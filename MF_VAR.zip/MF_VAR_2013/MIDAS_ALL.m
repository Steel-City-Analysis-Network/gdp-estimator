%======================================================================
%
%        MF-VAR REVISION                     
%
%        Date : MAY, 2013
%
%        Note : This code runs U-MIDAS regression     
%
%        Code Written By:  Frank Schorfheide  schorf@ssc.upenn.edu
%                          Dongho Song        donghos@sas.upenn.edu
%======================================================================


%======================================================================
%                          HOUSEKEEPING
%======================================================================

tic
close all
clear all
clc

ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

%% load vintages
create_vintage_NEW

nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33

%% specification
% qlag = # of lagged variables in MIDAS, e.g., 1;
% hR   = forecast horizon, e.g., 2;
% mv   = pick mv^{th} monthly indicator as regressor, e.g.,2;
H    = 8;
qlag = 2;


% store output forecasts
FL_vector50 = zeros(nrs,H,4);
FG_vector50 = zeros(nrs,H,4);

for rrrr=1:length(nrs_vec)
rrr = nrs_vec(rrrr);
vm_loaddatar_4_midas

for hR = 1:H
    
% last quarterly observation nT
nT  = max(find(~isnan(YQ)));

% length of monthly indicators mL
mL1  = 3*qlag + max(find(~isnan(YM(:,1))))-nT;
mL2  = 3*qlag + max(find(~isnan(YM(:,2))))-nT;
mL3  = 3*qlag + max(find(~isnan(YM(:,3))))-nT;

% change to quarterly frequency
pick = kron(ones(nT/3,1),[0;0;1]);
LHS_ = YQ(1:nT);
LHS  = LHS_(pick==1);

% construct RHS variables: conditional on forecast horizon hR
RHS01 = YM(1:nT-3*(hR+1)+mL1,1);
RHS02 = YM(1:nT-3*(hR+1)+mL2,2);
RHS03 = YM(1:nT-3*(hR+1)+mL3,3);
LHS0 = YQ(1:nT-3*(hR+1)+3);
clear RHS1 RHSF
RHS1 = [];
RHSF = [];
for tt=4:nT-3*(hR+2)
    if qlag==1
        RHS1(tt,:) =[1 LHS0(tt+4) RHS01(tt+4:tt+mL1+3)' RHS02(tt+4:tt+mL2+3)' RHS03(tt+4:tt+mL3+3)'];
    elseif qlag==2
        RHS1(tt,:) =[1 LHS0(tt+4) LHS0(tt+1) RHS01(tt+1:tt+mL1)' RHS02(tt+1:tt+mL2)' RHS03(tt+1:tt+mL3)'];
    end
end

% truncate and pick the last month values (change to quarterly frequency)
pick = kron(ones(floor(size(RHS1,1)/3),1),[0;0;1]);
RHS1 = RHS1(end-length(pick)+1:end,:);
RHS  = RHS1(pick==1,:);

% set the length of LHS be equal to that of RHS
LHS = LHS(end-size(RHS,1)+1:end);

LHS = LHS(2:end);
RHS = RHS(2:end,:);

% run OLS to obtain parameters
beta = regress(LHS,RHS);

% run forecast based on the parameters: beta
if qlag==1
RHSF = [1 YQ(nT) YM(nT-3*qlag+1:nT-3*qlag+mL1,1)' YM(nT-3*qlag+1:nT-3*qlag+mL2,2)' YM(nT-3*qlag+1:nT-3*qlag+mL3,3)'];  
elseif qlag==2
RHSF = [1 YQ(nT) YQ(nT-3) YM(nT-3*qlag+1:nT-3*qlag+mL1,1)' YM(nT-3*qlag+1:nT-3*qlag+mL2,2)' YM(nT-3*qlag+1:nT-3*qlag+mL3,3)']; 
end


FL_vector50(rrr,hR,4) = RHSF*beta;

if hR>1
    FG_vector50(rrr,hR,4) = 100*(FL_vector50(rrr,hR,4)-FL_vector50(rrr,hR-1,4));
else
    FG_vector50(rrr,hR,4) = 100*(FL_vector50(rrr,hR,4)-YQ(nT));
end

end
end

save results_RS_MIDAS_ALL.mat



path=ss;

disp('                                                                   ');
disp(['                        ELAPSED TIME:   ', num2str(toc)]          );
disp('                                                                   ');

elapsedtime=toc;











