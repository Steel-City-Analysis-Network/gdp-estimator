clc;clear;
ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

%load results_RS_QFBVAR.mat
load results_RS_MFBVAR.mat

qdata=0
disp('Are You Using QF-VAR? If 1 then Yes')
% recession episodes: 126 - 140
% 126: 1/31/08
% 140: 3/31/09

% if 1, then use real-time data || 0, then use final-data
select_rtime = 1;

% from 2006:Q2-2011:Q1
rtime = 2006+0.25:0.25:2011;

rs_sample = [];
rs_nobs   = [];
rs_fdata  = [];
rs_fsub   = [];

% the most recent vintage
for kk=1:length(var)
        
    if kk<4
        rs_sub   = kron(var(kk).fdata(:,end),ones(3,1));  
    else
        rs_sub   = var(kk).fdata(:,end);
    end
        
    if kk>=9
        rs_sub = rs_sub(1:end-1,:);
    end
        
    rs_sample = [rs_sample rs_sub];
end

tl_data = nan((length(rs_sample))/3,11);

for jj=1:(length(rs_sample))/3
    tl_data(jj,:) = mean(rs_sample(3*(jj-1)+1:3*jj,:));
end
    
tg_data = 100*(tl_data(2:end,:)-tl_data(1:end-1,:));
TL_data = [tl_data(:,4:end) tl_data(:,1:3)];
TG_data = [tg_data(:,4:end) tg_data(:,1:3)];

lhistoryd  = nan(15,20,11);
ghistoryd  = nan(15,20,11);
lhistory   = nan(15,20,11);
ghistory   = nan(15,20,11);
lhistory05 = nan(15,20,11);
ghistory05 = nan(15,20,11);
lhistory20 = nan(15,20,11);
ghistory20 = nan(15,20,11);
lhistory80 = nan(15,20,11);
ghistory80 = nan(15,20,11);
lhistory95 = nan(15,20,11);
ghistory95 = nan(15,20,11);


for rrr=127:141
rs_sample = [];
rs_sample2= [];
for kk=1:length(var)
        
    if kk<4
        rs_sub   = kron(var(kk).rsdata(:,rrr),ones(3,1));
        rs_sub2  = kron(var(kk).fdata(:,rrr),ones(3,1));
    else
        rs_sub   = var(kk).rsdata(:,rrr);
        rs_sub2  = var(kk).fdata(:,rrr);
    end
        
    if kk>=9
        rs_sub  = rs_sub(1:end-1,:);
        rs_sub2 = rs_sub2(1:end-1,:);
    end
        
    rs_sample = [rs_sample rs_sub];
    rs_sample2 = [rs_sample2 rs_sub2];
end

rsl_data  = nan((length(rs_sample))/3,11);
rsl_data2 = nan((length(rs_sample2))/3,11);

for jj=1:(length(rs_sample)-1)/3
    rsl_data(jj,:) = mean(rs_sample(3*(jj-1)+1:3*jj,:));
end
for jj=1:(length(rs_sample2)-1)/3
    rsl_data2(jj,:) = mean(rs_sample2(3*(jj-1)+1:3*jj,:));
end
    
rsg_data  = 100*(rsl_data(2:end,:)-rsl_data(1:end-1,:));
rsg_data2 = 100*(rsl_data2(2:end,:)-rsl_data2(1:end-1,:));

rsl_data  = rsl_data(1:max(find(~isnan(rsl_data(:,1)))),:);
rsg_data  = rsg_data(1:max(find(~isnan(rsg_data(:,1)))),:);

rsl_data2 = rsl_data2(1:max(find(~isnan(rsl_data(:,1)))),:);
rsg_data2 = rsg_data2(1:max(find(~isnan(rsg_data(:,1)))),:);

if qdata==0
rsl05      = squeeze(FL_vector05(rrr,:,:));
rsg05      = squeeze(FG_vector05(rrr,:,:));
rsl20      = squeeze(FL_vector20(rrr,:,:));
rsg20      = squeeze(FG_vector20(rrr,:,:));
rsl50      = squeeze(FL_vector50(rrr,:,:));
rsg50      = squeeze(FG_vector50(rrr,:,:));
rsl80      = squeeze(FL_vector80(rrr,:,:));
rsg80      = squeeze(FG_vector80(rrr,:,:));
rsl95      = squeeze(FL_vector95(rrr,:,:));
rsg95      = squeeze(FG_vector95(rrr,:,:));
rsl_d      = squeeze(FL_vector(rrr,:,:)); 
rsg_d      = squeeze(FG_vector(rrr,:,:));
elseif qdata==1
rsl05      = squeeze(FLQ_vector05(rrr,:,:));
rsg05      = squeeze(FGQ_vector05(rrr,:,:));
rsl20      = squeeze(FLQ_vector20(rrr,:,:));
rsg20      = squeeze(FGQ_vector20(rrr,:,:));
rsl50      = squeeze(FLQ_vector50(rrr,:,:));
rsg50      = squeeze(FGQ_vector50(rrr,:,:));
rsl80      = squeeze(FLQ_vector80(rrr,:,:));
rsg80      = squeeze(FGQ_vector80(rrr,:,:));
rsl95      = squeeze(FLQ_vector95(rrr,:,:));
rsg95      = squeeze(FGQ_vector95(rrr,:,:));
rsl_d      = squeeze(FLQ_vector(rrr,:,:)); 
rsg_d      = squeeze(FGQ_vector(rrr,:,:));
end

if select_rtime==1
rsl_data = [ rsl_data(:,4:end) rsl_data(:,1:3)];
rsg_data = [ rsg_data(:,4:end) rsg_data(:,1:3)];
elseif select_rtime==0
rsl_data = [ rsl_data2(:,4:end) rsl_data2(:,1:3)];
rsg_data = [ rsg_data2(:,4:end) rsg_data2(:,1:3)];    
end


rsl2_data = [rsl_data;rsl50];
rsg2_data = [rsg_data;rsg50];

rsl2_d = [rsl_data;rsl_d];
rsg2_d = [rsg_data;rsg_d];


rrrr=126;


if rrr>=127 && rrr<130     % 8-15
    lhistory(rrr-rrrr,1:15,:) = rsl2_data(end-14:end,:);
    ghistory(rrr-rrrr,1:15,:) = rsg2_data(end-14:end,:);
    lhistory05(rrr-rrrr,8:15,:) = rsl05;
    ghistory05(rrr-rrrr,8:15,:) = rsg05;
    lhistory20(rrr-rrrr,8:15,:) = rsl20;
    ghistory20(rrr-rrrr,8:15,:) = rsg20;
    lhistory80(rrr-rrrr,8:15,:) = rsl80;
    ghistory80(rrr-rrrr,8:15,:) = rsg80;
    lhistory95(rrr-rrrr,8:15,:) = rsl95;
    ghistory95(rrr-rrrr,8:15,:) = rsg95;
    lhistory05(rrr-rrrr,1:7,:)  = lhistory(rrr-rrrr,1:7,:);
    ghistory05(rrr-rrrr,1:7,:)  = ghistory(rrr-rrrr,1:7,:);
    lhistory20(rrr-rrrr,1:7,:)  = lhistory(rrr-rrrr,1:7,:);
    ghistory20(rrr-rrrr,1:7,:)  = ghistory(rrr-rrrr,1:7,:);
    lhistory80(rrr-rrrr,1:7,:)  = lhistory(rrr-rrrr,1:7,:);
    ghistory80(rrr-rrrr,1:7,:)  = ghistory(rrr-rrrr,1:7,:);
    lhistory95(rrr-rrrr,1:7,:)  = lhistory(rrr-rrrr,1:7,:);
    ghistory95(rrr-rrrr,1:7,:)  = ghistory(rrr-rrrr,1:7,:);      
elseif rrr>=130 && rrr<133     % 9-16
    lhistory(rrr-rrrr,1:16,:) = rsl2_data(end-15:end,:);
    ghistory(rrr-rrrr,1:16,:) = rsg2_data(end-15:end,:);
    lhistory05(rrr-rrrr,9:16,:) = rsl05;
    ghistory05(rrr-rrrr,9:16,:) = rsg05;
    lhistory20(rrr-rrrr,9:16,:) = rsl20;
    ghistory20(rrr-rrrr,9:16,:) = rsg20;
    lhistory80(rrr-rrrr,9:16,:) = rsl80;
    ghistory80(rrr-rrrr,9:16,:) = rsg80;
    lhistory95(rrr-rrrr,9:16,:) = rsl95;
    ghistory95(rrr-rrrr,9:16,:) = rsg95;
    lhistory05(rrr-rrrr,1:8,:)  = lhistory(rrr-rrrr,1:8,:);
    ghistory05(rrr-rrrr,1:8,:)  = ghistory(rrr-rrrr,1:8,:);
    lhistory20(rrr-rrrr,1:8,:)  = lhistory(rrr-rrrr,1:8,:);
    ghistory20(rrr-rrrr,1:8,:)  = ghistory(rrr-rrrr,1:8,:);
    lhistory80(rrr-rrrr,1:8,:)  = lhistory(rrr-rrrr,1:8,:);
    ghistory80(rrr-rrrr,1:8,:)  = ghistory(rrr-rrrr,1:8,:);
    lhistory95(rrr-rrrr,1:8,:)  = lhistory(rrr-rrrr,1:8,:);
    ghistory95(rrr-rrrr,1:8,:)  = ghistory(rrr-rrrr,1:8,:);      
elseif rrr>=133 && rrr<136     % 10-17
    lhistory(rrr-rrrr,1:17,:) = rsl2_data(end-16:end,:);
    ghistory(rrr-rrrr,1:17,:) = rsg2_data(end-16:end,:);
    lhistory05(rrr-rrrr,10:17,:) = rsl05;
    ghistory05(rrr-rrrr,10:17,:) = rsg05;
    lhistory20(rrr-rrrr,10:17,:) = rsl20;
    ghistory20(rrr-rrrr,10:17,:) = rsg20;
    lhistory80(rrr-rrrr,10:17,:) = rsl80;
    ghistory80(rrr-rrrr,10:17,:) = rsg80;
    lhistory95(rrr-rrrr,10:17,:) = rsl95;
    ghistory95(rrr-rrrr,10:17,:) = rsg95;    
    lhistory05(rrr-rrrr,1:9,:)  = lhistory(rrr-rrrr,1:9,:);
    ghistory05(rrr-rrrr,1:9,:)  = ghistory(rrr-rrrr,1:9,:);
    lhistory20(rrr-rrrr,1:9,:)  = lhistory(rrr-rrrr,1:9,:);
    ghistory20(rrr-rrrr,1:9,:)  = ghistory(rrr-rrrr,1:9,:);
    lhistory80(rrr-rrrr,1:9,:)  = lhistory(rrr-rrrr,1:9,:);
    ghistory80(rrr-rrrr,1:9,:)  = ghistory(rrr-rrrr,1:9,:);
    lhistory95(rrr-rrrr,1:9,:)  = lhistory(rrr-rrrr,1:9,:);
    ghistory95(rrr-rrrr,1:9,:)  = ghistory(rrr-rrrr,1:9,:);
elseif rrr>=136 && rrr<139     % 11-18
    lhistory(rrr-rrrr,1:18,:) = rsl2_data(end-17:end,:);
    ghistory(rrr-rrrr,1:18,:) = rsg2_data(end-17:end,:);
    lhistory05(rrr-rrrr,11:18,:) = rsl05;
    ghistory05(rrr-rrrr,11:18,:) = rsg05;
    lhistory20(rrr-rrrr,11:18,:) = rsl20;
    ghistory20(rrr-rrrr,11:18,:) = rsg20;
    lhistory80(rrr-rrrr,11:18,:) = rsl80;
    ghistory80(rrr-rrrr,11:18,:) = rsg80;
    lhistory95(rrr-rrrr,11:18,:) = rsl95;
    ghistory95(rrr-rrrr,11:18,:) = rsg95;    
    lhistory05(rrr-rrrr,1:10,:)  = lhistory(rrr-rrrr,1:10,:);
    ghistory05(rrr-rrrr,1:10,:)  = ghistory(rrr-rrrr,1:10,:);
    lhistory20(rrr-rrrr,1:10,:)  = lhistory(rrr-rrrr,1:10,:);
    ghistory20(rrr-rrrr,1:10,:)  = ghistory(rrr-rrrr,1:10,:);
    lhistory80(rrr-rrrr,1:10,:)  = lhistory(rrr-rrrr,1:10,:);
    ghistory80(rrr-rrrr,1:10,:)  = ghistory(rrr-rrrr,1:10,:);
    lhistory95(rrr-rrrr,1:10,:)  = lhistory(rrr-rrrr,1:10,:);
    ghistory95(rrr-rrrr,1:10,:)  = ghistory(rrr-rrrr,1:10,:);  
elseif rrr>=139 && rrr<142     % 12-19
    lhistory(rrr-rrrr,1:19,:) = rsl2_data(end-18:end,:);
    ghistory(rrr-rrrr,1:19,:) = rsg2_data(end-18:end,:);
    lhistory05(rrr-rrrr,12:19,:) = rsl05;
    ghistory05(rrr-rrrr,12:19,:) = rsg05;
    lhistory20(rrr-rrrr,12:19,:) = rsl20;
    ghistory20(rrr-rrrr,12:19,:) = rsg20;
    lhistory80(rrr-rrrr,12:19,:) = rsl80;
    ghistory80(rrr-rrrr,12:19,:) = rsg80;
    lhistory95(rrr-rrrr,12:19,:) = rsl95;
    ghistory95(rrr-rrrr,12:19,:) = rsg95;    
    lhistory05(rrr-rrrr,1:11,:)  = lhistory(rrr-rrrr,1:11,:);
    ghistory05(rrr-rrrr,1:11,:)  = ghistory(rrr-rrrr,1:11,:);
    lhistory20(rrr-rrrr,1:11,:)  = lhistory(rrr-rrrr,1:11,:);
    ghistory20(rrr-rrrr,1:11,:)  = ghistory(rrr-rrrr,1:11,:);
    lhistory80(rrr-rrrr,1:11,:)  = lhistory(rrr-rrrr,1:11,:);
    ghistory80(rrr-rrrr,1:11,:)  = ghistory(rrr-rrrr,1:11,:);
    lhistory95(rrr-rrrr,1:11,:)  = lhistory(rrr-rrrr,1:11,:);
    ghistory95(rrr-rrrr,1:11,:)  = ghistory(rrr-rrrr,1:11,:);  
end

end

vname  = {'2008:M1 Vintage', '2008:M2 Vintage', '2008:M3 Vintage',...
          '2008:M4 Vintage', '2008:M5 Vintage', '2008:M6 Vintage',...
          '2008:M7 Vintage', '2008:M8 Vintage', '2008:M9 Vintage',...
          '2008:M10 Vintage','2008:M11 Vintage','2008:M12 Vintage',...
          '2009:M1 Vintage', '2009:M2 Vintage', '2009:M3 Vintage'};
      
%% plot from 2007:Q3 to 2009:Q4      

scrsz = get(0,'ScreenSize');

fig1=figure('Position',[20,20,900,600],'Name',...
        'Around Recession Period','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.2]);
vvv=9;    
for qq=7:12
subplot(2,3,qq-6)   
hold on
g90=shadedplot(rtime(6:15),squeeze(ghistory95(qq,6:15,vvv)),squeeze(ghistory05(qq,6:15,vvv)),[0.9 0.9 0.3],'w');
hold on    
g60=shadedplot(rtime(6:15),squeeze(ghistory80(qq,6:15,vvv)),squeeze(ghistory20(qq,6:15,vvv)),[0.7 0.6 0.1],[0.9 0.9 0.3]); 
hold on
plot(rtime(6:15),squeeze(ghistory(qq,6:15,vvv)),'LineWidth',1.5,'Color',[0.6,0.6,0.1])
hold on
plot(rtime(6:15),TG_data(end-17:end-8,vvv),'Marker','^','LineWidth',1,'Color',[0.2,0.2,0.2],'LineStyle','-')
alpha(0.6)
title(vname(qq),'Interpreter','latex','FontSize',14)
axis([rtime(6) rtime(15) -3.5 3])
set(gca,'XTickLabel',{'07:Q3','08:Q1','08:Q3','09:Q1','09:Q3'})
set(gca,'FontSize',15)
end
set(gca,'FontSize',13)


fig2=figure('Position',[20,20,900,600],'Name',...
        'Around Recession Period','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.2]);
vvv=3;    
for qq=7:12
subplot(2,3,qq-6)   
hold on
g90=shadedplot(rtime(6:15),squeeze(ghistory95(qq,6:15,vvv)),squeeze(ghistory05(qq,6:15,vvv)),[0.9 0.9 0.3],'w');
hold on    
g60=shadedplot(rtime(6:15),squeeze(ghistory80(qq,6:15,vvv)),squeeze(ghistory20(qq,6:15,vvv)),[0.7 0.6 0.1],[0.9 0.9 0.3]); 
hold on
plot(rtime(6:15),squeeze(ghistory(qq,6:15,vvv)),'LineWidth',1.5,'Color',[0.6,0.6,0.1])
hold on
plot(rtime(6:15),TG_data(end-17:end-8,vvv),'Marker','^','LineWidth',1,'Color',[0.2,0.2,0.2],'LineStyle','-')
alpha(0.6)
title(vname(qq),'Interpreter','latex','FontSize',14)
axis([rtime(6) rtime(15) -3 3])
set(gca,'XTickLabel',{'07:Q3','08:Q1','08:Q3','09:Q1','09:Q3'})
set(gca,'FontSize',15)
end
set(gca,'FontSize',13)



fig3=figure('Position',[20,20,900,600],'Name',...
        'Around Recession Period','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/1.2]);
vvv=1;    
for qq=10:15
subplot(2,3,qq-9)   
hold on
l90=shadedplot(rtime(6:15),100*squeeze(lhistory95(qq,6:15,vvv)),100*squeeze(lhistory05(qq,6:15,vvv)),[0.9 0.9 0.3],'w');
hold on    
l60=shadedplot(rtime(6:15),100*squeeze(lhistory80(qq,6:15,vvv)),100*squeeze(lhistory20(qq,6:15,vvv)),[0.7 0.6 0.1],[0.9 0.9 0.3]); 
hold on
plot(rtime(6:15),100*squeeze(lhistory(qq,6:15,vvv)),'LineWidth',1.5,'Color',[0.6,0.6,0.1])
hold on
plot(rtime(6:15),100*TL_data(end-17:end-8,vvv),'Marker','^','LineWidth',1,'Color',[0.2,0.2,0.2],'LineStyle','-')
alpha(0.6)
title(vname(qq),'Interpreter','latex','FontSize',14)
axis([rtime(6) rtime(15) 3.5 12])
set(gca,'XTickLabel',{'07:Q3','08:Q1','08:Q3','09:Q1','09:Q3'})
set(gca,'FontSize',15)
end
set(gca,'FontSize',13)


% fig4=figure('Position',[20,20,900,600],'Name',...
%         'Around Recession Period','Color','w',...
%         'Position',[1 scrsz(4)/13 scrsz(3)/1.0 scrsz(4)/2]);
% vvv=6;    
% for qq=10:15
% subplot(2,3,qq-9)   
% hold on
% l90=shadedplot(rtime(6:15),100*squeeze(lhistory95(qq,6:15,vvv)),100*squeeze(lhistory05(qq,6:15,vvv)),[0.6 0.6 0.6],'w');
% hold on    
% l60=shadedplot(rtime(6:15),100*squeeze(lhistory80(qq,6:15,vvv)),100*squeeze(lhistory20(qq,6:15,vvv)),[0.5 0.5 0.5],[0.6 0.6 0.6]); 
% hold on
% plot(rtime(6:15),100*squeeze(lhistory(qq,6:15,vvv)),'LineWidth',1.5,'Color',[0.4,0.4,0.4])
% hold on
% plot(rtime(6:15),100*TL_data(end-17:end-8,vvv),'Marker','^','LineWidth',1,'Color',[0.9,0.2,0.1],'LineStyle','-')
% alpha(0.6)
% title(vname(qq),'Interpreter','latex','FontSize',11)
% axis([rtime(6) rtime(15) -7 8])
% set(gca,'XTickLabel',{'07:Q3','08:Q1','08:Q3','09:Q1','09:Q3'})
% end


saveas(fig1,'Figures/GDP_rec.bmp')
saveas(fig2,'Figures/INF_rec.bmp')
saveas(fig3,'Figures/UNR_rec.bmp')
%saveas(fig4,'Figures/FF_rec.bmp')




