%======================================================================
%
%        MF BVAR : MIXED FREQ BAYESIAN VAR INFERENCE AND FORECASTING                     
%
%        Date : November, 2013
%
%        Note : Given selected hyperparameters, this code performs  
%               Bayesian Inference and obtains forecast estimates      
%
%        Code Written By:  Frank Schorfheide  schorf@ssc.upenn.edu
%                          Dongho Song        donghos@sas.upenn.edu
%======================================================================


%======================================================================
%                          HOUSEKEEPING
%======================================================================

tic
close all
clear all
clc

ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);


rs_GDP = [];
rs_UNR = [];
rs_INF = [];
rs_FF  = [];

HAIR   = [];

for wwww=1:11
    
if wwww==1
    load lambda1_revision_1.mat
elseif wwww==2
    load lambda1_revision_2.mat
elseif wwww==3
    load lambda1_revision_3.mat
elseif wwww==4
    load lambda1_revision_4.mat
elseif wwww==5
    load lambda1_revision_5.mat
elseif wwww==6
    load lambda1_revision_6.mat
elseif wwww==7
    load lambda1_revision_7.mat
elseif wwww==8
    load lambda1_revision_8.mat
elseif wwww==9
    load lambda1_revision_9.mat    
elseif wwww==10
    load lambda1_revision_10.mat
elseif wwww==11
    load lambda1_revision_11.mat       
end

HAIR = [HAIR mdd_vector];

vm_sub_forecast

[Nsim Nh Nv] = size(YYvector_ql);

nstart = 0.5*Nsim+1;
nend   = Nsim;
window = 500;
number = floor((nend-nstart)/window);


recur_stat_gr = zeros(number+1,11);
recur_stat_lv = zeros(number+1,11);

for bb=1:number+1
    
    recur_stat_gr(bb,:) = squeeze(mean(YYvector_qg(nstart+1:min(nstart+window*bb, Nsim),8,:)));
    recur_stat_lv(bb,:) = squeeze(mean(YYvector_ql(nstart+1:min(nstart+window*bb, Nsim),8,:)));  
end

recur_stat = [recur_stat_gr(:,9) recur_stat_lv(:,1)*100 recur_stat_gr(:,5) recur_stat_lv(:,6)*100];
  
rs_GDP = [rs_GDP recur_stat(:,1)]; 
rs_UNR = [rs_UNR recur_stat(:,2)]; 
rs_INF = [rs_INF recur_stat(:,3)]; 
rs_FF  = [rs_FF  recur_stat(:,4)]; 

savefilename = ['recur_stat_', num2str(wwww), '.mat'];	
save(savefilename);
    
end
    

rs_GDP0 = rs_GDP - mean(rs_GDP(end,:));
rs_INF0 = rs_INF - mean(rs_INF(end,:));
rs_UNR0 = rs_UNR - mean(rs_UNR(end,:));
rs_FF0  = rs_FF  - mean(rs_FF(end,:));

rs_max1 = max(max(max(rs_GDP0)),max(max(rs_INF0)));
rs_min1 = min(min(min(rs_GDP0)),min(min(rs_INF0)));
rs_max2 = max(max(max(rs_UNR0)),max(max(rs_FF0)));
rs_min2 = min(min(min(rs_UNR0)),min(min(rs_FF0)));

rs_max  = max(rs_max1,rs_max2);
rs_min  = min(rs_min1,rs_min2);

scrsz = get(0,'ScreenSize');
fig=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3)/1 scrsz(4)/1.2]);
subplot(2,2,1)
plot(rs_GDP0,'Color',[0.7 0.7 0.7],'LineWidth',2)
axis([1 number+1 -.05 .05])
title('GDP Growth','Interpreter','latex','FontSize',15);
set(gca,'Xtick',1:20,'XTickLabel',{'0.5k','','','','2.5k','','','','','5k','','','','','7.5k','','','','','10k'})
set(gca,'FontSize',15)
subplot(2,2,2)
plot(rs_UNR0,'Color',[0.7 0.7 0.7],'LineWidth',2)
axis([1 number+1 -.05 .05])
title('Unemployment Rate','Interpreter','latex','FontSize',15);
set(gca,'Xtick',1:20,'XTickLabel',{'0.5k','','','','2.5k','','','','','5k','','','','','7.5k','','','','','10k'})
set(gca,'FontSize',15)
subplot(2,2,3)
plot(rs_INF0,'Color',[0.7 0.7 0.7],'LineWidth',2)
axis([1 number+1 -.05 .05])
title('Inflation','Interpreter','latex','FontSize',15);
set(gca,'Xtick',1:20,'XTickLabel',{'0.5k','','','','2.5k','','','','','5k','','','','','7.5k','','','','','10k'})
set(gca,'FontSize',15)
subplot(2,2,4)
plot(rs_FF0,'Color',[0.7 0.7 0.7],'LineWidth',2)
axis([1 number+1 -.05 .05])
title('Federal Funds Rate','Interpreter','latex','FontSize',15);
set(gca,'Xtick',1:20,'XTickLabel',{'0.5k','','','','2.5k','','','','','5k','','','','','7.5k','','','','','10k'})
set(gca,'FontSize',15)



fig=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3)/1.5 scrsz(4)/1.35]);
plot(HAIR,'LineWidth',2)
set(gca,'Xtick',1:6,'XTickLabel',{'0.005','0.01','0.05','0.09','0.15','0.50'})
set(gca,'FontSize',24)
xlabel('$$\lambda_{1}$$','Interpreter','latex','FontSize',37);




path = ss;
