    rs_sample = nan(size(var(9).rsdata,1),11);
    rs_nobs   = [];
    rs_fdata  = [];
    rs_fsub   = [];
    
    for kk=1:length(var)
        
        if kk<4
            rs_sub   = kron(var(kk).rsdata(:,rrr),ones(3,1));         
            rs_T     = max(find(~isnan(rs_sub)));
        else
            rs_sub   = var(kk).rsdata(:,rrr);
            rs_T     = max(find(~isnan(rs_sub)));
        end
                
        rs_sample(1:length(rs_sub),kk) = rs_sub;
        rs_nobs   = [rs_nobs rs_T];
    end
    
    for kk=1:length(var)        
        
        if kk>3
            rs_fmsub = var(kk).fdata(min(rs_nobs)-2:min(rs_nobs)+24,rrr);
            rs_fsub  = zeros(size(rs_fmsub,1)/3,1);
            for ii=1:size(rs_fsub,1)
                rs_fsub(ii)=mean(rs_fmsub(3*(ii-1)+1:3*ii));
            end
        else
            if min(rs_nobs)<rs_nobs(1)
                min_nobs = rs_nobs(1);
            else
                min_nobs = min(rs_nobs);
            end
            rs_fsub  = var(kk).fdata(min_nobs/3:min_nobs/3+8,rrr);            
        end
        
        rs_fdata  = [rs_fdata rs_fsub]; 
        rs_flvl   = rs_fdata(2:end,:);
        rs_fgrth  = 100*(rs_fdata(2:end,:)-rs_fdata(1:end-1,:)); 
      
    end
        % temporary definition
        rs_flvl   = [rs_flvl(:,4:end) rs_flvl(:,1:3)];
        rs_fgrth  = [rs_fgrth(:,4:end) rs_fgrth(:,1:3)];
        
    YQ      = rs_sample(:,1:3);
    YM      = rs_sample(:,4:end);   
    YDATA0  = [YM YQ];
    YDATA   = YDATA0(1:min(rs_nobs),:);
    
    RYQ  = zeros(min_nobs/3,11);
    for gg=1:min_nobs/3
        RYQ(gg,:) = mean(YDATA(3*(gg-1)+1:3*gg,:));
    end    
        
    nv   = size(RYQ,2);