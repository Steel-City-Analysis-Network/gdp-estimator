% DATASET: 10 Variables
% UNRATE,HOURS,CPI,INDPRO,PCE,FEDFUND,TBOND,SP500
YM = csvread('YM.csv',1,1);
YM(:,1)   = YM(:,1)/100;
YM(:,6:7) = YM(:,6:7)/100;
YM(:,2:5) = log(YM(:,2:5));
YM(:,8)   = log(YM(:,8)); 

% GDP,INVFIX 
YQ = csvread('YQ.csv',1,1);
YQ = log(YQ);
YQ = kron(YQ,ones(3,1));         

% prespecified federal funds rates
setff = 0.002;

% specification
Nm = size(YM,2);
Nq = size(YQ,2);

nlags_  = 6;                  % number of lags   
T0      = nlags_+1;           % size of pre-sample
nex     = 1;                  % number of exogenous vars;1(=intercept only) 
p       = nlags_;
nlags   = p;
nv      = Nm+Nq;
kq      = Nq*p;

% data selection
data_spec;                    

pick    = min(today_loc(1)-1,size(YQ,1));

YM      = YM(1:today_loc(1)-1,:);
YQ      = YQ(1:pick,:);

trueYM  = [data_available(1:today_loc(1)-1,2:3) YM];
trueYQ  = [data_available(1:pick,2:3) YQ];

if pick<(today_loc(1)-1)
    add_pick = today_loc(1)-1-pick;
    trueYY = [trueYM [YQ;log(zeros(add_pick,Nq))]];
else
    trueYY = [trueYM YQ];
end
    

nobs    = index_YY(end,1)-T0; % length of balanced panel 
Tnew    = size(index_YN,1);   % number of additional observations
Tnobs   = nobs+Tnew;          % number of total observations