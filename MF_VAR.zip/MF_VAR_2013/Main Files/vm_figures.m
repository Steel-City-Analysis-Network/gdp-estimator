%% descriptive figures
pnames   =  strvcat('Unemployment Rate','Hours Worked','Consumer Price Index (Growth Rates)',...
     'Industrial Production Index (Growth Rates)','Personal Consumption Expenditure (Growth Rates)',...
    'Federal Funds Rate','Treasury Bond Yield','SP 500 (Growth Rates)',...
    'Gross Domestic Product (Growth Rates)','Fixed Investment (Growth Rates)');
pxnames  =  strvcat( 'Forecast Horizon');
pynames1 =  strvcat( 'Percent');
pynames2 =  strvcat( 'Percent (Annualized)');

% real data
Ymm     = Ym(end-104:end,:);
Yqq     = Yq(end-104:end,:);
YQQ     = zeros(size(Yqq,1)/3,size(Yqq,2));
YMM     = zeros(size(Ymm,1)/3,size(Ymm,2));

for i=1:size(Ymm,1)/3
    YMM(i,:) = mean(Ymm(3*(i-1)+1:3*i,:));
    YQQ(i,:) = mean(Yqq(3*(i-1)+1:3*i,:));
end

YYY = [YMM YQQ];

grY = 400*(YYY(2:end,:)-YYY(1:end-1,:));
lvY = 100*YYY;

% time line
if today(2)<4
    ftime = seqa(today(1)-3,0.25,H/3+12);
elseif today(2)>=4 && today(2)<7
    ftime = seqa(today(1)-3+0.25,0.25,H/3+12);
elseif today(2)>=7 && today(2)<10
    ftime = seqa(today(1)-3+0.5,0.25,H/3+12);
else
    ftime = seqa(today(1)-3+0.75,0.25,H/3+12);
end

%% select variables
% Level: Unemployment Rates, Federal Funds Rates, Treasury Bond Yields
% Growth: The Rests (except SP 500)
vartypel = [1 0 0 0 0 1 1 0 0 0];
vartypeg = [0 1 1 1 1 0 0 0 1 1];

pnamesl  = pnames(vartypel==1,:);
pnamesg  = pnames(vartypeg==1,:);

% convert to annualized growth rates 
YYvecl   = 100*YYvector_ql(:,:,vartypel==1);
YYvecg   = 4*YYvector_qg(:,:,vartypeg==1);

FYYvecl  = 100*FYYvector_ql(:,:,vartypel==1);
FYYvecg  = 4*FYYvector_qg(:,:,vartypeg==1);

gry      = grY(end-11:end,vartypeg==1);
lvy      = lvY(end-11:end,vartypel==1);

 % 90 percent and 60 percent interval and median values
[yvecl95,yvecl80,yvecl50,yvecl20,yvecl05] = moment(YYvecl);
[yvecg95,yvecg80,yvecg50,yvecg20,yvecg05] = moment(YYvecg);
[Fvecl95,Fvecl80,Fvecl50,Fvecl20,Fvecl05] = moment(FYYvecl);
[Fvecg95,Fvecg80,Fvecg50,Fvecg20,Fvecg05] = moment(FYYvecg);

% augment forecasts with 3 years of past data
yvecl05 = [lvy;yvecl05];
yvecl20 = [lvy;yvecl20];
yvecl50 = [lvy;yvecl50];
yvecl80 = [lvy;yvecl80];
yvecl95 = [lvy;yvecl95];

yvecg05 = [gry;yvecg05];
yvecg20 = [gry;yvecg20];
yvecg50 = [gry;yvecg50];
yvecg80 = [gry;yvecg80];
yvecg95 = [gry;yvecg95];

Fvecl05 = [lvy;Fvecl05];
Fvecl20 = [lvy;Fvecl20];
Fvecl50 = [lvy;Fvecl50];
Fvecl80 = [lvy;Fvecl80];
Fvecl95 = [lvy;Fvecl95];

Fvecg05 = [gry;Fvecg05];
Fvecg20 = [gry;Fvecg20];
Fvecg50 = [gry;Fvecg50];
Fvecg80 = [gry;Fvecg80];
Fvecg95 = [gry;Fvecg95];

% level now-/forecasts
scrsz = get(0,'ScreenSize');
lv1=figure('Position',[20,20,900,600],'Name',...
        'Levels Now-/Forecasts','Color','w',...
        'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
for i=1:1  
hold on
    plot(ftime,Fvecl50(:,i), 'Color',[0.9 0.2 0.1],'LineWidth',3,'LineStyle','--');
    plot(ftime,yvecl50(:,i), 'Color',[0.1 0.1 0.1],'LineWidth',3,'LineStyle','-');          
title(pnamesl(i,:),'FontSize',18,'FontWeight','bold');
xlabel(pxnames,'FontSize',15,'FontWeight','bold');
ylabel(pynames1(1,:),'FontSize',15,'FontWeight','bold');
h=legend('Median Forecasts: fix FF','Median Forecasts') ;
    set(h, 'FontSize',14,'FontWeight','bold');
    set(h,'Location','SouthEast');
    legend('boxoff')
hold on
    l90=shadedplot(ftime,yvecl95(:,i)',yvecl05(:,i)',[0.8 0.8 0.8],'w');
hold on    
    l60=shadedplot(ftime,yvecl80(:,i)',yvecl20(:,i)',[0.4 0.4 0.4],'w');
alpha(0.65)
axis tight
grid on
hold off
end

lv2=figure('Position',[20,20,900,600],'Name',...
        'Levels Now-/Forecasts','Color','w',...
        'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
for i=2:3
subplot(1,2,i-1)    
hold on
    plot(ftime,Fvecl50(:,i), 'Color',[0.9 0.2 0.1],'LineWidth',3,'LineStyle','--');
    plot(ftime,yvecl50(:,i), 'Color',[0.1 0.1 0.1],'LineWidth',3,'LineStyle','-');          
title(pnamesl(i,:),'FontSize',18,'FontWeight','bold');
xlabel(pxnames,'FontSize',15,'FontWeight','bold');
ylabel(pynames1(1,:),'FontSize',15,'FontWeight','bold');
h=legend('Median Forecasts: fix FF','Median Forecasts') ;
    set(h, 'FontSize',14,'FontWeight','bold');
    set(h,'Location','SouthEast');
    legend('boxoff')
hold on
    l90=shadedplot(ftime,yvecl95(:,i)',yvecl05(:,i)',[0.8 0.8 0.8],'w');
hold on    
    l60=shadedplot(ftime,yvecl80(:,i)',yvecl20(:,i)',[0.4 0.4 0.4],'w');
alpha(0.65)
axis tight
grid on
hold off
end

% growth now-/forecasts
gr1=figure('Position',[20,20,900,600],'Name',...
        'Growth Now-/Forecasts','Color','w',...
        'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
for i=1:2
subplot(1,2,i)    
hold on
    plot(ftime,Fvecg50(:,i), 'Color',[0.9 0.2 0.1],'LineWidth',3,'LineStyle','--');
    plot(ftime,yvecg50(:,i), 'Color',[0.1 0.1 0.1],'LineWidth',3,'LineStyle','-'); 
title(pnamesg(i,:),'FontSize',18,'FontWeight','bold');
xlabel(pxnames(1,:),'FontSize',15,'FontWeight','bold');
ylabel(pynames2(1,:),'FontSize',15,'FontWeight','bold');
h=legend('Median Forecasts: fix FF','Median Forecasts') ;
    set(h, 'FontSize',14,'FontWeight','bold');
    set(h,'Location','SouthEast');
    legend('boxoff')
hold on
    g90=shadedplot(ftime,yvecg95(:,i)',yvecg05(:,i)',[0.8 0.8 0.8],'w');
hold on    
    g60=shadedplot(ftime,yvecg80(:,i)',yvecg20(:,i)',[0.4 0.4 0.4],'w');
alpha(0.65)
axis tight
grid on
hold off
end

gr2=figure('Position',[20,20,900,600],'Name',...
        'Growth Now-/Forecasts','Color','w',...
        'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
for i=3:4
subplot(1,2,i-2)    
hold on
    plot(ftime,Fvecg50(:,i), 'Color',[0.9 0.2 0.1],'LineWidth',3,'LineStyle','--');
    plot(ftime,yvecg50(:,i), 'Color',[0.1 0.1 0.1],'LineWidth',3,'LineStyle','-');     
title(pnamesg(i,:),'FontSize',18,'FontWeight','bold');
xlabel(pxnames(1,:),'FontSize',15,'FontWeight','bold');
ylabel(pynames2(1,:),'FontSize',15,'FontWeight','bold');
h=legend('Median Forecasts: fix FF','Median Forecasts') ;
    set(h, 'FontSize',14,'FontWeight','bold');
    set(h,'Location','SouthEast');
    legend('boxoff')
hold on
    g90=shadedplot(ftime,yvecg95(:,i)',yvecg05(:,i)',[0.8 0.8 0.8],'w');
hold on
    g60=shadedplot(ftime,yvecg80(:,i)',yvecg20(:,i)',[0.4 0.4 0.4],'w');
alpha(0.65)
axis tight
grid on
hold off
end

gr3=figure('Position',[20,20,900,600],'Name',...
        'Growth Now-/Forecasts','Color','w',...
        'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
for i=5:6
subplot(1,2,i-4)    
hold on
    plot(ftime,Fvecg50(:,i), 'Color',[0.9 0.2 0.1],'LineWidth',3,'LineStyle','--');
    plot(ftime,yvecg50(:,i), 'Color',[0.1 0.1 0.1],'LineWidth',3,'LineStyle','-');     
title(pnamesg(i,:),'FontSize',18,'FontWeight','bold');
xlabel(pxnames(1,:),'FontSize',15,'FontWeight','bold');
ylabel(pynames2(1,:),'FontSize',15,'FontWeight','bold');
h=legend('Median Forecasts: fix FF','Median Forecasts') ;
    set(h, 'FontSize',14,'FontWeight','bold');
    set(h,'Location','SouthEast');
    legend('boxoff')
hold on
    g90=shadedplot(ftime,yvecg95(:,i)',yvecg05(:,i)',[0.8 0.8 0.8],'w');
hold on
    g60=shadedplot(ftime,yvecg80(:,i)',yvecg20(:,i)',[0.4 0.4 0.4],'w');
alpha(0.65)
axis tight
grid on
hold off
end


% saveas(lv1,'Figures/Posterior Predictive Distribution1 (Level).bmp');
% saveas(lv2,'Figures/Posterior Predictive Distribution2 (Level).bmp');
% saveas(gr1,'Figures/Posterior Predictive Distribution1 (Growth).bmp');
% saveas(gr2,'Figures/Posterior Predictive Distribution2 (Growth).bmp');
% saveas(gr3,'Figures/Posterior Predictive Distribution3 (Growth).bmp');