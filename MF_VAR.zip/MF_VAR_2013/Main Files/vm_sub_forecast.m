%======================================================================
%                     BLOCK 3: FORECASTING
%======================================================================
disp('                                                                ');
disp('                                                                ');
disp('                                                                ');
disp('                    MIXED FREQUENCY VAR: FORECASTING            ');
disp('                                                                ');
disp('                          - BLOCK ALGORITHM (2)-                ');
disp('                                                                ');
disp('                                                                ');
disp('                                                                ');

% do not fix federal funds rate
% store forecasts in monthly frequency
YYvector_ml  = zeros(nsim,H,Nm+Nq);     % collects now/forecast      
YYvector_mg  = zeros(nsim,H,Nm+Nq);
% store forecasts in quarterly frequency
YYvector_ql  = zeros(nsim,H/3,Nm+Nq);   
YYvector_qg  = zeros(nsim,H/3,Nm+Nq);

% % fix federal funds rate
% % store forecasts in monthly frequency
% FYYvector_ml  = zeros(nsim,H,Nm+Nq);     % collects now/forecast      
% FYYvector_mg  = zeros(nsim,H,Nm+Nq);
% % store forecasts in quarterly frequency
% FYYvector_ql  = zeros(nsim,H/3,Nm+Nq);   
% FYYvector_qg  = zeros(nsim,H/3,Nm+Nq);

counter   = 0;

for jj=1:nsim
    
    
    YYact    = squeeze(YYactsim(jj,end,:));
    XXact    = squeeze(XXactsim(jj,end,:));    
    post_phi = squeeze(Phip(jj,:,:));
    post_sig = squeeze(Sigmap(jj,:,:));
    
    vm_forecast_no_error                       % Output: YYpred 
    
    counter         = counter +1; 
     
    if counter==5000
    disp('                                                              '); 
    disp(['                FORECAST HORIZON:   ', num2str(H)]            );
    disp('                                                              ');
    disp(['                DRAW NUMBER:   ', num2str(jj)]                );
    disp('                                                              ');
    disp(['                REMAINING DRAWS:   ', num2str(nsim-jj)]       );
    disp('                                                              ');

    counter = 0;
    end    
    
    %% 1) Now-/Forecasts without fixing Federal Funds Rates 
    % store in monthly frequency
    YYvector_ml(jj,:,:)  = YYpred;    
    YYvector_mg(jj,:,:)  = 100*(YYpred1(2:end,:)-YYpred1(1:end-1,:));
    % store forecasts in quarterly frequency
    for ll=1:(H/3)-1
    YYvector_ql(jj,ll+1,:) = ...
    mean(YYvector_ml(jj,3*ll+1-Tnew:3*(ll+1)-Tnew,:));
    end
    
    % store nowcasts in quarterly frequency
    YYnow=squeeze(YYactsim(jj,end-Tnew+1:end,:));
    
    if size(YYnow,1) > size(YYnow,2)
        YYnow = YYnow';
    end
    
    if size(squeeze(YYvector_ml(jj,1:3-Tnew,:)),1)>...
       size(squeeze(YYvector_ml(jj,1:3-Tnew,:)),2)
       YYfuture=squeeze(YYvector_ml(jj,1:3-Tnew,:))';
    else
       YYfuture=squeeze(YYvector_ml(jj,1:3-Tnew,:)); 
    end
    
    if Tnew==3
    YYvector_ql(jj,1,:) = mean(YYnow);
    else
    YYvector_ql(jj,1,:) = mean([YYnow;YYfuture]);
    end
    
    YYvector_qg(jj,1,:) = ...
    100*(squeeze(YYvector_ql(jj,1,:))- mean([Ym(end-2:end,:) Yq(end-2:end,:)])');
    for bb=2:H/3
    YYvector_qg(jj,bb,:) = ...
    100*(squeeze(YYvector_ql(jj,bb,:))-squeeze(YYvector_ql(jj,bb-1,:)));
    end
    
%     %% 2) Now-/Forecasts fixing Federal Funds Rates 
%     vm_forecast_fix
%     % store in monthly frequency
%     FYYvector_ml(jj,:,:)  = FYYpred;    
%     FYYvector_mg(jj,:,:)  = 100*(FYYpred1(2:end,:)-FYYpred1(1:end-1,:));
%     % store forecasts in quarterly frequency
%     for ll=1:(H/3)-1
%     FYYvector_ql(jj,ll+1,:) = ...
%     mean(FYYvector_ml(jj,3*ll+1-Tnew:3*(ll+1)-Tnew,:));
%     end
%     
%     % store nowcasts in quarterly frequency
%     FYYnow=squeeze(YYactsim(jj,end-Tnew+1:end,:));
%     
%     if size(FYYnow,1) > size(FYYnow,2)
%         FYYnow = FYYnow';
%     end
%     
%     if size(squeeze(FYYvector_ml(jj,1:3-Tnew,:)),1)>...
%        size(squeeze(FYYvector_ml(jj,1:3-Tnew,:)),2)
%        FYYfuture=squeeze(FYYvector_ml(jj,1:3-Tnew,:))';
%     else
%        FYYfuture=squeeze(FYYvector_ml(jj,1:3-Tnew,:)); 
%     end
%     
%     if Tnew==3
%     FYYvector_ql(jj,1,:) = mean(FYYnow);
%     else
%     FYYvector_ql(jj,1,:) = mean([FYYnow;FYYfuture]);
%     end
%     
%     FYYvector_qg(jj,1,:) = ...
%     100*(squeeze(FYYvector_ql(jj,1,:))- mean([Ym(end-2:end,:) Yq(end-2:end,:)])');
%     for bb=2:H/3
%     FYYvector_qg(jj,bb,:) = ...
%     100*(squeeze(FYYvector_ql(jj,bb,:))-squeeze(FYYvector_ql(jj,bb-1,:)));
%     end
end