clc;
%% description
vartype     = {'Unemployment Rate','Hours Worked','Consumer Price Index',...
    'Industrial Production Index','Personal Consumption Expenditure',...
    'Federal Funds Rate','Treasury Bond Yield','SP 500',...
    'Gross Domestic Products','Fixed Investment'};
vartypel    = {'Unemployment Rate','Federal Funds Rate','Treasury Bond Yield'};
vartypeg    = {'Hours Worked','Consumer Price Index',...
    'Industrial Production Index','Personal Consumption Expenditure',...
    'Gross Domestic Products','Fixed Investment'};
vartypef    = {'T','T+1','T+4','T+20'};


indicator     = data_available(today_loc(1)-4:today_loc(1)-1,4:end)';
indicator_d   = trueYY(today_loc(1)-4:today_loc(1)-1,3:end)'; 
indicator_m   = squeeze(median(YYactsim))';
indicator_l95 = [yvecl95(13:14,:)' yvecl95(17,:)' yvecl95(33,:)'];
indicator_l80 = [yvecl80(13:14,:)' yvecl80(17,:)' yvecl80(33,:)'];
indicator_l50 = [yvecl50(13:14,:)' yvecl50(17,:)' yvecl50(33,:)'];
indicator_l20 = [yvecl20(13:14,:)' yvecl20(17,:)' yvecl20(33,:)'];
indicator_l05 = [yvecl05(13:14,:)' yvecl05(17,:)' yvecl05(33,:)'];
indicator_g95 = [yvecg95(13:14,:)' yvecg95(17,:)' yvecg95(33,:)'];
indicator_g80 = [yvecg80(13:14,:)' yvecg80(17,:)' yvecg80(33,:)'];
indicator_g50 = [yvecg50(13:14,:)' yvecg50(17,:)' yvecg50(33,:)'];
indicator_g20 = [yvecg20(13:14,:)' yvecg20(17,:)' yvecg20(33,:)'];
indicator_g05 = [yvecg05(13:14,:)' yvecg05(17,:)' yvecg05(33,:)'];



disp('=========================================================================');
disp('                                                                         ');
disp('                  MIXED FREQUENCY VAR: NOW-/FORECASTING                  ');
disp('                                                                         ');
disp('                             - SUMMARY -                                 ');
disp('                                                                         ');
disp(['                    Today : ',   num2str(today)                          ]);
disp(['                    Estimation Begins: ', num2str(index_YY(1,2:3))       ]);
disp(['                    Estimation Ends: ', num2str(index_YY(end,2:3))       ]);
disp(['                    Nowcasting Origin (T): ', num2str(today(2))          ]);
disp(['                    Forecasting Horizon : ', num2str(20)                 ]);
disp(['                    Number of Draws: ', num2str(nsim)                    ]);
disp('                                                                         ');
disp('=========================================================================');
disp(['                    Denote  T  :  ',    num2str(today(2))                ]);                                
disp(['                            1  :  ',    num2str('Available')             ]);  
disp(['                            0  :  ',    num2str('Not Available')         ]); 
disp('=========================================================================');
disp([' Variable Name                          T-4      T-3      T-2      T-1 ']);
disp('=========================================================================');
for hh=1:size(vartype,2);
    fprintf('%-32s %9.0f %8.0f %8.0f %8.0f\n',vartype{hh},indicator(hh,1),...
        indicator(hh,2),indicator(hh,3),indicator(hh,4));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('                         - AVAILABLE DATA -                              ');
disp('                                                                         ');
disp('             Note: All are log-transformed except Unemployment Rate,     ');
disp('                   Federal Funds Rate, Treasure Bonds Yield              ');
disp('=========================================================================');
disp([' Variable Name                          T-4      T-3      T-2      T-1 ']);
disp('=========================================================================');
for hh=1:size(vartype,2);
    fprintf('%-35s %8.2f %8.2f %8.2f %8.2f\n',vartype{hh},indicator_d(hh,1),...
        indicator_d(hh,2),indicator_d(hh,3),indicator_d(hh,4));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('            - NOWCAST CONDITIONING ON MODEL GENERATED DATASET -          ');
disp('                                                                         ');
disp('             Note: Look at the values that correspond to 0               ');
disp('                   These are the median latent values                    ');
disp('=========================================================================');
disp([' Variable Name                          T-4      T-3      T-2      T-1 ']);
disp('=========================================================================');
for hh=1:size(vartype,2);
    fprintf('%-35s %8.2f %8.2f %8.2f %8.2f\n',vartype{hh},indicator_m(hh,1),...
        indicator_m(hh,2),indicator_m(hh,3),indicator_m(hh,4));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('             - SUMMARY OF NOWCASTING AND FORECASTING RESULTS -           ');
disp('                                                                         ');
disp('                            -MEDIAN LEVEL -                              ');
disp('                                                                         ');
disp('                     Note: Numbers are multiplied by 100                 ');
disp('=========================================================================');
disp([' Variable Name                           T       T+1     T+4      T+20 ']);
disp('=========================================================================');
for hh=1:size(vartypel,2);
    fprintf('%-35s %8.2f %8.2f %8.2f %8.2f\n',vartypel{hh},indicator_l50(hh,1),...
        indicator_l50(hh,2),indicator_l50(hh,3),indicator_l50(hh,4));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('                        -MEDIAN GROWTH RATES -                           ');
disp('                                                                         ');
disp('                     Note: Growth Rates are annualized                   ');
disp('=========================================================================');
disp([' Variable Name                           T       T+1     T+4      T+20 ']);
disp('=========================================================================');
for hh=1:size(vartypeg,2);
    fprintf('%-35s %8.2f %8.2f %8.2f %8.2f\n',vartypeg{hh},indicator_g50(hh,1),...
        indicator_g50(hh,2),indicator_g50(hh,3),indicator_g50(hh,4));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('                         - Unemployment Rate -                           ');
disp('                                                                         ');
disp('=========================================================================');
disp([' Forecast Horizon             5%       20%      50%      80%      95%  ']);
disp('=========================================================================');
for hh=1:size(vartypef,2);
    fprintf('%-25s %7.2f %8.2f %8.2f %8.2f %8.2f\n',vartypef{hh},indicator_l05(1,hh),...
        indicator_l20(1,hh),indicator_l50(1,hh),indicator_l80(1,hh),indicator_l95(1,hh));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('                - Hours Worked Annualized Growth Rate -                  ');
disp('                                                                         ');
disp('=========================================================================');
disp([' Forecast Horizon             5%       20%      50%      80%      95%  ']);
disp('=========================================================================');
for hh=1:size(vartypef,2);
    fprintf('%-25s %7.2f %8.2f %8.2f %8.2f %8.2f\n',vartypef{hh},indicator_g05(1,hh),...
        indicator_g20(1,hh),indicator_g50(1,hh),indicator_g80(1,hh),indicator_g95(1,hh));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('              - Consumer Price Index Annualized Growth Rate -            ');
disp('                                                                         ');
disp('=========================================================================');
disp([' Forecast Horizon             5%       20%      50%      80%      95%  ']);
disp('=========================================================================');
for hh=1:size(vartypef,2);
    fprintf('%-25s %7.2f %8.2f %8.2f %8.2f %8.2f\n',vartypef{hh},indicator_g05(2,hh),...
        indicator_g20(2,hh),indicator_g50(2,hh),indicator_g80(2,hh),indicator_g95(2,hh));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('      - Personal Consumption Expenditure Annualized Growth Rate -        ');
disp('                                                                         ');
disp('=========================================================================');
disp([' Forecast Horizon             5%       20%      50%      80%      95%  ']);
disp('=========================================================================');
for hh=1:size(vartypef,2);
    fprintf('%-25s %7.2f %8.2f %8.2f %8.2f %8.2f\n',vartypef{hh},indicator_g05(4,hh),...
        indicator_g20(4,hh),indicator_g50(4,hh),indicator_g80(4,hh),indicator_g95(4,hh));    
end
disp('=========================================================================');
disp('                                                                         ');
disp('           - Gross Domestic Products Annualized Growth Rate -            ');
disp('                                                                         ');
disp('=========================================================================');
disp([' Forecast Horizon             5%       20%      50%      80%      95%  ']);
disp('=========================================================================');
for hh=1:size(vartypef,2);
    fprintf('%-25s %7.2f %8.2f %8.2f %8.2f %8.2f\n',vartypef{hh},indicator_g05(5,hh),...
        indicator_g20(5,hh),indicator_g50(5,hh),indicator_g80(5,hh),indicator_g95(5,hh));    
end
disp('=========================================================================');