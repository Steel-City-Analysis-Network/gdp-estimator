function mdd = vm_mdd_all4_v2(lstate,zmddsim,nsim,nobs,densfac)
Nq    = size(lstate,2);

lstate0  = lstate(:,:,1:nobs);
pick     = repmat([1 1 0],1,nobs/3);
lstate1  = lstate0(:,:,pick==1);
NN       = size(lstate1,3);
lstate2  = reshape(lstate1,nsim,Nq*NN);
parasim  = lstate2(0.5*nsim+1:end,:);
zmddsim  = zmddsim(0.5*nsim+1:end,:);


%==========================================================================
% Computation of the marginal likelihood 
%==========================================================================

%==========================================================================
% default parameters
%==========================================================================

% for data density (modified harmonic mean)
%densfac = 4000;
hmax    = 20;

%==========================================================================
% means and standard deviations
%==========================================================================

% initialize output
ndraws     = 0;
drawmean   = 0;
drawsqmean = 0;
sumdrawsq  = 0;
	 
postsim = zmddsim;
     
% number of simulations in each block
nsimul = size(parasim,1);
npara  = size(parasim,2);
% collect simulations
drawblock = parasim;
drawdim   = size(drawblock,2);

% compute sums of x(i) and x(i)^2 to be used to calculate means and s.d.
drawmean   = drawmean + sum(drawblock,1);
drawsqmean = drawsqmean + sum(drawblock.^2,1);
sumdrawsq  = sumdrawsq + parasim'*parasim;
ndraws     = ndraws + nsimul;

% compute means and standard deviations
drawmean   = drawmean/ndraws;
drawsqmean = drawsqmean/ndraws;
drawstdd   = sqrt(drawsqmean - drawmean.^2);
drawsig    = sumdrawsq/ndraws - drawmean'*drawmean;

[up sp vp] = svd(drawsig);
drawsiginv = zeros(size(drawsig));
drawsigdet = zeros(size(drawsig));

for j=1:size(drawsig,1)
    if drawsig(j,j) > 1e-6
        drawsiginv(j,j) = 1./sp(j,j);
        drawsigdet(j,j) = sp(j,j);
    else
        drawsigdet(j,j) = 1;
    end
end

drawsiglndet = sum(log(diag(drawsigdet)));
drawsiginv   = (up*drawsiginv*vp')' ;
% drawsiglndet = log(det(drawsig));

%==========================================================================
% marginal data density:  modified harmonic mean by Geweke (1999)
%==========================================================================

p = (.1:.1:.9)';
pcrit = chi2inv(p,ones(length(p),1)*npara);

ndraws  = 0;
suminvlike = zeros(length(p),1);
laginvlike = zeros(hmax,length(p));
gaminvlike = zeros(hmax,length(p));
	    
% number of simulations in each block
[nsimul,npara] = size(parasim);				

paradev  = parasim-repmat(drawmean,nsimul,1);
quadpara = sum((paradev*drawsiginv).*paradev,2);

% simulation loop
for j=1:nsimul
	lnfpara = - 0.5*npara*log(2*pi) - 0.5*drawsiglndet - 0.5*quadpara(j) - log(p);
	indpara = (quadpara(j)<pcrit);
	invlike = exp(lnfpara - postsim(j) + densfac).*indpara;

	laginvlike = [invlike' ; laginvlike(1:hmax-1,:)];
	gaminvlike = gaminvlike + laginvlike.*repmat(invlike',hmax,1);
	suminvlike = suminvlike + invlike;
end	% simulation loop

ndraws = ndraws + nsimul;

meaninvlike = suminvlike/ndraws;
%gaminvlike  = gaminvlike/ndraws - repmat((meaninvlike.^2)',hmax,1);

% % standard error
% suminvlikeerror = gaminvlike(1,:);
% for k=2:hmax
%    suminvlikeerror = suminvlikeerror + 2*gaminvlike(k,:)*(1-(k-1)/hmax);
% end
% 
% suminvlikeerror = 100*sqrt(suminvlikeerror/ndraws)./meaninvlike' ;

% marginalized data density
mdd = densfac-log(meaninvlike);
%mdd = [p mdd];

mdd = mean(mdd);