function [mdd store1 store2 index] = vm_mdd_all(parasim,likesim,priorsim,nsim,densfac,sD)
rng(sD);

parasim  = parasim(0.5*nsim+1:end,:);
likesim  = likesim(0.5*nsim+1:end,:);
priorsim = priorsim(0.5*nsim+1:end,:);


%==========================================================================%
% Computation of the marginal likelihood 
%==========================================================================

%==========================================================================
% default parameters
%==========================================================================

block1   = 1;		% starting block
blockn   = 1;		% ending block

% for data density (modified harmonic mean)
%densfac = 5150;
hmax    = 20;

%==========================================================================
% means and standard deviations
%==========================================================================

% initialize output
ndraws     = 0;
drawmean   = 0;
drawsqmean = 0;
sumdrawsq  = 0;

% loop for block
for jblock=block1:blockn
	 
    postsim = likesim+priorsim(:,1)+priorsim(:,2);
     
    % number of simulations in each block
	nsimul = size(parasim,1);
    npara  = size(parasim,2);
	% collect simulations
	drawblock = parasim;
	drawdim   = size(drawblock,2);

	% compute sums of x(i) and x(i)^2 to be used to calculate means and s.d.
	drawmean   = drawmean + sum(drawblock,1);
	drawsqmean = drawsqmean + sum(drawblock.^2,1);
	sumdrawsq  = sumdrawsq + parasim'*parasim;
	ndraws     = ndraws + nsimul;

end

% compute means and standard deviations
drawmean   = drawmean/ndraws;
drawsqmean = drawsqmean/ndraws;
drawstdd   = sqrt(drawsqmean - drawmean.^2);

drawsig    = sumdrawsq/ndraws - drawmean'*drawmean;

[up sp vp] = svd(drawsig);
drawsiginv = zeros(size(drawsig));
drawsigdet = zeros(size(drawsig));

for j=1:size(drawsig,1)
    if drawsig(j,j) > 1e-12
        drawsiginv(j,j) = 1./sp(j,j);
        drawsigdet(j,j) = sp(j,j);
    else
        drawsigdet(j,j) = 1;
    end
end

drawsiglndet = sum(log(diag(drawsigdet)));
drawsiginv   = (up*drawsiginv*vp')' ;

% drawsiglndet = log(det(drawsig));

% drawsig    = sumdrawsq/ndraws - drawmean'*drawmean;
% 
% % check diagonal elements 
% for j=1:size(drawsig,1)
% 	if drawsig(j,j) < 1E-6
% 		drawsig(j,j) = 1E-6;
% 	end
% end
% 
% tol = 1e-6;
% [up sp vp] = svd(drawsig);
% invsp = zeros(size(sp,1),size(sp,1));
% detsp = zeros(size(sp,1),size(sp,1));
% for rr=1:size(sp,1)
%     if sp(rr,rr)> tol;
%         invsp(rr,rr)=1./sp(rr,rr);
%         detsp(rr,rr)=sp(rr,rr);
%     else
%         detsp(rr,rr)=1;
%     end    
% end
% 
% drawsiginv   = (up*invsp*vp')';
% drawsiglndet = log(det(detsp));

%==========================================================================
% marginal data density:  modified harmonic mean by Geweke (1999)
%==========================================================================

p = (.1:.1:.9)';
pcrit = chi2inv(p,ones(length(p),1)*npara);

ndraws  = 0;
suminvlike = zeros(length(p),1);
laginvlike = zeros(hmax,length(p));
gaminvlike = zeros(hmax,length(p));

store1 = zeros(nsimul,length(p));
store2 = zeros(nsimul,length(p));

index = zeros(nsimul,length(p));




% loop for block
for jblock=block1:blockn

	    
    % number of simulations in each block
	[nsimul,npara] = size(parasim);				

	paradev  = parasim-repmat(drawmean,nsimul,1);
	quadpara = sum((paradev*drawsiginv).*paradev,2);
% 
%     densfac = - 0.5*npara*log(2*pi) - 0.5*drawsiglndet - 0.5*quadpara(1) - log(p) - postsim(1);
%     densfac = -mean(densfac);

	% simulation loop
	for j=1:nsimul
		lnfpara = - 0.5*npara*log(2*pi) - 0.5*drawsiglndet - 0.5*quadpara(j) - log(p);
		indpara = (quadpara(j)<pcrit);
		invlike = exp(lnfpara - postsim(j) + densfac).*indpara;

        store1(j,:) = (lnfpara );
        store2(j,:) = (postsim(j));
        index(j,:) = indpara;
    
		laginvlike = [invlike' ; laginvlike(1:hmax-1,:)];
		gaminvlike = gaminvlike + laginvlike.*repmat(invlike',hmax,1);
		suminvlike = suminvlike + invlike;
	end	% simulation loop

	ndraws = ndraws + nsimul;

end	% loop for blocks

meaninvlike = suminvlike/ndraws;
gaminvlike  = gaminvlike/ndraws - repmat((meaninvlike.^2)',hmax,1);


% standard error
suminvlikeerror = gaminvlike(1,:);
for k=2:hmax
   suminvlikeerror = suminvlikeerror + 2*gaminvlike(k,:)*(1-(k-1)/hmax);
end

suminvlikeerror = 100*sqrt(suminvlikeerror/ndraws)./meaninvlike' ;

% marginalized data density
mdd = densfac-log(meaninvlike);
%mdd = [p mdd];

mdd = mean(mdd);