    frs_sample = nan(size(var(9).rsdata,1),11);
    frs_nobs   = [];
    frs_fdata  = [];
    frs_fsub   = [];
    
    for kk=1:length(var)
        
        if kk<4
            frs_sub   = kron(var(kk).rsdata(:,frrr),ones(3,1));         
            frs_T     = max(find(~isnan(frs_sub)));
        else
            frs_sub   = var(kk).rsdata(:,frrr);
            frs_T     = max(find(~isnan(frs_sub)));
        end
                
        frs_sample(1:length(frs_sub),kk) = frs_sub;
        frs_nobs   = [frs_nobs frs_T];
    end
    
    for kk=1:length(var)        
        
        if kk>3
            frs_fmsub = var(kk).fdata(min(frs_nobs)-2:min(frs_nobs)+24,frrr);
            frs_fsub  = zeros(size(frs_fmsub,1)/3,1);
            for ii=1:size(frs_fsub,1)
                frs_fsub(ii)=mean(frs_fmsub(3*(ii-1)+1:3*ii));
            end
        else
            if min(frs_nobs)<frs_nobs(1)
                min_nobs = frs_nobs(1);
            else
                min_nobs = min(frs_nobs);
            end
            frs_fsub  = var(kk).fdata(min_nobs/3:min_nobs/3+8,frrr);            
        end
        
        frs_fdata  = [frs_fdata frs_fsub]; 
        frs_flvl   = frs_fdata(2:end,:);
        frs_fgrth  = 100*(frs_fdata(2:end,:)-frs_fdata(1:end-1,:)); 
      
    end
        % temporary definition
        frs_flvl   = [frs_flvl(:,4:end) frs_flvl(:,1:3)];
        frs_fgrth  = [frs_fgrth(:,4:end) frs_fgrth(:,1:3)];
        
    YQ      = frs_sample(:,1:3);
    YM      = frs_sample(:,4:end);   
    YDATA0  = [YM YQ];
    
    YDATA   = YDATA0(1:min(frs_nobs),:);
    
    YYY  = zeros(frs_nobs(1)/3,11);
    for gg=1:frs_nobs(1)/3
        YYY(gg,:) = mean(YDATA(3*(gg-1)+1:3*gg,:));
    end            