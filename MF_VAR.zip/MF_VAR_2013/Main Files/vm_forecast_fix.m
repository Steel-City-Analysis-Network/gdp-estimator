%==========================================================================
%              BAYESIAN ESTIMATION: FORECASTING                  
%==========================================================================

FYYpred              = zeros(H+1,nv);     % forecasts from VAR
FYYpred(1,:)         = YYact;
FXXpred              = zeros(H+1,(nv)*nlags+1);
FXXpred(:,end)       = ones(H+1,1);
FXXpred(1,:)         = XXact;

%==========================================================================   
%          given posterior draw, draw #{H+1} random sequence
%==========================================================================

Ferror_pred = zeros(H+1,nv);     
    
for h=1:H+1
        
    Ferror_pred(h,:) = mvnrnd(zeros(nv,1), post_sig);         
        
end

%==========================================================================   
%       given posterior draw, iterate forward to construct forecasts
%==========================================================================
    
for h=2:2
        
    FXXpred(h,nv+1:end-1) = FXXpred(h-1,1:end-nv-1);
    FXXpred(h,1:nv)       = FYYpred(h-1,:);
    FYYpred(h,:)          = FXXpred(h,:)*post_phi+Ferror_pred(h,:);
    
end

% change elements in YYpred(2,6) to prespecified number
FYYpred(2,6) = setff;

% change elements in post_phi associated with federal funds rates
post_phi(:,6) = zeros(length(post_phi),1);
post_phi(6,:) = zeros(1,size(post_phi,2));
post_phi(6,6) = 1;

for h=3:H+1
        
    FXXpred(h,nv+1:end-1) = FXXpred(h-1,1:end-nv-1);
    FXXpred(h,1:nv)       = FYYpred(h-1,:);
    FYYpred(h,:)          = FXXpred(h,:)*post_phi+Ferror_pred(h,:);
    
end

FYYpred1     = FYYpred;
FYYpred      = FYYpred(2:end,:);

