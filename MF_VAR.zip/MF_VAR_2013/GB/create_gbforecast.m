base='C:\Users\Dongho\Documents\RTMFVAR\GB\';
dpath=[base,''];

%Specify Whether you are comparing to Greenbook or BlueChip forecast
if ~exist('judge','var');
    judge='GB';%GB or 'BC'
end


%% %%%%%%%%%%%%%%%%%% READ IN EXCEL FILES %%%%%%%%%%%%%%%%%%%%%%%%% 

fvar=struct('name',{'GDPC1GBFP_2', 'CPIAUCSLGBFP_2', 'UNRATEGBF_2'},'source',...
           {'NIPA', 'NIPA', 'EES'});

%% BC always occur the 10th of each month --> create vector of forecast dates for judgemental forecasts
if strcmp(judge,'BC');

  %% datenum is matlab function that formats dates
  dt=[reshape(repmat(1992:2011,12,1),[],1),repmat((1:12)',20,1),repmat(10,12*20,1)];
  vdates=nan(size(dt,1),1);
  for i=1:length(vdates);
      vdates(i)=datenum(dt(i,:));
  end
  %% a = 2 -- BC
  a=2;  
else
  %% a = 1 -- GB
  a=1;  
end;

lastdates=nan(length(fvar)-1,1);%preallocate "lastdate" matrix;
firstdates=nan(length(fvar)-1,1);
for i=a:length(fvar);
  
  %% var(i).name is GB.xls (forecast dates), GDP.xls, et cetera
  
  %% number of sheets in xls file (vintages are stored in multiple sheets, and number of sheets varies across variables)
  [~, sheets]=xlsfinfo([dpath,fvar(i).name,'.xls']);
  
  
  %% D is data, E is vintage dates (date associated with release of that data)
  D=[];E=[];
  
  %% first sheet is just info (source, etc.), from sheet 2 data start
  %% load data sheet by sheet, and concatenate them (making sure all vintages have the same length)
  for j=2:length(sheets);
    %% for each sheet, reading all vintages in that sheet, data and `headings' (observation dates and vintage dates)
    [data1,fvar(i).headings]=xlsread([dpath,fvar(i).name,'.xls'],j);

    %% appending to fvar(i).data
    %% making sure all vintages have the same length
    fvar(i).data=[D,[data1;nan(size(fvar(i).headings)-[size(data1,1)+1,1])]];
    
    %% D is all fvar(i).data (all sheet) up to j
    D=fvar(i).data;
    
    %% appending to vdate
    vdate=char([E, fvar(i).headings(1,2:end)]);
    %% E is all vintage dates up to sheet j
    E=vdate;
  end;  
  
    %% at this point, fvar(i).data has all data, vdate has all vintage dates
   
  %% for variables for which we have data before 1/1/94, chop them off
  %limit to observations after 1994
  d=find(strcmp(fvar(i).headings,'1/1/1994'));
  if isempty(d)
    d=2;
  end;
  fvar(i).odate=datenum(char(fvar(i).headings(d:end,1)));
  fvar(i).vdate=datenum(vdate(:,((end-7):end)),'yyyymmdd');
  fvar(i).data=fvar(i).data(d-1:end,:);
  
  if i>1;
    lastdates(i-1)=fvar(i).vdate(end);
    firstdates(i-1)=fvar(i).vdate(1);
  end
end;

for i=1:length(fvar)
    fvar(i).gdate = fvar(i).vdate(find(datenum('3/17/94')==fvar(i).vdate):end);
    gbdata0 = fvar(i).data(:,find(datenum('3/17/94')==fvar(i).vdate):end);
    gbdatai = ~isnan(gbdata0);
    endloc  = max(sum(gbdatai));
    gbdata  = nan(endloc,size(gbdata0,2));
    
    for j=1:size(gbdata0,2)
        minloc = min(find(~isnan(gbdata0(:,j))));
        maxloc = max(find(~isnan(gbdata0(:,j))));
        gbdata(:,j) = [gbdata0(minloc:maxloc,j);nan(endloc-size(gbdata0(minloc:maxloc,j),1),1)];
    end
    fvar(i).gbdata = gbdata;
end
    
% unrate: missing date at 6/26/96    
