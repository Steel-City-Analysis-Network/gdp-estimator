%======================================================================
%                    BAYESIAN ESTIMATION OF VAR
%======================================================================
disp('                                                                ');
disp('                    MIXED FREQUENCY VAR: ESTIMATION             ');
disp('                                                                ');

%======================================================================
%                          HYPERPARAMETERS
%======================================================================
% load hyp.txt;           % selected hyperparameters from BVAR_PRIOR
% 
% lambda1=hyp(1);lambda2=hyp(2);lambda3=hyp(3);lambda4=hyp(4);lambda5=hyp(5);

%======================================================================
%                     BLOCK 1: PARAMETER ESTIMATION 
%======================================================================

% Matrices for collecting draws from Posterior Density

Sigmap    = zeros(nsim,nv,nv);
Phip      = zeros(nsim,nv*p+1,nv);
Cons      = zeros(nsim,nv);
lstate    = zeros(nsim,Nq,Tnobs);
YYactsim  = zeros(nsim,4,nv);
XXactsim  = zeros(nsim,4,nv*p+1);
likesim   = zeros(nsim,1);
zmddsim   = zeros(nsim,1);    
priorsim  = zeros(nsim,2);
parasim   = zeros(nsim,(nv*p+1)*nv+nv*(nv+1)/2);
At_mat    = zeros(Tnobs,Nq*(p+1));
Pt_mat    = zeros(Tnobs,(Nq*(p+1))^2);
Atildemat = zeros(nsim,Nq*(p+1));
Ptildemat = zeros(nsim,Nq*(p+1),Nq*(p+1));
loglh   = 0;
counter = 0;


%% Define Coefficient Matrices
% Define phi(qm), phi(qq), phi(qc)
phi_qm = zeros(Nm*p,Nq);
for i=1:p
    phi_qm(Nm*(i-1)+1:Nm*i,:)=Phi((i-1)*(Nm+Nq)+1:(i-1)*(Nm+Nq)+Nm,Nm+1:end);
end
phi_qq = zeros(Nq*p,Nq);
for i=1:p
    phi_qq(Nq*(i-1)+1:Nq*i,:)=Phi((i-1)*(Nm+Nq)+Nm+1:i*(Nm+Nq),Nm+1:end);
end
phi_qc = Phi(end,Nm+1:end);

% Define phi(mm), phi(mq), phi(mc)
phi_mm = zeros(Nm*p,Nm);
for i=1:p
    phi_mm(Nm*(i-1)+1:Nm*i,:)=Phi((i-1)*(Nm+Nq)+1:(i-1)*(Nm+Nq)+Nm,1:Nm);
end
phi_mq = zeros(Nq*p,Nm);
for i=1:p
    phi_mq(Nq*(i-1)+1:Nq*i,:)=Phi((i-1)*(Nm+Nq)+Nm+1:i*(Nm+Nq),1:Nm);
end
phi_mc = Phi(end,1:Nm);

% Define Covariance Term sig_mm, sig_mq, sig_qm, sig_qq
sig_mm  = sigma(1:Nm,1:Nm);
sig_mq  = 0.5*(sigma(1:Nm,Nm+1:end)+sigma(Nm+1:end,1:Nm)');
sig_qm  = 0.5*(sigma(Nm+1:end,1:Nm)+sigma(1:Nm,Nm+1:end)');
sig_qq  = sigma(Nm+1:end,Nm+1:end);

% Define Transition Equation Matrices
GAMMAs  = [[phi_qq' zeros(Nq,Nq)];[eye(p*Nq,p*Nq) zeros(p*Nq,Nq)]];
GAMMAz  = [phi_qm'; zeros(p*Nq,p*Nm)];
GAMMAc  = [phi_qc'; zeros(p*Nq,1)];
GAMMAu  = [eye(Nq); zeros(p*Nq,Nq)];

% Define Measurement Equation Matrices
LAMBDAs = [[zeros(Nm,Nq) phi_mq'];(1/3)*[eye(Nq) eye(Nq) eye(Nq) zeros(Nq,Nq*(p-2))]];
LAMBDAz = [phi_mm'; zeros(Nq,p*Nm)];
LAMBDAc = [phi_mc'; zeros(Nq,1)];
LAMBDAu = [eye(Nm); zeros(Nq,Nm)];

% Define W matrix
Wmatrix   = [eye(Nm) zeros(Nm,Nq)];
LAMBDAs_t = Wmatrix * LAMBDAs;
LAMBDAz_t = Wmatrix * LAMBDAz;
LAMBDAc_t = Wmatrix * LAMBDAc;
LAMBDAu_t = Wmatrix * LAMBDAu;

%% Initialization   
init_var  = zeros(Nq*(p+1),Nq*(p+1));
for kk=1:p+1
    init_var = GAMMAs * init_var * GAMMAs' + GAMMAu * sig_qq * GAMMAu';
end

Zm_init   = zeros(T0-p-1,Nm*p);
i=1;
while i<=p
    Zm_init(:,(i-1)*Nm+1:i*Nm) = YM(p+1-(i-1):T0-i,:);
    i=i+1;
end

[init_At,init_Pt] = vm_initialize(GAMMAs,GAMMAz,GAMMAc,GAMMAu,...
LAMBDAs,LAMBDAz,LAMBDAc,LAMBDAu,LAMBDAs_t,LAMBDAz_t,LAMBDAc_t,LAMBDAu_t,...
sig_qq,sig_mm,sig_qm,sig_mq,Zm_init,YDATA,init_mean,init_var,spec_init);

%% Set Dataset
% Lagged Monthly Observations
Zm   = zeros(nobs,Nm*p);
i=1;
while i<=p
    Zm(:,(i-1)*Nm+1:i*Nm) = YM(T0-(i-1):T0+nobs-i,:);
    i=i+1;
end

% Observations in Monthly Freq
Yq   = YQ(T0+1:nobs+T0,:);
Ym   = YM(T0+1:nobs+T0,:);

%% Estimation
MF_BVAR_MAIN_SUB