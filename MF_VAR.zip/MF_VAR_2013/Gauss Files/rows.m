function d=rows(A)

d=size(A,1);
end