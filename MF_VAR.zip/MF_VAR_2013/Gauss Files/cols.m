function c=cols(A)

c=size(A,2);
end
