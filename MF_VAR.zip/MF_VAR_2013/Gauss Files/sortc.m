function BB=sortc(AA)

[B IX]=sort(AA(:,2),1);
BB=[IX B];
