%% recursive sample: 7/31/97 - 1/31/10: 151 total
% discrepancy between GB closed dates and projection dates
% 1/31/96: December CPI release NOT yet available: USE 2/1/96 release  
% definition of {0,1,2}:
% var(1) var(2) var(3) var(4): let var(1) be the only QF variable
%   0     +2      +2     +3  : denote as "0" : 3rd release  
%   0      0       0     +1  : denote as "1" : 1st release
%   0     +1      +1     +2  : denote as "2" : 2nd release
%

load results_RS_AR2.mat    
load results_RS_QFBVAR.mat  
load results_RS_MFBVAR.mat

nrs = 151;

% SS_index starts from 1994:M3, but we want to use it from 1997:M7
%SS_index = SS_index(38:nrs+37);
SS_index = SS_index(38:38+nrs-1);
SS_index(28)  = 4;
SS_index(29)  = 4;
SS_index(33)  = 4;
SS_index(145) = 4;

% store RMSE_vector: 
RMSE_MF2_G_vector = zeros(sum(SS_index==2),8,11);
RMSE_MF2_L_vector = zeros(sum(SS_index==2),8,11);
FG2_vector        = FG_vector((SS_index==2)==1,:,:);
FL2_vector        = FL_vector((SS_index==2)==1,:,:);
RMSE_MF0_G_vector = zeros(sum(SS_index==0),8,11);
RMSE_MF0_L_vector = zeros(sum(SS_index==0),8,11);
FG0_vector        = FG_vector((SS_index==0)==1,:,:);
FL0_vector        = FL_vector((SS_index==0)==1,:,:);
RMSE_MF1_G_vector = zeros(sum(SS_index==1),8,11);
RMSE_MF1_L_vector = zeros(sum(SS_index==1),8,11);
FG1_vector        = FG_vector((SS_index==1)==1,:,:);
FL1_vector        = FL_vector((SS_index==1)==1,:,:);

RMSE_QF2_G_vector = zeros(sum(SS_index==2),8,11);
RMSE_QF2_L_vector = zeros(sum(SS_index==2),8,11);
RMSE_QF0_G_vector = zeros(sum(SS_index==0),8,11);
RMSE_QF0_L_vector = zeros(sum(SS_index==0),8,11);
RMSE_QF1_G_vector = zeros(sum(SS_index==1),8,11);
RMSE_QF1_L_vector = zeros(sum(SS_index==1),8,11);

RMSE_AR2_G_vector = zeros(sum(SS_index==2),8,11);
RMSE_AR2_L_vector = zeros(sum(SS_index==2),8,11);
RMSE_AR0_G_vector = zeros(sum(SS_index==0),8,11);
RMSE_AR0_L_vector = zeros(sum(SS_index==0),8,11);
RMSE_AR1_G_vector = zeros(sum(SS_index==1),8,11);
RMSE_AR1_L_vector = zeros(sum(SS_index==1),8,11);

FG2_vector50 = FG_vector50((SS_index==2)==1,:,:);
FL2_vector50 = FL_vector50((SS_index==2)==1,:,:);
FG0_vector50 = FG_vector50((SS_index==0)==1,:,:);
FL0_vector50 = FL_vector50((SS_index==0)==1,:,:);
FG1_vector50 = FG_vector50((SS_index==1)==1,:,:);
FL1_vector50 = FL_vector50((SS_index==1)==1,:,:);

FGQ2_vector50 = FGQ_vector50((SS_index==2)==1,:,:);
FLQ2_vector50 = FLQ_vector50((SS_index==2)==1,:,:);
FGQ0_vector50 = FGQ_vector50((SS_index==0)==1,:,:);
FLQ0_vector50 = FLQ_vector50((SS_index==0)==1,:,:);
FGQ1_vector50 = FGQ_vector50((SS_index==1)==1,:,:);
FLQ1_vector50 = FLQ_vector50((SS_index==1)==1,:,:);

FGA2_vector50 = FGA_vector50((SS_index==2)==1,:,:);
FLA2_vector50 = FLA_vector50((SS_index==2)==1,:,:);
FGA0_vector50 = FGA_vector50((SS_index==0)==1,:,:);
FLA0_vector50 = FLA_vector50((SS_index==0)==1,:,:);
FGA1_vector50 = FGA_vector50((SS_index==1)==1,:,:);
FLA1_vector50 = FLA_vector50((SS_index==1)==1,:,:);

for j=1:11
for ii=1:sum(SS_index==2)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF2_G_vector(ii,:,j) = ((4*FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);
    RMSE_MF2_L_vector(ii,:,j) = ((100*FL2_vector50(ii,:,j)-100*FL2_vector(ii,:,j)).^2);       
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF2_G_vector(ii,:,j)  = ((4*FGQ2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);
    RMSE_QF2_L_vector(ii,:,j)  = ((100*FLQ2_vector50(ii,:,j)-100*FL2_vector(ii,:,j)).^2);

    % AR2 RMSE COMPUTATION
    RMSE_AR2_G_vector(ii,:,j)  = ((4*FGA2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);
    RMSE_AR2_L_vector(ii,:,j)  = ((100*FLA2_vector50(ii,:,j)-100*FL2_vector(ii,:,j)).^2);    
end
end

for j=1:11
for ii=1:sum(SS_index==0)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF0_G_vector(ii,:,j) = ((4*FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);
    RMSE_MF0_L_vector(ii,:,j) = ((100*FL0_vector50(ii,:,j)-100*FL0_vector(ii,:,j)).^2);       
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF0_G_vector(ii,:,j)  = ((4*FGQ0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);
    RMSE_QF0_L_vector(ii,:,j)  = ((100*FLQ0_vector50(ii,:,j)-100*FL0_vector(ii,:,j)).^2);

    % AR2 RMSE COMPUTATION
    RMSE_AR0_G_vector(ii,:,j)  = ((4*FGA0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);
    RMSE_AR0_L_vector(ii,:,j)  = ((100*FLA0_vector50(ii,:,j)-100*FL0_vector(ii,:,j)).^2);    
end
end

for j=1:11
for ii=1:sum(SS_index==1)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF1_G_vector(ii,:,j) = ((4*FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);
    RMSE_MF1_L_vector(ii,:,j) = ((100*FL1_vector50(ii,:,j)-100*FL1_vector(ii,:,j)).^2);       
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF1_G_vector(ii,:,j)  = ((4*FGQ1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);
    RMSE_QF1_L_vector(ii,:,j)  = ((100*FLQ1_vector50(ii,:,j)-100*FL1_vector(ii,:,j)).^2);

    % AR2 RMSE COMPUTATION
    RMSE_AR1_G_vector(ii,:,j)  = ((4*FGA1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);
    RMSE_AR1_L_vector(ii,:,j)  = ((100*FLA1_vector50(ii,:,j)-100*FL1_vector(ii,:,j)).^2);    
end
end



RMSE_MF2_G = sqrt(squeeze(mean(RMSE_MF2_G_vector)));
RMSE_MF0_G = sqrt(squeeze(mean(RMSE_MF0_G_vector)));
RMSE_MF1_G = sqrt(squeeze(mean(RMSE_MF1_G_vector)));
RMSE_QF2_G = sqrt(squeeze(mean(RMSE_QF2_G_vector)));
RMSE_QF0_G = sqrt(squeeze(mean(RMSE_QF0_G_vector)));
RMSE_QF1_G = sqrt(squeeze(mean(RMSE_QF1_G_vector)));
RMSE_AR2_G = sqrt(squeeze(mean(RMSE_AR2_G_vector)));
RMSE_AR0_G = sqrt(squeeze(mean(RMSE_AR0_G_vector)));
RMSE_AR1_G = sqrt(squeeze(mean(RMSE_AR1_G_vector)));

RMSE_MF2_L = sqrt(squeeze(mean(RMSE_MF2_L_vector)));
RMSE_MF0_L = sqrt(squeeze(mean(RMSE_MF0_L_vector)));
RMSE_MF1_L = sqrt(squeeze(mean(RMSE_MF1_L_vector)));
RMSE_QF2_L = sqrt(squeeze(mean(RMSE_QF2_L_vector)));
RMSE_QF0_L = sqrt(squeeze(mean(RMSE_QF0_L_vector)));
RMSE_QF1_L = sqrt(squeeze(mean(RMSE_QF1_L_vector)));
RMSE_AR2_L = sqrt(squeeze(mean(RMSE_AR2_L_vector)));
RMSE_AR0_L = sqrt(squeeze(mean(RMSE_AR0_L_vector)));
RMSE_AR1_L = sqrt(squeeze(mean(RMSE_AR1_L_vector)));

scrsz = get(0,'ScreenSize');

fig=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.2]);
subplot(2,2,1);
hold on;
plot(100*(RMSE_MF1_G(1:8,9)-RMSE_QF1_G(1:8,9))./RMSE_QF1_G(1:8,9),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_G(1:8,9)-RMSE_QF2_G(1:8,9))./RMSE_QF2_G(1:8,9),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_G(1:8,9)-RMSE_QF0_G(1:8,9))./RMSE_QF0_G(1:8,9),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('GDP Growth','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -30 5])
%axis([1 8 min(100*(RMSE_MF0_G(1:8,9)-RMSE_QF0_G(1:8,9))./RMSE_QF0_G(1:8,9)) 1.1]);
set(gca,'FontSize',15)

subplot(2,2,3);
hold on;
hold on;
plot(100*(RMSE_MF1_G(1:8,3)-RMSE_QF1_G(1:8,3))./RMSE_QF1_G(1:8,3),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_G(1:8,3)-RMSE_QF2_G(1:8,3))./RMSE_QF2_G(1:8,3),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_G(1:8,3)-RMSE_QF0_G(1:8,3))./RMSE_QF0_G(1:8,3),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Inflation','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -70 5])
%axis([1 8 min(100*(RMSE_MF0_G(1:8,3)-RMSE_QF0_G(1:8,3))./RMSE_QF0_G(1:8,3)) 1.1]);
set(gca,'FontSize',15)

subplot(2,2,2);
hold on;
plot(100*(RMSE_MF1_L(1:8,1)-RMSE_QF1_L(1:8,1))./RMSE_QF1_L(1:8,1),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_L(1:8,1)-RMSE_QF2_L(1:8,1))./RMSE_QF2_L(1:8,1),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_L(1:8,1)-RMSE_QF0_L(1:8,1))./RMSE_QF0_L(1:8,1),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Unemployment Rate','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -70 5])
%axis([1 8 min(100*(RMSE_MF0_L(1:8,1)-RMSE_QF0_L(1:8,1))./RMSE_QF0_L(1:8,1)) 1.1]);
set(gca,'FontSize',15)

subplot(2,2,4);
hold on;
plot(100*(RMSE_MF1_L(1:8,6)-RMSE_QF1_L(1:8,6))./RMSE_QF1_L(1:8,6),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_L(1:8,6)-RMSE_QF2_L(1:8,6))./RMSE_QF2_L(1:8,6),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_L(1:8,6)-RMSE_QF0_L(1:8,6))./RMSE_QF0_L(1:8,6),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Federal Funds Rate','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -100 5])
%axis([1 8 min(100*(RMSE_MF0_L(1:8,6)-RMSE_QF0_L(1:8,6))./RMSE_QF0_L(1:8,6)) 1.1]);
set(gca,'FontSize',15)

%%



fig2=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.2]);
subplot(2,2,1);
hold on;
plot(100*(RMSE_MF1_G(1:8,9)-RMSE_AR1_G(1:8,9))./RMSE_AR1_G(1:8,9),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_G(1:8,9)-RMSE_AR2_G(1:8,9))./RMSE_AR2_G(1:8,9),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_G(1:8,9)-RMSE_AR0_G(1:8,9))./RMSE_AR0_G(1:8,9),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('GDP Growth','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -35 15])
set(gca,'FontSize',15)

subplot(2,2,3);
hold on;
hold on;
plot(100*(RMSE_MF1_G(1:8,3)-RMSE_AR1_G(1:8,3))./RMSE_AR1_G(1:8,3),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_G(1:8,3)-RMSE_AR2_G(1:8,3))./RMSE_AR2_G(1:8,3),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_G(1:8,3)-RMSE_AR0_G(1:8,3))./RMSE_AR0_G(1:8,3),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Inflation','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
%axis([1 8 min(100*(RMSE_MF0_G(1:8,3)-RMSE_AR0_G(1:8,3))./RMSE_AR0_G(1:8,3)) 1]);
axis tight 
set(gca,'FontSize',15)

subplot(2,2,2);
hold on;
plot(100*(RMSE_MF1_L(1:8,1)-RMSE_AR1_L(1:8,1))./RMSE_AR1_L(1:8,1),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_L(1:8,1)-RMSE_AR2_L(1:8,1))./RMSE_AR2_L(1:8,1),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_L(1:8,1)-RMSE_AR0_L(1:8,1))./RMSE_AR0_L(1:8,1),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Unemployment Rate','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -80 20])
%axis([1 8 min(100*(RMSE_MF0_L(1:8,1)-RMSE_AR0_L(1:8,1))./RMSE_AR0_L(1:8,1)) 1.1]);
set(gca,'FontSize',15)


subplot(2,2,4);
hold on;
plot(100*(RMSE_MF1_L(1:8,6)-RMSE_AR1_L(1:8,6))./RMSE_AR1_L(1:8,6),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_MF2_L(1:8,6)-RMSE_AR2_L(1:8,6))./RMSE_AR2_L(1:8,6),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_L(1:8,6)-RMSE_AR0_L(1:8,6))./RMSE_AR0_L(1:8,6),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('Federal Funds Rate','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
%axis tight
%axis([1 8 min(100*(RMSE_MF0_L(1:8,6)-RMSE_AR0_L(1:8,6))./RMSE_AR0_L(1:8,6)) 1.1]);
set(gca,'FontSize',15)



RMSE_ALL_G = zeros(size(RMSE_MF1_G_vector,1)+size(RMSE_MF2_G_vector,1)+size(RMSE_MF0_G_vector,1),8,11);

RMSE_ALL_G(1:size(RMSE_MF1_G_vector,1),:,:) = RMSE_MF1_G_vector;
RMSE_ALL_G(size(RMSE_MF1_G_vector,1)+1:size(RMSE_MF1_G_vector,1)+size(RMSE_MF2_G_vector,1),:,:) = RMSE_MF2_G_vector;
RMSE_ALL_G(end-size(RMSE_MF0_G_vector,1)+1:end,:,:) = RMSE_MF0_G_vector;
RMSE_ALL_G = sqrt(squeeze(mean(RMSE_ALL_G)));

RMSE_ALL_L = zeros(size(RMSE_MF1_L_vector,1)+size(RMSE_MF2_L_vector,1)+size(RMSE_MF0_L_vector,1),8,11);

RMSE_ALL_L(1:size(RMSE_MF1_L_vector,1),:,:) = RMSE_MF1_L_vector;
RMSE_ALL_L(size(RMSE_MF1_L_vector,1)+1:size(RMSE_MF1_L_vector,1)+size(RMSE_MF2_L_vector,1),:,:) = RMSE_MF2_L_vector;
RMSE_ALL_L(end-size(RMSE_MF0_L_vector,1)+1:end,:,:) = RMSE_MF0_L_vector;
RMSE_ALL_L = sqrt(squeeze(mean(RMSE_ALL_L)));

ALL_SELECT = [1 0 0 0 0 1 1 0 0 0 0];

RMSE_ALL               = 0.25*RMSE_ALL_G;
RMSE_ALL(:,ALL_SELECT==1) = RMSE_ALL_L(:,ALL_SELECT==1);

RMSE_0_MON               = 0.25*RMSE_MF1_G;
RMSE_0_MON(:,ALL_SELECT==1) = RMSE_MF1_L(:,ALL_SELECT==1);

RMSE_1_MON               = 0.25*RMSE_MF2_G;
RMSE_1_MON(:,ALL_SELECT==1) = RMSE_MF2_L(:,ALL_SELECT==1);

RMSE_2_MON               = 0.25*RMSE_MF0_G;
RMSE_2_MON(:,ALL_SELECT==1) = RMSE_MF0_L(:,ALL_SELECT==1);

saveas(fig,'Figures/RMSE_MQ.bmp');
saveas(fig2,'Figures/RMSE_MA.bmp');
%saveas(fig3,'Figures/RMSE_QA.bmp');
