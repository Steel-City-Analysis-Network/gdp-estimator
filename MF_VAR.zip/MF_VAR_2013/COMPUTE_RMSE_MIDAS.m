%% recursive sample: 7/31/97 - 1/31/10: 151 total
% discrepancy between GB closed dates and projection dates
% 1/31/96: December CPI release NOT yet available: USE 2/1/96 release  
% definition of {0,1,2}:
% var(1) var(2) var(3) var(4): let var(1) be the only QF variable
%   0     +2      +2     +3  : denote as "0" : 3rd release  
%   0      0       0     +1  : denote as "1" : 1st release
%   0     +1      +1     +2  : denote as "2" : 2nd release
%

%  1    2    3    4   5   6   7    8 
% UNR, HRS, CPI, IP, PCE, FF, TB, SP500
  
load results_RS_MIDAS_1.mat  
FG_vector50_MIDAS1 = FG_vector50;
load results_RS_MIDAS_2.mat  
FG_vector50_MIDAS2 = FG_vector50;
load results_RS_MIDAS_3.mat  
FG_vector50_MIDAS3 = FG_vector50;
load results_RS_MIDAS_4.mat  
FG_vector50_MIDAS4 = FG_vector50;
load results_RS_MIDAS_5.mat  
FG_vector50_MIDAS5 = FG_vector50;
load results_RS_MIDAS_6.mat  
FG_vector50_MIDAS6 = FG_vector50;
load results_RS_MIDAS_7.mat  
FG_vector50_MIDAS7 = FG_vector50;
load results_RS_MIDAS_8.mat  
FG_vector50_MIDAS8 = FG_vector50;

load results_RS_MIDAS_ALL.mat
FG_vector50_MIDASA = FG_vector50;

load results_RS_MFBVAR2_1.mat
FG_vector50_var2_1 = FG_vector50;
load results_RS_MFBVAR2_2.mat
FG_vector50_var2_2 = FG_vector50;
load results_RS_MFBVAR2_3.mat
FG_vector50_var2_3 = FG_vector50;
load results_RS_MFBVAR2_4.mat
FG_vector50_var2_4 = FG_vector50;
load results_RS_MFBVAR2_5.mat
FG_vector50_var2_5 = FG_vector50;
load results_RS_MFBVAR2_6.mat
FG_vector50_var2_6 = FG_vector50;
load results_RS_MFBVAR2_7.mat
FG_vector50_var2_7 = FG_vector50;
load results_RS_MFBVAR2_8.mat
FG_vector50_var2_8 = FG_vector50;

load results_RS_MFBVAR_var4_2013.mat
load results_RS_QFBVAR_var4.mat

nrs = 151;

% SS_index starts from 1994:M3, but we want to use it from 1997:M7
%SS_index = SS_index(38:nrs+37);
SS_index = SS_index(38:38+nrs-1);
SS_index(28)  = 4;
SS_index(29)  = 4;
SS_index(33)  = 4;
SS_index(145) = 4;
SS_index(151) = 4;

% store RMSE_vector: 
RMSE_MF2_G_vector = zeros(sum(SS_index==2),8,4);
FG2_vector        = FG_vector((SS_index==2)==1,:,:);
RMSE_MF0_G_vector = zeros(sum(SS_index==0),8,4);
FG0_vector        = FG_vector((SS_index==0)==1,:,:);
RMSE_MF1_G_vector = zeros(sum(SS_index==1),8,4);
FG1_vector        = FG_vector((SS_index==1)==1,:,:);

RMSE_QF2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_QF0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_QF1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_1MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_1MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_1MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_2MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_2MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_2MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_3MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_3MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_3MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_4MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_4MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_4MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_5MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_5MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_5MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_6MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_6MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_6MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_7MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_7MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_7MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_8MD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_8MD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_8MD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_AMD2_G_vector = zeros(sum(SS_index==2),8,4);
RMSE_AMD0_G_vector = zeros(sum(SS_index==0),8,4);
RMSE_AMD1_G_vector = zeros(sum(SS_index==1),8,4);

RMSE_1MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_1MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_1MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_2MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_2MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_2MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_3MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_3MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_3MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_4MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_4MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_4MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_5MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_5MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_5MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_6MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_6MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_6MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_7MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_7MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_7MF1_G_vector = zeros(sum(SS_index==1),8,2);

RMSE_8MF2_G_vector = zeros(sum(SS_index==2),8,2);
RMSE_8MF0_G_vector = zeros(sum(SS_index==0),8,2);
RMSE_8MF1_G_vector = zeros(sum(SS_index==1),8,2);


FG2_vector50 = FG_vector50((SS_index==2)==1,:,:);
FG0_vector50 = FG_vector50((SS_index==0)==1,:,:);
FG1_vector50 = FG_vector50((SS_index==1)==1,:,:);

FGQ2_vector50 = FGQ_vector50((SS_index==2)==1,:,:);
FGQ0_vector50 = FGQ_vector50((SS_index==0)==1,:,:);
FGQ1_vector50 = FGQ_vector50((SS_index==1)==1,:,:);

MD1FG2_vector50 = FG_vector50_MIDAS1((SS_index==2)==1,:,:);
MD1FG0_vector50 = FG_vector50_MIDAS1((SS_index==0)==1,:,:);
MD1FG1_vector50 = FG_vector50_MIDAS1((SS_index==1)==1,:,:);

MD2FG2_vector50 = FG_vector50_MIDAS2((SS_index==2)==1,:,:);
MD2FG0_vector50 = FG_vector50_MIDAS2((SS_index==0)==1,:,:);
MD2FG1_vector50 = FG_vector50_MIDAS2((SS_index==1)==1,:,:);

MD3FG2_vector50 = FG_vector50_MIDAS3((SS_index==2)==1,:,:);
MD3FG0_vector50 = FG_vector50_MIDAS3((SS_index==0)==1,:,:);
MD3FG1_vector50 = FG_vector50_MIDAS3((SS_index==1)==1,:,:);

MD4FG2_vector50 = FG_vector50_MIDAS4((SS_index==2)==1,:,:);
MD4FG0_vector50 = FG_vector50_MIDAS4((SS_index==0)==1,:,:);
MD4FG1_vector50 = FG_vector50_MIDAS4((SS_index==1)==1,:,:);

MD5FG2_vector50 = FG_vector50_MIDAS5((SS_index==2)==1,:,:);
MD5FG0_vector50 = FG_vector50_MIDAS5((SS_index==0)==1,:,:);
MD5FG1_vector50 = FG_vector50_MIDAS5((SS_index==1)==1,:,:);

MD6FG2_vector50 = FG_vector50_MIDAS6((SS_index==2)==1,:,:);
MD6FG0_vector50 = FG_vector50_MIDAS6((SS_index==0)==1,:,:);
MD6FG1_vector50 = FG_vector50_MIDAS6((SS_index==1)==1,:,:);

MD7FG2_vector50 = FG_vector50_MIDAS7((SS_index==2)==1,:,:);
MD7FG0_vector50 = FG_vector50_MIDAS7((SS_index==0)==1,:,:);
MD7FG1_vector50 = FG_vector50_MIDAS7((SS_index==1)==1,:,:);

MD8FG2_vector50 = FG_vector50_MIDAS8((SS_index==2)==1,:,:);
MD8FG0_vector50 = FG_vector50_MIDAS8((SS_index==0)==1,:,:);
MD8FG1_vector50 = FG_vector50_MIDAS8((SS_index==1)==1,:,:);


MDAFG2_vector50 = FG_vector50_MIDASA((SS_index==2)==1,:,:);
MDAFG0_vector50 = FG_vector50_MIDASA((SS_index==0)==1,:,:);
MDAFG1_vector50 = FG_vector50_MIDASA((SS_index==1)==1,:,:);



MF1FG2_vector50 = FG_vector50_var2_1((SS_index==2)==1,:,:);
MF1FG0_vector50 = FG_vector50_var2_1((SS_index==0)==1,:,:);
MF1FG1_vector50 = FG_vector50_var2_1((SS_index==1)==1,:,:);

MF2FG2_vector50 = FG_vector50_var2_2((SS_index==2)==1,:,:);
MF2FG0_vector50 = FG_vector50_var2_2((SS_index==0)==1,:,:);
MF2FG1_vector50 = FG_vector50_var2_2((SS_index==1)==1,:,:);

MF3FG2_vector50 = FG_vector50_var2_3((SS_index==2)==1,:,:);
MF3FG0_vector50 = FG_vector50_var2_3((SS_index==0)==1,:,:);
MF3FG1_vector50 = FG_vector50_var2_3((SS_index==1)==1,:,:);

MF4FG2_vector50 = FG_vector50_var2_4((SS_index==2)==1,:,:);
MF4FG0_vector50 = FG_vector50_var2_4((SS_index==0)==1,:,:);
MF4FG1_vector50 = FG_vector50_var2_4((SS_index==1)==1,:,:);

MF5FG2_vector50 = FG_vector50_var2_5((SS_index==2)==1,:,:);
MF5FG0_vector50 = FG_vector50_var2_5((SS_index==0)==1,:,:);
MF5FG1_vector50 = FG_vector50_var2_5((SS_index==1)==1,:,:);

MF6FG2_vector50 = FG_vector50_var2_6((SS_index==2)==1,:,:);
MF6FG0_vector50 = FG_vector50_var2_6((SS_index==0)==1,:,:);
MF6FG1_vector50 = FG_vector50_var2_6((SS_index==1)==1,:,:);

MF7FG2_vector50 = FG_vector50_var2_7((SS_index==2)==1,:,:);
MF7FG0_vector50 = FG_vector50_var2_7((SS_index==0)==1,:,:);
MF7FG1_vector50 = FG_vector50_var2_7((SS_index==1)==1,:,:);

MF8FG2_vector50 = FG_vector50_var2_8((SS_index==2)==1,:,:);
MF8FG0_vector50 = FG_vector50_var2_8((SS_index==0)==1,:,:);
MF8FG1_vector50 = FG_vector50_var2_8((SS_index==1)==1,:,:);


for j=4:4
for ii=1:sum(SS_index==2)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF2_G_vector(ii,:,j) = ((4*FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);    
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF2_G_vector(ii,:,j)  = ((4*FGQ2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);

    % MIDAS(1) RMSE COMPUTATION        
    RMSE_1MD2_G_vector(ii,:,j) = ((4*MD1FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);      

    % MIDAS(2) RMSE COMPUTATION        
    RMSE_2MD2_G_vector(ii,:,j) = ((4*MD2FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);     
    
    % MIDAS(3) RMSE COMPUTATION        
    RMSE_3MD2_G_vector(ii,:,j) = ((4*MD3FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2); 

    % MIDAS(4) RMSE COMPUTATION        
    RMSE_4MD2_G_vector(ii,:,j) = ((4*MD4FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);      

    % MIDAS(5) RMSE COMPUTATION        
    RMSE_5MD2_G_vector(ii,:,j) = ((4*MD5FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);     
    
    % MIDAS(6) RMSE COMPUTATION        
    RMSE_6MD2_G_vector(ii,:,j) = ((4*MD6FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2); 

    % MIDAS(7) RMSE COMPUTATION        
    RMSE_7MD2_G_vector(ii,:,j) = ((4*MD7FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);     
    
    % MIDAS(8) RMSE COMPUTATION        
    RMSE_8MD2_G_vector(ii,:,j) = ((4*MD8FG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2); 
        
    % MIDAS(A) RMSE COMPUTATION        
    RMSE_AMD2_G_vector(ii,:,j) = ((4*MDAFG2_vector50(ii,:,j)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(1) RMSE COMPUTATION        
    RMSE_1MF2_G_vector(ii,:,j-2) = ((4*MF1FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(2) RMSE COMPUTATION        
    RMSE_2MF2_G_vector(ii,:,j-2) = ((4*MF2FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(3) RMSE COMPUTATION        
    RMSE_3MF2_G_vector(ii,:,j-2) = ((4*MF3FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(4) RMSE COMPUTATION        
    RMSE_4MF2_G_vector(ii,:,j-2) = ((4*MF4FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(5) RMSE COMPUTATION        
    RMSE_5MF2_G_vector(ii,:,j-2) = ((4*MF5FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(6) RMSE COMPUTATION        
    RMSE_6MF2_G_vector(ii,:,j-2) = ((4*MF6FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(7) RMSE COMPUTATION        
    RMSE_7MF2_G_vector(ii,:,j-2) = ((4*MF7FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);   
    
    % MF BVAR(8) RMSE COMPUTATION        
    RMSE_8MF2_G_vector(ii,:,j-2) = ((4*MF8FG2_vector50(ii,:,j-2)-4*FG2_vector(ii,:,j)).^2);      
end
end

for j=4:4
for ii=1:sum(SS_index==0)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF0_G_vector(ii,:,j) = ((4*FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);    
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF0_G_vector(ii,:,j)  = ((4*FGQ0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);

    % MIDAS(1) RMSE COMPUTATION        
    RMSE_1MD0_G_vector(ii,:,j) = ((4*MD1FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);      

    % MIDAS(2) RMSE COMPUTATION        
    RMSE_2MD0_G_vector(ii,:,j) = ((4*MD2FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);     
    
    % MIDAS(3) RMSE COMPUTATION        
    RMSE_3MD0_G_vector(ii,:,j) = ((4*MD3FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2); 

    % MIDAS(4) RMSE COMPUTATION        
    RMSE_4MD0_G_vector(ii,:,j) = ((4*MD4FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);      

    % MIDAS(5) RMSE COMPUTATION        
    RMSE_5MD0_G_vector(ii,:,j) = ((4*MD5FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);     
    
    % MIDAS(6) RMSE COMPUTATION        
    RMSE_6MD0_G_vector(ii,:,j) = ((4*MD6FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2); 

    % MIDAS(7) RMSE COMPUTATION        
    RMSE_7MD0_G_vector(ii,:,j) = ((4*MD7FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);     
    
    % MIDAS(8) RMSE COMPUTATION        
    RMSE_8MD0_G_vector(ii,:,j) = ((4*MD8FG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2); 
        
    % MIDAS(A) RMSE COMPUTATION        
    RMSE_AMD0_G_vector(ii,:,j) = ((4*MDAFG0_vector50(ii,:,j)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(1) RMSE COMPUTATION        
    RMSE_1MF0_G_vector(ii,:,j-2) = ((4*MF1FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(2) RMSE COMPUTATION        
    RMSE_2MF0_G_vector(ii,:,j-2) = ((4*MF2FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(3) RMSE COMPUTATION        
    RMSE_3MF0_G_vector(ii,:,j-2) = ((4*MF3FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(4) RMSE COMPUTATION        
    RMSE_4MF0_G_vector(ii,:,j-2) = ((4*MF4FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(5) RMSE COMPUTATION        
    RMSE_5MF0_G_vector(ii,:,j-2) = ((4*MF5FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(6) RMSE COMPUTATION        
    RMSE_6MF0_G_vector(ii,:,j-2) = ((4*MF6FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(7) RMSE COMPUTATION        
    RMSE_7MF0_G_vector(ii,:,j-2) = ((4*MF7FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);   
    
    % MF BVAR(8) RMSE COMPUTATION        
    RMSE_8MF0_G_vector(ii,:,j-2) = ((4*MF8FG0_vector50(ii,:,j-2)-4*FG0_vector(ii,:,j)).^2);      
end
end

for j=4:4
for ii=1:sum(SS_index==1)    
    % MF BVAR RMSE COMPUTATION        
    RMSE_MF1_G_vector(ii,:,j) = ((4*FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);    
    
    % QF BVAR RMSE COMPUTATION
    RMSE_QF1_G_vector(ii,:,j)  = ((4*FGQ1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);

    % MIDAS(1) RMSE COMPUTATION        
    RMSE_1MD1_G_vector(ii,:,j) = ((4*MD1FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);      

    % MIDAS(2) RMSE COMPUTATION        
    RMSE_2MD1_G_vector(ii,:,j) = ((4*MD2FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);     
    
    % MIDAS(3) RMSE COMPUTATION        
    RMSE_3MD1_G_vector(ii,:,j) = ((4*MD3FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2); 

    % MIDAS(4) RMSE COMPUTATION        
    RMSE_4MD1_G_vector(ii,:,j) = ((4*MD4FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);      

    % MIDAS(5) RMSE COMPUTATION        
    RMSE_5MD1_G_vector(ii,:,j) = ((4*MD5FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);     
    
    % MIDAS(6) RMSE COMPUTATION        
    RMSE_6MD1_G_vector(ii,:,j) = ((4*MD6FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2); 

    % MIDAS(7) RMSE COMPUTATION        
    RMSE_7MD1_G_vector(ii,:,j) = ((4*MD7FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);     
    
    % MIDAS(8) RMSE COMPUTATION        
    RMSE_8MD1_G_vector(ii,:,j) = ((4*MD8FG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2); 
        
    % MIDAS(A) RMSE COMPUTATION        
    RMSE_AMD1_G_vector(ii,:,j) = ((4*MDAFG1_vector50(ii,:,j)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(1) RMSE COMPUTATION        
    RMSE_1MF1_G_vector(ii,:,j-2) = ((4*MF1FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(2) RMSE COMPUTATION        
    RMSE_2MF1_G_vector(ii,:,j-2) = ((4*MF2FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(3) RMSE COMPUTATION        
    RMSE_3MF1_G_vector(ii,:,j-2) = ((4*MF3FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(4) RMSE COMPUTATION        
    RMSE_4MF1_G_vector(ii,:,j-2) = ((4*MF4FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(5) RMSE COMPUTATION        
    RMSE_5MF1_G_vector(ii,:,j-2) = ((4*MF5FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(6) RMSE COMPUTATION        
    RMSE_6MF1_G_vector(ii,:,j-2) = ((4*MF6FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(7) RMSE COMPUTATION        
    RMSE_7MF1_G_vector(ii,:,j-2) = ((4*MF7FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);   
    
    % MF BVAR(8) RMSE COMPUTATION        
    RMSE_8MF1_G_vector(ii,:,j-2) = ((4*MF8FG1_vector50(ii,:,j-2)-4*FG1_vector(ii,:,j)).^2);      
end
end



RMSE_MF2_G = sqrt(squeeze(mean(RMSE_MF2_G_vector)));
RMSE_MF0_G = sqrt(squeeze(mean(RMSE_MF0_G_vector)));
RMSE_MF1_G = sqrt(squeeze(mean(RMSE_MF1_G_vector)));

RMSE_QF2_G = sqrt(squeeze(mean(RMSE_QF2_G_vector)));
RMSE_QF0_G = sqrt(squeeze(mean(RMSE_QF0_G_vector)));
RMSE_QF1_G = sqrt(squeeze(mean(RMSE_QF1_G_vector)));

RMSE_1MD2_G = sqrt(squeeze(mean(RMSE_1MD2_G_vector)));
RMSE_1MD0_G = sqrt(squeeze(mean(RMSE_1MD0_G_vector)));
RMSE_1MD1_G = sqrt(squeeze(mean(RMSE_1MD1_G_vector)));

RMSE_2MD2_G = sqrt(squeeze(mean(RMSE_2MD2_G_vector)));
RMSE_2MD0_G = sqrt(squeeze(mean(RMSE_2MD0_G_vector)));
RMSE_2MD1_G = sqrt(squeeze(mean(RMSE_2MD1_G_vector)));

RMSE_3MD2_G = sqrt(squeeze(mean(RMSE_3MD2_G_vector)));
RMSE_3MD0_G = sqrt(squeeze(mean(RMSE_3MD0_G_vector)));
RMSE_3MD1_G = sqrt(squeeze(mean(RMSE_3MD1_G_vector)));

RMSE_4MD2_G = sqrt(squeeze(mean(RMSE_4MD2_G_vector)));
RMSE_4MD0_G = sqrt(squeeze(mean(RMSE_4MD0_G_vector)));
RMSE_4MD1_G = sqrt(squeeze(mean(RMSE_4MD1_G_vector)));

RMSE_5MD2_G = sqrt(squeeze(mean(RMSE_5MD2_G_vector)));
RMSE_5MD0_G = sqrt(squeeze(mean(RMSE_5MD0_G_vector)));
RMSE_5MD1_G = sqrt(squeeze(mean(RMSE_5MD1_G_vector)));

RMSE_6MD2_G = sqrt(squeeze(mean(RMSE_6MD2_G_vector)));
RMSE_6MD0_G = sqrt(squeeze(mean(RMSE_6MD0_G_vector)));
RMSE_6MD1_G = sqrt(squeeze(mean(RMSE_6MD1_G_vector)));

RMSE_7MD2_G = sqrt(squeeze(mean(RMSE_7MD2_G_vector)));
RMSE_7MD0_G = sqrt(squeeze(mean(RMSE_7MD0_G_vector)));
RMSE_7MD1_G = sqrt(squeeze(mean(RMSE_7MD1_G_vector)));

RMSE_8MD2_G = sqrt(squeeze(mean(RMSE_8MD2_G_vector)));
RMSE_8MD0_G = sqrt(squeeze(mean(RMSE_8MD0_G_vector)));
RMSE_8MD1_G = sqrt(squeeze(mean(RMSE_8MD1_G_vector)));

RMSE_AMD2_G = sqrt(squeeze(mean(RMSE_AMD2_G_vector)));
RMSE_AMD0_G = sqrt(squeeze(mean(RMSE_AMD0_G_vector)));
RMSE_AMD1_G = sqrt(squeeze(mean(RMSE_AMD1_G_vector)));

RMSE_1MF2_G = sqrt(squeeze(mean(RMSE_1MF2_G_vector)));
RMSE_1MF0_G = sqrt(squeeze(mean(RMSE_1MF0_G_vector)));
RMSE_1MF1_G = sqrt(squeeze(mean(RMSE_1MF1_G_vector)));

RMSE_2MF2_G = sqrt(squeeze(mean(RMSE_2MF2_G_vector)));
RMSE_2MF0_G = sqrt(squeeze(mean(RMSE_2MF0_G_vector)));
RMSE_2MF1_G = sqrt(squeeze(mean(RMSE_2MF1_G_vector)));

RMSE_3MF2_G = sqrt(squeeze(mean(RMSE_3MF2_G_vector)));
RMSE_3MF0_G = sqrt(squeeze(mean(RMSE_3MF0_G_vector)));
RMSE_3MF1_G = sqrt(squeeze(mean(RMSE_3MF1_G_vector)));

RMSE_4MF2_G = sqrt(squeeze(mean(RMSE_4MF2_G_vector)));
RMSE_4MF0_G = sqrt(squeeze(mean(RMSE_4MF0_G_vector)));
RMSE_4MF1_G = sqrt(squeeze(mean(RMSE_4MF1_G_vector)));

RMSE_5MF2_G = sqrt(squeeze(mean(RMSE_5MF2_G_vector)));
RMSE_5MF0_G = sqrt(squeeze(mean(RMSE_5MF0_G_vector)));
RMSE_5MF1_G = sqrt(squeeze(mean(RMSE_5MF1_G_vector)));

RMSE_6MF2_G = sqrt(squeeze(mean(RMSE_6MF2_G_vector)));
RMSE_6MF0_G = sqrt(squeeze(mean(RMSE_6MF0_G_vector)));
RMSE_6MF1_G = sqrt(squeeze(mean(RMSE_6MF1_G_vector)));

RMSE_7MF2_G = sqrt(squeeze(mean(RMSE_7MF2_G_vector)));
RMSE_7MF0_G = sqrt(squeeze(mean(RMSE_7MF0_G_vector)));
RMSE_7MF1_G = sqrt(squeeze(mean(RMSE_7MF1_G_vector)));

RMSE_8MF2_G = sqrt(squeeze(mean(RMSE_8MF2_G_vector)));
RMSE_8MF0_G = sqrt(squeeze(mean(RMSE_8MF0_G_vector)));
RMSE_8MF1_G = sqrt(squeeze(mean(RMSE_8MF1_G_vector)));

% RMSE_MF2_G(1,:) = nan(1,4); 
% RMSE_MF0_G(1,:) = nan(1,4);  
% RMSE_MF1_G(1,:) = nan(1,4);  



scrsz = get(0,'ScreenSize');

fig=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.1]);
subplot(2,3,1);
hold on;
plot(100*(RMSE_MF1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_MF2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_MF0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (UNR,CPI,FF) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,2);
hold on;
plot(100*(RMSE_AMD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_AMD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_AMD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (UNR,CPI,FF) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -15 25])
set(gca,'FontSize',14)

subplot(2,3,4);
hold on;
plot(100*(RMSE_1MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_1MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_1MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (UNR) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,5);
hold on;
plot(100*(RMSE_3MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_3MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_3MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (CPI) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,6);
hold on;
plot(100*(RMSE_6MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_6MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_6MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (FF) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)



fig2=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.1]);

subplot(2,3,1);
hold on;
plot(100*(RMSE_1MF1_G(1:8,2)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_1MF2_G(1:8,2)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_1MF0_G(1:8,2)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (UNR) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,2);
hold on;
plot(100*(RMSE_3MF1_G(1:8,2)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_3MF2_G(1:8,2)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_3MF0_G(1:8,2)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (CPI) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,3);
hold on;
plot(100*(RMSE_6MF1_G(1:8,2)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_6MF2_G(1:8,2)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_6MF0_G(1:8,2)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (FF) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)     
     
     
subplot(2,3,4);
hold on;
plot(100*(RMSE_1MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_1MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_1MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (UNR) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,5);
hold on;
plot(100*(RMSE_3MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_3MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_3MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (CPI) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)

subplot(2,3,6);
hold on;
plot(100*(RMSE_6MD1_G(1:8,4)-RMSE_QF1_G(1:8,4))./RMSE_QF1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_6MD2_G(1:8,4)-RMSE_QF2_G(1:8,4))./RMSE_QF2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_6MD0_G(1:8,4)-RMSE_QF0_G(1:8,4))./RMSE_QF0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MIDAS (FF) vs QF-VAR','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -25 8])
set(gca,'FontSize',14)     
     
     
fig3=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.1]);

subplot(2,4,1);
hold on;
plot(100*(RMSE_1MF1_G(1:8,2)-RMSE_1MD1_G(1:8,4))./RMSE_1MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_1MF2_G(1:8,2)-RMSE_1MD2_G(1:8,4))./RMSE_1MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_1MF0_G(1:8,2)-RMSE_1MD0_G(1:8,4))./RMSE_1MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (UNR) vs MIDAS (UNR)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,2);
hold on;
plot(100*(RMSE_2MF1_G(1:8,2)-RMSE_2MD1_G(1:8,4))./RMSE_2MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_2MF2_G(1:8,2)-RMSE_2MD2_G(1:8,4))./RMSE_2MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_2MF0_G(1:8,2)-RMSE_2MD0_G(1:8,4))./RMSE_2MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (HRS) vs MIDAS (HRS)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,3);
hold on;
plot(100*(RMSE_3MF1_G(1:8,2)-RMSE_3MD1_G(1:8,4))./RMSE_3MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_3MF2_G(1:8,2)-RMSE_3MD2_G(1:8,4))./RMSE_3MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_3MF0_G(1:8,2)-RMSE_3MD0_G(1:8,4))./RMSE_3MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (CPI) vs MIDAS (CPI)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,4);
hold on;
plot(100*(RMSE_4MF1_G(1:8,2)-RMSE_4MD1_G(1:8,4))./RMSE_4MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_4MF2_G(1:8,2)-RMSE_4MD2_G(1:8,4))./RMSE_4MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_4MF0_G(1:8,2)-RMSE_4MD0_G(1:8,4))./RMSE_4MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (IP) vs MIDAS (IP)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,5);
hold on;
plot(100*(RMSE_5MF1_G(1:8,2)-RMSE_5MD1_G(1:8,4))./RMSE_5MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_5MF2_G(1:8,2)-RMSE_5MD2_G(1:8,4))./RMSE_5MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_5MF0_G(1:8,2)-RMSE_5MD0_G(1:8,4))./RMSE_5MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (PCE) vs MIDAS (PCE)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,6);
hold on;
plot(100*(RMSE_6MF1_G(1:8,2)-RMSE_6MD1_G(1:8,4))./RMSE_6MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_6MF2_G(1:8,2)-RMSE_6MD2_G(1:8,4))./RMSE_6MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_6MF0_G(1:8,2)-RMSE_6MD0_G(1:8,4))./RMSE_6MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (FF) vs MIDAS (FF)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,7);
hold on;
plot(100*(RMSE_7MF1_G(1:8,2)-RMSE_7MD1_G(1:8,4))./RMSE_7MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_7MF2_G(1:8,2)-RMSE_7MD2_G(1:8,4))./RMSE_7MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_7MF0_G(1:8,2)-RMSE_7MD0_G(1:8,4))./RMSE_7MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (TB) vs MIDAS (TB)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)

subplot(2,4,8);
hold on;
plot(100*(RMSE_8MF1_G(1:8,2)-RMSE_8MD1_G(1:8,4))./RMSE_8MD1_G(1:8,4),'Color',[0.9 0.2 0.1],'LineStyle',':','LineWidth',5.5)
plot(100*(RMSE_8MF2_G(1:8,2)-RMSE_8MD2_G(1:8,4))./RMSE_8MD2_G(1:8,4),'Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_8MF0_G(1:8,2)-RMSE_8MD0_G(1:8,4))./RMSE_8MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',14);
legend('boxoff')
title('MF-VAR (SP500) vs MIDAS (SP500)','FontSize',14);
xlabel('Forecast Horizon','FontSize',14);
ylabel('Relative RMSE','FontSize',14);
hold on
line([1 8],[0 0],'Color',[0.2 0.2 0.2],'LineStyle',':','LineWidth',3)
axis([1 8 -35 8])
set(gca,'FontSize',14)



fig4=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.2]);

subplot(2,2,1);
hold on;
plot(100*(RMSE_1MF1_G(1:8,2)-RMSE_1MD1_G(1:8,4))./RMSE_1MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_1MF2_G(1:8,2)-RMSE_1MD2_G(1:8,4))./RMSE_1MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_1MF0_G(1:8,2)-RMSE_1MD0_G(1:8,4))./RMSE_1MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (UNR) \emph{versus} MIDAS (UNR)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -20 5])
set(gca,'FontSize',15)

subplot(2,2,2);
hold on;
plot(100*(RMSE_4MF1_G(1:8,2)-RMSE_4MD1_G(1:8,4))./RMSE_4MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_4MF2_G(1:8,2)-RMSE_4MD2_G(1:8,4))./RMSE_4MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_4MF0_G(1:8,2)-RMSE_4MD0_G(1:8,4))./RMSE_4MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (IP) \emph{versus} MIDAS (IP)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -40 10])
set(gca,'FontSize',15)

subplot(2,2,3);
hold on;
plot(100*(RMSE_5MF1_G(1:8,2)-RMSE_5MD1_G(1:8,4))./RMSE_5MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_5MF2_G(1:8,2)-RMSE_5MD2_G(1:8,4))./RMSE_5MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_5MF0_G(1:8,2)-RMSE_5MD0_G(1:8,4))./RMSE_5MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (PCE) \emph{versus} MIDAS (PCE)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -30 5])
set(gca,'FontSize',15)


subplot(2,2,4);
hold on;
plot(100*(RMSE_8MF1_G(1:8,2)-RMSE_8MD1_G(1:8,4))./RMSE_8MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_8MF2_G(1:8,2)-RMSE_8MD2_G(1:8,4))./RMSE_8MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_8MF0_G(1:8,2)-RMSE_8MD0_G(1:8,4))./RMSE_8MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (SP500) \emph{versus} MIDAS (SP500)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -30 10])
set(gca,'FontSize',15)


fig5=figure('Position',[20,20,900,600],'Name',...
         'RMSE','Color','w',...
         'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.2]);

subplot(2,2,1);
hold on;
plot(100*(RMSE_2MF1_G(1:8,2)-RMSE_2MD1_G(1:8,4))./RMSE_2MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_2MF2_G(1:8,2)-RMSE_2MD2_G(1:8,4))./RMSE_2MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_2MF0_G(1:8,2)-RMSE_2MD0_G(1:8,4))./RMSE_2MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','northeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (HRS) \emph{versus} MIDAS (HRS)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -35 5])
set(gca,'FontSize',15)

subplot(2,2,2);
hold on;
plot(100*(RMSE_3MF1_G(1:8,2)-RMSE_3MD1_G(1:8,4))./RMSE_3MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_3MF2_G(1:8,2)-RMSE_3MD2_G(1:8,4))./RMSE_3MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_3MF0_G(1:8,2)-RMSE_3MD0_G(1:8,4))./RMSE_3MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (CPI) \emph{versus} MIDAS (CPI)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -40 10])
set(gca,'FontSize',15)

subplot(2,2,3);
hold on;
plot(100*(RMSE_6MF1_G(1:8,2)-RMSE_6MD1_G(1:8,4))./RMSE_6MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_6MF2_G(1:8,2)-RMSE_6MD2_G(1:8,4))./RMSE_6MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_6MF0_G(1:8,2)-RMSE_6MD0_G(1:8,4))./RMSE_6MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (FF) \emph{versus} MIDAS (FF)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -20 10])
set(gca,'FontSize',15)


subplot(2,2,4);
hold on;
plot(100*(RMSE_7MF1_G(1:8,2)-RMSE_7MD1_G(1:8,4))./RMSE_7MD1_G(1:8,4),'Marker','o','Color',[0.9 0.2 0.1],'LineStyle','-','LineWidth',3)
plot(100*(RMSE_7MF2_G(1:8,2)-RMSE_7MD2_G(1:8,4))./RMSE_7MD2_G(1:8,4),'Marker','s','Color',[0.2 0.8 0.2],'LineStyle','--','LineWidth',4)
plot(100*(RMSE_7MF0_G(1:8,2)-RMSE_7MD0_G(1:8,4))./RMSE_7MD0_G(1:8,4),'Color',[0.1 0.2 0.9],'LineStyle','-','LineWidth',3)
gg=legend('+0 Months','+1 Months','+2 Months');
set(gg,'location','southeast','FontSize',15);
set(gg,'Interpreter','latex');
legend('boxoff')
title('MF-VAR (TB) \emph{versus} MIDAS (TB)','Interpreter','latex','FontSize',15);
xlabel('Forecast Horizon','Interpreter','latex','FontSize',15);
ylabel('Relative RMSE','Interpreter','latex','FontSize',15);
hold on
line([1 8],[0 0],'Color',[0.6 0.6 0.6],'LineStyle','--','LineWidth',2)
axis([1 8 -30 10])
set(gca,'FontSize',15)


saveas(fig4,'Figures/RMSE_M_MD_var4.bmp');
saveas(fig5,'Figures/RMSE_M_MD_var4_0.bmp');
saveas(fig,'Figures/RMSE_M_MD_var4_1.bmp');
saveas(fig2,'Figures/RMSE_M_MD_var4_2.bmp');
saveas(fig3,'Figures/RMSE_M_MD_var4_3.bmp');