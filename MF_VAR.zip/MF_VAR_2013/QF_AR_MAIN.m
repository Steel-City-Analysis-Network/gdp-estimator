%======================================================================
%
%            QF AR : Quarterly Frequency AR(2)                   
%
%            Date : AUGUST, 2011     
%
%            Code Written By:  Frank Schorfheide  schorf@ssc.upenn.edu
%                              Dongho Song        donghos@sas.upenn.edu
%======================================================================


%======================================================================
%                          HOUSEKEEPING
%======================================================================

tic
close all
clear all
clc

ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

  
%======================================================================
%                           SPECIFICATION
%======================================================================

% LOAD DATA
create_vintage_NEW

% STORE
nsim     = 20000;         % number of draws from Posterior Density
nburn    = 0.2*nsim;     % number of draws to discard
nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33
H        = 8;
nv       = 11; 

FLA_vector95 = zeros(nrs,H,nv);
FLA_vector80 = zeros(nrs,H,nv);
FLA_vector50 = zeros(nrs,H,nv);
FLA_vector20 = zeros(nrs,H,nv);
FLA_vector05 = zeros(nrs,H,nv);
FLA_vector   = zeros(nrs,H,nv);

FGA_vector95 = zeros(nrs,H,nv);
FGA_vector80 = zeros(nrs,H,nv);
FGA_vector50 = zeros(nrs,H,nv);
FGA_vector20 = zeros(nrs,H,nv);
FGA_vector05 = zeros(nrs,H,nv);
FGA_vector   = zeros(nrs,H,nv);

APIT_LC      = zeros(nrs,H,nv);
APIT_GC      = zeros(nrs,H,nv);
APIT_L       = zeros(nrs,H,nv);
APIT_G       = zeros(nrs,H,nv);
%======================================================================
%                          HYPERPARAMETERS
%======================================================================
load hyp_1.txt;           % selected hyperparameters from BVAR_PRIOR
load hyp_2.txt;
load hyp_3.txt;
load hyp_4.txt;
load hyp_5.txt;
load hyp_6.txt;
load hyp_7.txt;
load hyp_8.txt;
load hyp_9.txt;
load hyp_10.txt;
load hyp_11.txt
hyp_vec = [hyp_1 hyp_2 hyp_3 hyp_4 hyp_5 hyp_6 hyp_7 hyp_8 hyp_9 hyp_10 hyp_11];
  
%======================================================================
%            BAYESIAN ESTIMATION OF VAR, FORECASTING, RMSE
%======================================================================
disp('                                                                ');
disp('     QUARTERLY FREQUENCY AUTOREGRESSIVE MODEL OF ORDER 2        ');
disp('                                                                ');
disp('                                                                ');
disp('             - ESTIMATION -                                     ');
disp('                                                                ');

% recursive sample 
for rrrr=1:length(nrs_vec)
    rrr=nrs_vec(rrrr);
    rs_sample = nan(size(var(9).rsdata,1),11);
    rs_nobs   = [];
    rs_fdata  = [];
    rs_fsub   = [];
    
    for kk=1:length(var)
        
        if kk<4
            rs_sub   = kron(var(kk).rsdata(:,rrr),ones(3,1));         
            rs_T     = max(find(~isnan(rs_sub)));
        else
            rs_sub   = var(kk).rsdata(:,rrr);
            rs_T     = max(find(~isnan(rs_sub)));
        end
                
        rs_sample(1:length(rs_sub),kk) = rs_sub;
        rs_nobs   = [rs_nobs rs_T];
    end
    
    for kk=1:length(var)        
        
        if kk>3
            rs_fmsub = var(kk).fdata(min(rs_nobs)-2:min(rs_nobs)+24,rrr);
            rs_fsub  = zeros(size(rs_fmsub,1)/3,1);
            for ii=1:size(rs_fsub,1)
                rs_fsub(ii)=mean(rs_fmsub(3*(ii-1)+1:3*ii));
            end
        else
            if min(rs_nobs)<rs_nobs(1)
                min_nobs = rs_nobs(1);
            else
                min_nobs = min(rs_nobs);
            end
            rs_fsub  = var(kk).fdata(min_nobs/3:min_nobs/3+8,rrr);            
        end
        
        rs_fdata  = [rs_fdata rs_fsub]; 
        rs_flvl   = rs_fdata(2:end,:);
        rs_fgrth  = 100*(rs_fdata(2:end,:)-rs_fdata(1:end-1,:)); 
      
    end
        % temporary definition
        rs_flvl   = [rs_flvl(:,4:end) rs_flvl(:,1:3)];
        rs_fgrth  = [rs_fgrth(:,4:end) rs_fgrth(:,1:3)];
        
    YQ      = rs_sample(:,1:3);
    YM      = rs_sample(:,4:end);   
    YDATA0  = [YM YQ];
    
    YDATA   = YDATA0(1:min(rs_nobs),:);
    
    RYQ  = zeros(rs_nobs(1)/3,11);
    for gg=1:rs_nobs(1)/3
        RYQ(gg,:) = mean(YDATA(3*(gg-1)+1:3*gg,:));
    end
    
    nv   = size(RYQ,2);

for kkk=1:nv
        
    YY   = RYQ(:,kkk);
    hyp  = hyp_vec(:,kkk);

    % SPECIFICATION
    nlags   = 2;              % number of lags   
    T0      = nlags+2;        % size of pre-sample 
    nex     = 1;              % number of exogenous vars; 1 means intercept only 
    nv      = size(YY,2);     % number of variables 
    nobs    = size(YY,1)-T0;  % number of observations 

    spec    = [nlags T0 nex nv nobs];
    
    % RUN BLOCK ALGORITHM 
    QF_AR_MAIN_SUB
        
    % SAVE THE MEDIAN VALUE ONLY
    [y95,y80,y50,y20,y05] = moment(YYvector);
    [g95,g80,g50,g20,g05] = moment(YYvector_g);
    
        % cumulative predictive distributions
    YYvector_c  = YYvector;
    YYvector_gc = YYvector_g;
    for jj=1:nsim-nburn
        for hh=2:8
            YYvector_c(jj,hh)  = mean(YYvector(jj,1:hh));
            YYvector_gc(jj,hh) = mean(YYvector_g(jj,1:hh));
        end
    end

    % cumulative actual values
    rs_flvlc  = rs_flvl;
    rs_fgrthc = rs_fgrth;

    for hh=2:8
        rs_flvlc(hh,:)  = mean(rs_flvl(1:hh,:));
        rs_fgrthc(hh,:) = mean(rs_fgrth(1:hh,:));
    end

    % compute unconditional probability integral transformation
    pit_lc = zeros(8,1);
    pit_gc = zeros(8,1);
    pit_l  = zeros(8,1);
    pit_g  = zeros(8,1);

    for hh=1:8
            pit_gc(hh) = mean(squeeze(YYvector_gc(:,hh))< ones(nsim,1)*rs_fgrthc(hh,kkk));
            pit_lc(hh) = mean(squeeze(YYvector_c(:,hh))< ones(nsim,1)*rs_flvlc(hh,kkk));
            pit_g(hh)  = mean(squeeze(YYvector_g(:,hh))< ones(nsim,1)*rs_fgrth(hh,kkk));
            pit_l(hh)  = mean(squeeze(YYvector(:,hh))< ones(nsim,1)*rs_flvl(hh,kkk));        
    end
    
    FLA_vector95(rrr,:,kkk) = y95';
    FLA_vector80(rrr,:,kkk) = y80';
    FLA_vector50(rrr,:,kkk) = y50';
    FLA_vector20(rrr,:,kkk) = y20';
    FLA_vector05(rrr,:,kkk) = y05';
    FGA_vector95(rrr,:,kkk) = g95';
    FGA_vector80(rrr,:,kkk) = g80';
    FGA_vector50(rrr,:,kkk) = g50';
    FGA_vector20(rrr,:,kkk) = g20';
    FGA_vector05(rrr,:,kkk) = g05';    
    APIT_LC(rrr,:,kkk)        = pit_lc;
    APIT_GC(rrr,:,kkk)        = pit_gc;
    APIT_L(rrr,:,kkk)         = pit_l;
    APIT_G(rrr,:,kkk)         = pit_g;
end
    FLA_vector(rrr,:,:)   = rs_flvl;
    FGA_vector(rrr,:,:)   = rs_fgrth;
end

save results_RS_AR2.mat

path=ss;

disp('                                                                 ');
disp(['            ELAPSED TIME:   ', num2str(toc)]                     );
disp('                                                                 ');


elapsedtime=toc;    
    