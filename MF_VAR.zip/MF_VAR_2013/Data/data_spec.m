load release_date.txt
year  = 1964:1:2051;
month = 1:1:12;
month = repmat(month',length(year),1);
year  = kron(year,ones(1,12))';
time  = [year month];
time  = [[1:1:length(time)]' time];

calendar       = release_date(find((release_date(:,1)-today(2))==0),:);
data_until     = calendar((max(find(calendar(:,2)-today(3)<=0))),:); 

today_loc      = time(find((time(:,2)-today(1))==0),1:3);
today_loc      = today_loc(find((today_loc(:,3)-today(2))==0),1:3);

data_available = zeros(length(time),nv);    

for i=1:nv
    data_available(1:today_loc+data_until(i+2),i)=1;
end
    
data_available = [time data_available];    

% estimation sample
index_YY       = data_available(1:min(sum(data_available)),:);
index_YN       = data_available(min(sum(data_available))+1:today_loc(1)-1,:);

index_NY       = index_YN(:,4:end)';
index_NYM      = index_YN(:,4:Nm+3)';
index_NYQ      = index_YN(:,Nm+4:end)';

      

