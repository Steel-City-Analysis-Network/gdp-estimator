% load INVFIX data from FRB-MN: 1964/01/01 - 2011/10/01
[YQ0, YQX]  = xlsread('YQ.xls');
YQ          = log(YQ0);
% 1967/01/01 - 1995/01/01
INVFIX      = YQ(13:125,2);
grINVFIX    = INVFIX(2:end)-INVFIX(1:end-1);
T__         = length(grINVFIX);
% 1967/01/01 - 1990/01/01
INVFIX2     = YQ(13:105,2);
grINVFIX2   = INVFIX2(2:end)-INVFIX2(1:end-1);
T2__        = length(grINVFIX2);

% 1:113 selects data from 1967/01/01 - 1995/01/01
% 404:471 selects vintages from 2003/12/10 - 2009/06/25
% 472:end selects vintages from 2009/07/31 - present
fillin      = nan(size(var(2).data(1:112,404:end)));
fillbench   = zeros(size(grINVFIX));
fillbench2  = zeros(size(grINVFIX2));
fillorigin  = [var(2).data(93,404:471) var(2).data(113,472:end)];

for i=1:T__
    fillbench(T__-i+1)=-sum(grINVFIX(T__-i+1:T__));
end
for i=1:T2__
    fillbench2(T2__-i+1)=-sum(grINVFIX2(T2__-i+1:T2__));
end

for j=1:length(fillorigin)
    if j>68
        NT_ = T__;   %cuts at 1994/12/01
        fillbench_ = fillbench;
    else
        NT_ = 92;    %cuts at 1989/12/01
        fillbench_ = fillbench2;
    end
    fillin(1:NT_,j) = fillbench_ + ones(NT_,1)*fillorigin(j);
end

replace   = var(2).data(1:112,404:end);
index_rep = ~isnan(replace);

replace(index_rep==0) = fillin(index_rep==0);
var(2).data(1:112,404:end) = replace;