
var(8).vdate(find(var(8).vdate==datenum('8/1/1997')))=datenum('7/31/1997');
var(8).vdate(find(var(8).vdate==datenum('11/3/1997')))=datenum('10/31/1997');
var(8).vdate(find(var(8).vdate==datenum('2/2/1998')))=datenum('1/31/1998');

var(8).vdate(find(var(8).vdate==datenum('5/1/1998')))=datenum('4/30/1998');
var(8).vdate(find(var(8).vdate==datenum('8/3/1998')))=datenum('7/31/1998');
var(8).vdate(find(var(8).vdate==datenum('11/2/1998')))=datenum('10/31/1998');
var(8).vdate(find(var(8).vdate==datenum('2/1/1999')))=datenum('1/31/1999');

var(8).vdate(find(var(8).vdate==datenum('5/3/1999')))=datenum('4/30/1999');
var(8).vdate(find(var(8).vdate==datenum('11/2/1999')))=datenum('10/31/1999');
var(8).vdate(find(var(8).vdate==datenum('8/1/2000')))=datenum('7/31/2000');
var(8).vdate(find(var(8).vdate==datenum('2/1/2001')))=datenum('1/31/2001');

var(8).vdate(find(var(8).vdate==datenum('11/1/2001')))=datenum('10/31/2001');
var(8).vdate(find(var(8).vdate==datenum('8/2/2002')))=datenum('7/31/2002');
var(8).vdate(find(var(8).vdate==datenum('11/1/2002')))=datenum('10/31/2002');
var(8).vdate(find(var(8).vdate==datenum('8/1/2003')))=datenum('7/31/2003');
var(8).vdate(find(var(8).vdate==datenum('2/2/2004')))=datenum('1/31/2004');

var(8).vdate(find(var(8).vdate==datenum('8/3/2004')))=datenum('7/31/2004');
var(8).vdate(find(var(8).vdate==datenum('11/1/2004')))=datenum('10/31/2004');
var(8).vdate(find(var(8).vdate==datenum('8/2/2005')))=datenum('7/31/2005');
var(8).vdate(find(var(8).vdate==datenum('5/1/2006')))=datenum('4/30/2006');

var(8).vdate(find(var(8).vdate==datenum('8/1/2006')))=datenum('7/31/2006');
var(8).vdate(find(var(8).vdate==datenum('2/1/2007')))=datenum('1/31/2007');
var(8).vdate(find(var(8).vdate==datenum('11/1/2007')))=datenum('10/31/2007');
var(8).vdate(find(var(8).vdate==datenum('5/1/2008')))=datenum('4/30/2008');
var(8).vdate(find(var(8).vdate==datenum('8/4/2008')))=datenum('7/31/2008');
var(8).vdate(find(var(8).vdate==datenum('2/2/2009')))=datenum('1/31/2009');
var(8).vdate(find(var(8).vdate==datenum('8/4/2009')))=datenum('7/31/2009');
var(8).vdate(find(var(8).vdate==datenum('2/1/2010')))=datenum('1/31/2010');