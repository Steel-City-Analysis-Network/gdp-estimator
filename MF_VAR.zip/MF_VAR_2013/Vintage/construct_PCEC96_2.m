% load INVFIX data from FRB-MN: 1964/01/01 - 2012/01/01
[YM0, YMX]  = xlsread('YM.xls');
YM          = log(YM0);
% 1967/01/01 - 1995/01/01
PCE         = YM(37:373,8);
grPCE       = PCE(2:end)-PCE(1:end-1);
T__         = length(grPCE);
% 1967/01/01 - 1990/01/01
PCE2        = YM(37:313,8);
grPCE2      = PCE2(2:end)-PCE2(1:end-1);
T2__        = length(grPCE2);

% 404:471 selects vintages from 2003/12/23 - 2009/06/26
% 472:end selects vintages from 2009/08/04 - present
ffillin      = nan(size(var(8).data(1:336,291:end)));
ffillbench   = zeros(size(grPCE));
ffillbench2  = zeros(size(grPCE2));
ffillorigin  = [var(8).data(277,291:358) var(8).data(337,359:end)];

for i=1:T__
    ffillbench(T__-i+1)=-sum(grPCE(T__-i+1:T__));
end
for i=1:T2__
    ffillbench2(T2__-i+1)=-sum(grPCE2(T2__-i+1:T2__));
end

for j=1:length(ffillorigin)
    if j>68
        NT_ = T__;   %cuts at 1994/12/01
        ffillbench_ = ffillbench;
    else
        NT_ = 276;    %cuts at 1989/12/01
        ffillbench_ = ffillbench2;
    end
    ffillin(1:NT_,j) = ffillbench_ + ones(NT_,1)*ffillorigin(j);
end

replace2   = var(8).data(1:336,291:end);
index_rep2 = ~isnan(replace2);

replace2(index_rep2==0) = ffillin(index_rep2==0);
var(8).data(1:336,291:end) = replace2;
