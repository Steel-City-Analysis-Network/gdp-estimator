%==========================================================================
%
%            MFREQ BVAR : MINNESOTA PRIOR HYPERPARAMETERS SELECTION                     
%
%            Date : MAY, 2013
%
%            Note : Using grid search, this code obtains the set of 
%                   hyperparameters that maximizes the marginal likelihood     
%
%            Code Written By:  Frank Schorfheide   schorf@ssc.upenn.edu
%                              Dongho Song         donghos@sas.upenn.edu
%==========================================================================


%==========================================================================
%                             HOUSEKEEPING
%==========================================================================

tic
close all
clear all
clc

ss = path;

path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

number   = 1;            % number of iterations to obtain convergence
nsim     = 10000;        % number of draws from Posterior Density
nburn    = 0.2*nsim;     % number of draws to discard
nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33

% set today automatically: year-month-date-hour
today = datevec(now);
today = today(1:3);

% store hyperparameters
hyp_vector = zeros(nrs,5);

%% load vintages
create_vintage_NEW           

load hyp_var4.txt;           % selected hyperparameters from BVAR_PRIOR
hyp = hyp_var4;

lambda1=hyp(1);lambda2=hyp(2);lambda3=hyp(3);lambda4=hyp(4);lambda5=hyp(5);

for rrrr=1:1;%length(nrs_vec)   
    
rrr = nrs_vec(rrrr);    
vm_loaddatar_4


%======================================================================
%                     HYPERPARAMETER SELECTION 
%======================================================================

for hhh=1:number
    

disp('       BEGIN HYPERPARAMETER SEARCH')

%==========================================================================
%              HYPERPARAMETERS SELECTION: GRID SEARCH
%==========================================================================
% name of hyperparameters: 
%
% 1)lambda1, 2)lambda2, 3)lambda3, 4)lambda4, 5)lambda5
% 
% the role of hyperparameters:
%
% 1) overall tightness  
% 2) scaling down the variance for the coefficients of a distant lag  
% 3) number of observations used for obtaining the prior for the covariance 
%    matrix of error terms                          
% 4) tuning parameter for coefficients for constant 
% 5) tuning parameter for the covariance between coefficients  

% notes: we fix lambda3=1 
%
%==========================================================================
if rrr==1
    mfiner    = 0;       % 1: finer grid search || 0: no finer grid search
else
    mfiner    = 0;       % 1: finer grid search || 0: no finer grid search
    mflambda  = 20;      % number of finer grid points 
end

if mfiner ==0
    
mlambda1  = 10;
mlambda2  = 1;
mlambda4  = 10;
mlambda5  = 10;

% use nonuniform grid for lambda1

lambda1_grid    = linspace(0.01,   0.5,  mlambda1*1);
lambda2_grid    = linspace(0.1,2,mlambda2*1);
%lambda4_grid    = linspace(1,5,mlambda4*1);
%lambda5_grid    = linspace(1,5,mlambda5*1);


% lambda1_grid = [0.7916 0.8437 0.8958];
% lambda2_grid = [2];
 lambda4_grid = [1 ];
 lambda5_grid = [4 ];



%==========================================================================
%           BAYESIAN ESTIMATION OF VAR:  COARSE GRID SEARCH
%==========================================================================

% marginal data density plotted in 3D surface
mdd_vector  = zeros(length(lambda1_grid),length(lambda2_grid),...
                    length(lambda4_grid),length(lambda5_grid));

                
for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid)   
            for H5=1:length(lambda5_grid)
            
                
                % hyperparameters 
                lambda1=lambda1_grid(H1);
                lambda2=lambda2_grid(H2);
                lambda3=1;
                lambda4=lambda4_grid(H4);
                lambda5=lambda5_grid(H5);
                
                % compute marginal density
                disp('                                     ');
                disp('    BVAR: MARGINAL DATA DENSITY'      );
                disp('                                     ');
                disp(['   RECURSIVE SAMPLE:  ', num2str(rrr)]);
                disp('                                     ');
                disp(['   TOTAL ITERATION:   ', num2str(hhh)]);
                disp(['   LAMBDA_1:   ', num2str(H1)]       );
                disp(['   LAMBDA_2:   ', num2str(H2)]       );
                disp(['   LAMBDA_4:   ', num2str(H4)]       );
                disp(['   LAMBDA_5:   ', num2str(H5)]       );
                
                hyp   = [lambda1;lambda2;lambda3;lambda4;lambda5];                             

                MF_BVAR_PRIOR_SUB_4

                YY = [Ym squeeze(median(lstate(:,:,1:size(Ym,1))))];
                YY = YY(40:end,:);

                nobs_   = size(YY,1)-T0;
                spec    = [nlags T0 nex nv nobs_];

                %[mdd] = vm_mdd(hyp,YY,spec);              
                mdd = vm_mdd_all4_v2(lstate,zmddsim,nsim,nobs)
                
                mdd_vector(H1,H2,H4,H5)=mdd;               
               
                save results_prior_all4v2.mat
                
            end                     
        end        
    end    
end

mddmax=max(max(max(max(mdd_vector))));

for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid) 
            for H5=1:length(lambda5_grid)
                if mdd_vector(H1,H2,H4,H5)==mddmax
                    disp('                                     ');
                    disp('  SELECTED HYPERPARAMETERS           ');
                    grid_answer=[H1,H2,H4,H5];
                    answer=[lambda1_grid(H1);lambda2_grid(H2);...
                        lambda3;lambda4_grid(H4);lambda5_grid(H5)]
                    disp('                                     ');
                end
            end
        end
    end
end

elseif mfiner==1

lambda1_grid = linspace(answer(1)-2*answer(1)/20,answer(1)+2*answer(1)/20,mflambda);
lambda2_grid = linspace(answer(2)-2*answer(2)/20,answer(2)+2*answer(2)/20,mflambda);
lambda4_grid = linspace(answer(4)-2*answer(4)/20,answer(4)+2*answer(4)/20,mflambda);
lambda5_grid = linspace(answer(5)-2*answer(5)/20,answer(5)+2*answer(5)/20,mflambda);

% marginal data density plotted in 3D surface
mdd_vector  = zeros(length(lambda1_grid),length(lambda2_grid),...
                    length(lambda4_grid),length(lambda5_grid));
                
for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid)   
            for H5=1:length(lambda5_grid)
            
                
                % hyperparameters 
                lambda1=lambda1_grid(H1);
                lambda2=lambda2_grid(H2);
                lambda3=1;
                lambda4=lambda4_grid(H4);
                lambda5=lambda5_grid(H5);
                
                % compute marginal density
                disp('                                     ');
                disp('    BVAR: MARGINAL DATA DENSITY'      );
                disp('                                     ');
                disp(['   RECURSIVE SAMPLE:  ', num2str(rrr)]);
                disp('                                     ');
                disp(['   TOTAL ITERATION:   ', num2str(hhh)]);
                disp(['   LAMBDA_1:   ', num2str(H1)]       );
                disp(['   LAMBDA_2:   ', num2str(H2)]       );
                disp(['   LAMBDA_4:   ', num2str(H4)]       );
                disp(['   LAMBDA_5:   ', num2str(H5)]       );
                
                hyp   = [lambda1;lambda2;lambda3;lambda4;lambda5];
                
                [mdd] = vm_mdd2(hyp,YY,spec);              
                
                mdd_vector(H1,H2,H4,H5)=mdd;
            end                     
        end        
    end    
end

mddmax=max(max(max(max(mdd_vector))));

for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid) 
            for H5=1:length(lambda5_grid)
                if mdd_vector(H1,H2,H4,H5)==mddmax
                    disp('                                     ');
                    disp('  SELECTED HYPERPARAMETERS           ');
                    grid_answer=[H1,H2,H4,H5];
                    answer=[lambda1_grid(H1);lambda2_grid(H2);...
                        lambda3;lambda4_grid(H4);lambda5_grid(H5)]
                    disp('                                     ');
                end
            end
        end
    end
end

end

% %==========================================================================
% %                           SUMMARY FIGURES
% %==========================================================================
% clc;
% disp('                                                                   ');
% disp('                       GRID LOCATION'                               );
% grid_answer'
% disp('                                                                   ');
% disp('                   SELECTED HYPERPARAMETERS'                        );
% answer
% disp('                                                                   ');
% 
% 
pnames = strvcat( '\lambda_{3}, \lambda_{4}, and \lambda_{5} fixed',...
                  '\lambda_{2}, \lambda_{3}, and \lambda_{4} fixed',...
                  '\lambda_{2}, \lambda_{3}, and \lambda_{5} fixed');
pnames1= strvcat( '\lambda_{1}','\lambda_{2}','\lambda_{3}','\lambda_{4}','\lambda_{5}');
pnames2= strvcat( '\lambda_{1}','\lambda_{2}','\lambda_{3}','\lambda_{4}','\lambda_{5}');
pnames3= strvcat( 'MARGINAL DATA DENSITY' );

% scrsz = get(0,'ScreenSize');
% figure('Position',[20,20,900,600],'Name',...
%       'MARGINAL DATA DENSITY','Color','w',...
%       'Position',[1 scrsz(4)/2.5 scrsz(3) scrsz(4)/2])
% subplot(1,3,1)    
%     mesh(squeeze(mdd_vector(:,:,grid_answer(3),grid_answer(4))));
%     title(pnames(1,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(2,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
% subplot(1,3,2)    
%     mesh(squeeze(mdd_vector(:,grid_answer(2),grid_answer(3),:)));
%     title(pnames(2,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(5,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
% subplot(1,3,3)    
%     mesh(squeeze(mdd_vector(:,grid_answer(2),:,grid_answer(4))));
%     title(pnames(3,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(4,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
%     

%==========================================================================
%                               SAVE 
%==========================================================================
% note: this only saves the output of the last routine
%saveas(gcf,'Figures/Marginal Data Density Surface.bmp')
save('Output/hyp_var4.txt','answer','-ASCII')
%save('Output/mdd.txt','mddmax','-ASCII')

end

hyp_vector(rrr,:) = answer';

end





path=ss;
 
disp(['                    ELAPSED TIME: ', num2str(toc)              ]);

elapsedtime=toc;

