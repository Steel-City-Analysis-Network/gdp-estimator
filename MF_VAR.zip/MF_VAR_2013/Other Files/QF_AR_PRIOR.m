%==========================================================================
%
%            QF AR : MINNESOTA PRIOR HYPERPARAMETERS SELECTION                     
%
%            Date : August, 2012
%
%            Note : Using grid search, this code obtains the set of 
%                   hyperparameters that maximizes the marginal likelihood     
%
%            Code Written By:  Frank Schorfheide   schorf@ssc.upenn.edu
%                              Dongho Song         donghos@sas.upenn.edu
%==========================================================================


%==========================================================================
%                             HOUSEKEEPING
%==========================================================================

tic
close all
clear all
clc

ss = path;

path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33

% store hyperparameters
hyp_vector = zeros(nrs,5,11);

%% LOAD DATA
create_vintage_NEW

for rrrr = 1:length(nrs_vec)

    rrr = nrs_vec(rrrr);
    vm_loaddataa    

   % LOOP    
    for mselect = 1:nv
        QF_AR_PRIOR_SUB
        hyp_vector(rrr,:,mselect) = answer;
    end   
save results_prior_qfar2.mat    
end



path=ss;
 
disp(['                    ELAPSED TIME: ', num2str(toc)              ]);

elapsedtime=toc;

