%==========================================================================
%
%            QF BVAR : MINNESOTA PRIOR HYPERPARAMETERS SELECTION                     
%
%            Date : AUGUST, 2011
%
%            Note : Using grid search, this code obtains the set of 
%                   hyperparameters that maximizes the marginal likelihood     
%
%            Code Written By:  Frank Schorfheide   schorf@ssc.upenn.edu
%                              Dongho Song         donghos@sas.upenn.edu
%==========================================================================


%==========================================================================
%                             HOUSEKEEPING
%==========================================================================

tic
close all
clear all
clc

ss = path;

path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33

pick     = kron(ones(1,12),[1 zeros(1,11)]);
nrs_sel  = nrs_vec(pick==1);



% store hyperparameters
hyp_vector = zeros(nrs,5);

%% LOAD DATA
create_vintage_NEW
    
for rrrr=1:length(nrs_sel)   
    
    rrr = nrs_sel(rrrr);
    vm_loaddataq        

%==========================================================================
%              HYPERPARAMETERS SELECTION: GRID SEARCH
%==========================================================================
% name of hyperparameters: 
%
% 1)lambda1, 2)lambda2, 3)lambda3, 4)lambda4, 5)lambda5
% 
% the role of hyperparameters:
%
% 1) overall tightness  
% 2) scaling down the variance for the coefficients of a distant lag  
% 3) number of observations used for obtaining the prior for the covariance 
%    matrix of error terms                          
% 4) tuning parameter for coefficients for constant 
% 5) tuning parameter for the covariance between coefficients  

% notes: we fix lambda3=1 
%
%==========================================================================

mfiner    = 0;           % 1: finer grid search || 0: no finer grid search
mflambda  = 15;          % number of finer grid points 

mlambda1  = 40;
mlambda2  = 40;
mlambda4  = 40;
mlambda5  = 40;

% % use nonuniform grid for lambda1
% lambda11_grid   = linspace(0.01,  1,  mlambda1*2);
% lambda12_grid   = linspace(1,   2,  mlambda1*2);
% lambda13_grid   = linspace(2,   5,  mlambda1*2 );
% 
% lambda1_grid    = [lambda11_grid lambda12_grid lambda13_grid ];
% lambda2_grid    = linspace(0.01,1,mlambda2*2);
% lambda4_grid    = linspace(0.01,3,mlambda4*1);
% lambda5_grid    = linspace(0.01,3,mlambda5*2);

lambda1_grid    = linspace(0.01,10,mlambda1*1);
lambda2_grid    = linspace(0.01,10,mlambda2*1);
lambda4_grid    = linspace(0.1,10,mlambda4*1);
lambda5_grid    = linspace(0.1,10,mlambda5*1);

%==========================================================================
%           BAYESIAN ESTIMATION OF VAR:  COARSE GRID SEARCH
%==========================================================================

% marginal data density plotted in 3D surface
mdd_vector  = zeros(length(lambda1_grid),length(lambda2_grid),...
                    length(lambda4_grid),length(lambda5_grid));

                
for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid)   
            for H5=1:length(lambda5_grid)
            
                
                % hyperparameters 
                lambda1=lambda1_grid(H1);
                lambda2=lambda2_grid(H2);
                lambda3=1;
                lambda4=lambda4_grid(H4);
                lambda5=lambda5_grid(H5);
                
                % compute marginal density
                disp('                                     ');
                disp('    BVAR: MARGINAL DATA DENSITY'      );
                disp('                                     ');
                disp(['   RECURSIVE SAMPLE:  ', num2str(rrr)]);
                disp('                                     ');
                disp(['   LAMBDA_1:   ', num2str(H1)]       );
                disp(['   LAMBDA_2:   ', num2str(H2)]       );
                disp(['   LAMBDA_4:   ', num2str(H4)]       );
                disp(['   LAMBDA_5:   ', num2str(H5)]       );
                
                hyp   = [lambda1;lambda2;lambda3;lambda4;lambda5];
                
                [mdd] = vm_mdd(hyp,YY,spec);              
                
                mdd_vector(H1,H2,H4,H5)=mdd;
            end                     
        end        
    end    
end

mddmax=max(max(max(max(mdd_vector))));

for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid) 
            for H5=1:length(lambda5_grid)
                if mdd_vector(H1,H2,H4,H5)==mddmax
                    disp('                                     ');
                    disp('  SELECTED HYPERPARAMETERS           ');
                    grid_answer=[H1,H2,H4,H5];
                    answer=[lambda1_grid(H1);lambda2_grid(H2);...
                        lambda3;lambda4_grid(H4);lambda5_grid(H5)]
                    disp('                                     ');
                end
            end
        end
    end
end


%==========================================================================
%             BAYESIAN ESTIMATION OF VAR: FINER GRID SEARCH
%==========================================================================

if mfiner==1

lambda1_grid = linspace(answer(1)-2*answer(1)/40,answer(1)+2*answer(1)/40,mflambda);
lambda2_grid = linspace(answer(2)-2*answer(2)/40,answer(2)+2*answer(2)/40,mflambda);
lambda4_grid = linspace(answer(4)-2*answer(4)/40,answer(4)+2*answer(4)/40,mflambda);
lambda5_grid = linspace(answer(5)-2*answer(5)/40,answer(5)+2*answer(5)/40,mflambda);

% marginal data density plotted in 3D surface
mdd_vector  = zeros(length(lambda1_grid),length(lambda2_grid),...
                    length(lambda4_grid),length(lambda5_grid));
                
for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid)   
            for H5=1:length(lambda5_grid)
            
                
                % hyperparameters 
                lambda1=lambda1_grid(H1);
                lambda2=lambda2_grid(H2);
                lambda3=1;
                lambda4=lambda4_grid(H4);
                lambda5=lambda5_grid(H5);
                
                % compute marginal density
                disp('                                     ');
                disp('    BVAR: MARGINAL DATA DENSITY'      );
                disp('                                     ');
                disp('                                     ');
                disp(['   LAMBDA_1:   ', num2str(H1)]       );
                disp(['   LAMBDA_2:   ', num2str(H2)]       );
                disp(['   LAMBDA_4:   ', num2str(H4)]       );
                disp(['   LAMBDA_5:   ', num2str(H5)]       );
                
                hyp   = [lambda1;lambda2;lambda3;lambda4;lambda5];
                
                [mdd] = vm_mdd2(hyp,YY,spec);              
                
                mdd_vector(H1,H2,H4,H5)=mdd;
            end                     
        end        
    end    
end

mddmax=max(max(max(max(mdd_vector))));

for H1=1:length(lambda1_grid)    
    for H2=1:length(lambda2_grid)        
        for H4=1:length(lambda4_grid) 
            for H5=1:length(lambda5_grid)
                if mdd_vector(H1,H2,H4,H5)==mddmax
                    disp('                                     ');
                    disp('  SELECTED HYPERPARAMETERS           ');
                    grid_answer=[H1,H2,H4,H5];
                    answer=[lambda1_grid(H1);lambda2_grid(H2);...
                        lambda3;lambda4_grid(H4);lambda5_grid(H5)]
                    disp('                                     ');
                end
            end
        end
    end
end

end

%==========================================================================
%                           SUMMARY FIGURES
%==========================================================================
clc;
disp('                                                                   ');
disp('                       GRID LOCATION'                               );
grid_answer'
disp('                                                                   ');
disp('                   SELECTED HYPERPARAMETERS'                        );
answer
disp('                                                                   ');


% pnames = strvcat( 'lambda3, lambda4, and lambda5 fixed',...
%                   'lambda2, lambda3, and lambda4 fixed',...
%                   'lambda2, lambda3, and lambda5 fixed');
% pnames1= strvcat( 'lambda1','lambda2','lambda3','lambda4','lambda5');
% pnames2= strvcat( 'lambda1','lambda2','lambda3','lambda4','lambda5');
% pnames3= strvcat( 'MARGINAL DATA DENSITY' );
% 
% scrsz = get(0,'ScreenSize');
% figure('Position',[20,20,900,600],'Name',...
%       'MARGINAL DATA DENSITY','Color','w',...
%       'Position',[1 scrsz(4)/2.5 scrsz(3) scrsz(4)/2])
% subplot(1,3,1)    
%     mesh(squeeze(mdd_vector(:,:,grid_answer(3),grid_answer(4))));
%     title(pnames(1,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(2,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
% subplot(1,3,2)    
%     mesh(squeeze(mdd_vector(:,grid_answer(2),grid_answer(3),:)));
%     title(pnames(2,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(5,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
% subplot(1,3,3)    
%     mesh(squeeze(mdd_vector(:,grid_answer(2),:,grid_answer(4))));
%     title(pnames(3,:),'FontSize',15,'FontWeight','bold');
%     ylabel(pnames1(1,:),'FontSize',15,'FontWeight','bold');
%     xlabel(pnames2(4,:),'FontSize',15,'FontWeight','bold');
%     zlabel(pnames3,'FontSize',15,'FontWeight','bold');
    

%==========================================================================
%                               SAVE 
%==========================================================================
save('Output/hypq.txt','answer','-ASCII')

hyp_vector(rrr,:) = answer';

save results_prior_qfvar.mat

end




path=ss;
 
disp(['                    ELAPSED TIME: ', num2str(toc)              ]);

elapsedtime=toc;

