%======================================================================
%                           BLOCK ALGORITHM
%======================================================================
% dummy observations and actual observations
[mdd,YYact,YYdum,XXact,XXdum]=vm_mdd(hyp,YY,spec);

% draws from posterior distribution
vm_minnesota        
                    
%======================================================================
%                             FORECASTING
%======================================================================
disp('                                                                ');
disp('     QUARTERLY FREQUENCY AUTOREGRESSIVE MODEL OF ORDER 2        ');
disp('                                                                ');
disp('                                                                ');
disp('             - FORECASTING -                                     ');
disp('                                                                ');

YYvector   = zeros(nsim,H,nv);         % collects forecast      
YYvector_g = zeros(nsim,H,nv);         % collects forecast in growth terms

clear post_phi post_sig               % clear previously defined values
counter   = 0;


for jj=1:nsim
    
    post_phi=squeeze(Phip(jj,:,:));
    post_sig=squeeze(Sigmap(jj,:,:));
    
    post_phi=post_phi';
    post_sig=diag(diag(post_sig));
    
    YYact = YYact(end,:);
    XXact = XXact(end,:);
    
    vm_forecast                       % Output: YYpred 
    
    counter         = counter +1; 
     
    if counter==1000
    disp('                                                              '); 
    disp(['       RECURSIVE SAMPLE:   ', num2str(rrr)]                   );    
    disp('                                                              '); 
    disp(['       VARIABLE:   ', num2str(kkk)]                           );
    disp('                                                              ');
    disp(['       FORECAST HORIZON:   ', num2str(H)]                     );
    disp('                                                              ');
    disp(['       DRAW NUMBER:   ', num2str(jj)]                         );
    disp('                                                              ');
    disp(['       REMAINING DRAWS:   ', num2str(nsim-jj)]                );
    disp('                                                              ');

    counter = 0;
    end    
    
    YYvector(jj,:,:)    = YYpred;    
    YYvector_g(jj,:,:)  = 100*(YYpred1(2:end,:)-YYpred1(1:end-1,:));
end