%======================================================================
%
%        MF BVAR : MIXED FREQ BAYESIAN VAR INFERENCE AND FORECASTING                     
%
%        Date : AUGUST, 2012
%
%        Note : Given selected hyperparameters, this code performs  
%               Bayesian Inference and obtains forecast estimates      
%
%        Code Written By:  Frank Schorfheide  schorf@ssc.upenn.edu
%                          Dongho Song        donghos@sas.upenn.edu
%======================================================================


%======================================================================
%                          HOUSEKEEPING
%======================================================================

tic
close all
clear all
clc

ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

%clear diary
%diary('Figures/TABLE')

nsim     = 1000;        % number of draws from Posterior Density
nburn    = 0.0*nsim;     % number of draws to discard
nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33
H        = 8;
nv       = 4;

FL_vector95 = zeros(nrs,H,nv);
FL_vector80 = zeros(nrs,H,nv);
FL_vector50 = zeros(nrs,H,nv);
FL_vector20 = zeros(nrs,H,nv);
FL_vector05 = zeros(nrs,H,nv);
FL_vector   = zeros(nrs,H,nv);

FG_vector95 = zeros(nrs,H,nv);
FG_vector80 = zeros(nrs,H,nv);
FG_vector50 = zeros(nrs,H,nv);
FG_vector20 = zeros(nrs,H,nv);
FG_vector05 = zeros(nrs,H,nv);
FG_vector   = zeros(nrs,H,nv);

PIT_LC      = zeros(nrs,H,nv);
PIT_GC      = zeros(nrs,H,nv);
PIT_L       = zeros(nrs,H,nv);
PIT_G       = zeros(nrs,H,nv);

%======================================================================
%                          HYPERPARAMETERS
%======================================================================
load hyp_var4.txt;           % selected hyperparameters from BVAR_PRIOR
hyp = hyp_var4;
load hyp_vec_var4.txt;
lambda1=hyp(1);lambda2=hyp(2);lambda3=hyp(3);lambda4=hyp(4);lambda5=hyp(5);

%======================================================================
%                    BAYESIAN ESTIMATION OF VAR
%======================================================================

disp('                                                                ');
disp('                    MIXED FREQUENCY VAR: LOAD VINTAGES          ');
disp('                                                                ');
disp('                      - ASSEMBLE REAL TIME DATASET-             ');
disp('                                                                ');
%% load vintages
create_vintage_NEW

for rrrr=1:1;%length(nrs_vec)

    rrr = nrs_vec(rrrr);
    hyp = hyp_vec_var4(rrr,:);
    vm_loaddatar_4

disp(['                         - RECURSIVE SAMPLE:  ', num2str(rrr)]     );
disp('                                                                ');
disp('                                                                ');
disp('                                                                ');
disp('                    MIXED FREQUENCY VAR: ESTIMATION             ');
disp('                                                                ');
disp('                                                                ');
disp('                          - BLOCK ALGORITHM (1)-                ');
disp('                                                                ');
disp('                PARAMETER ESTIMATION WITH BALANCED PANEL        ');
disp('                                                                ');
%======================================================================
%                     BLOCK 1: PARAMETER ESTIMATION 
%======================================================================

% Matrices for collecting draws from Posterior Density

Sigmap    = zeros(nsim,nv,nv);
Phip      = zeros(nsim,nv*p+1,nv);
Cons      = zeros(nsim,nv);
lstate    = zeros(nsim,Nq,Tnobs);
YYactsim  = zeros(nsim,4,nv);
XXactsim  = zeros(nsim,4,nv*p+1);
likesim   = zeros(nsim,1);
priorsim  = zeros(nsim,2);
parasim   = zeros(nsim,(nv*p+1)*nv+nv*(nv+1)/2);

At_mat    = zeros(Tnobs,Nq*(p+1));
Pt_mat    = zeros(Tnobs,(Nq*(p+1))^2);
Atildemat = zeros(nsim,Nq*(p+1));
Ptildemat = zeros(nsim,Nq*(p+1),Nq*(p+1));
loglh   = 0;
counter = 0;


%% Define Coefficient Matrices
% Define phi(qm), phi(qq), phi(qc)
phi_qm = zeros(Nm*p,Nq);
for i=1:p
    phi_qm(Nm*(i-1)+1:Nm*i,:)=Phi((i-1)*(Nm+Nq)+1:(i-1)*(Nm+Nq)+Nm,Nm+1:end);
end
phi_qq = zeros(Nq*p,Nq);
for i=1:p
    phi_qq(Nq*(i-1)+1:Nq*i,:)=Phi((i-1)*(Nm+Nq)+Nm+1:i*(Nm+Nq),Nm+1:end);
end
phi_qc = Phi(end,Nm+1:end);

% Define phi(mm), phi(mq), phi(mc)
phi_mm = zeros(Nm*p,Nm);
for i=1:p
    phi_mm(Nm*(i-1)+1:Nm*i,:)=Phi((i-1)*(Nm+Nq)+1:(i-1)*(Nm+Nq)+Nm,1:Nm);
end
phi_mq = zeros(Nq*p,Nm);
for i=1:p
    phi_mq(Nq*(i-1)+1:Nq*i,:)=Phi((i-1)*(Nm+Nq)+Nm+1:i*(Nm+Nq),1:Nm);
end
phi_mc = Phi(end,1:Nm);

% Define Covariance Term sig_mm, sig_mq, sig_qm, sig_qq
sig_mm  = sigma(1:Nm,1:Nm);
sig_mq  = 0.5*(sigma(1:Nm,Nm+1:end)+sigma(Nm+1:end,1:Nm)');
sig_qm  = 0.5*(sigma(Nm+1:end,1:Nm)+sigma(1:Nm,Nm+1:end)');
sig_qq  = sigma(Nm+1:end,Nm+1:end);

% Define Transition Equation Matrices
GAMMAs  = [[phi_qq' zeros(Nq,Nq)];[eye(p*Nq,p*Nq) zeros(p*Nq,Nq)]];
GAMMAz  = [phi_qm'; zeros(p*Nq,p*Nm)];
GAMMAc  = [phi_qc'; zeros(p*Nq,1)];
GAMMAu  = [eye(Nq); zeros(p*Nq,Nq)];

% Define Measurement Equation Matrices
LAMBDAs = [[zeros(Nm,Nq) phi_mq'];(1/3)*[eye(Nq) eye(Nq) eye(Nq) zeros(Nq,Nq*(p-2))]];
LAMBDAz = [phi_mm'; zeros(Nq,p*Nm)];
LAMBDAc = [phi_mc'; zeros(Nq,1)];
LAMBDAu = [eye(Nm); zeros(Nq,Nm)];

% Define W matrix
Wmatrix   = [eye(Nm) zeros(Nm,Nq)];
LAMBDAs_t = Wmatrix * LAMBDAs;
LAMBDAz_t = Wmatrix * LAMBDAz;
LAMBDAc_t = Wmatrix * LAMBDAc;
LAMBDAu_t = Wmatrix * LAMBDAu;

%% Initialization   
init_var  = zeros(Nq*(p+1),Nq*(p+1));
for kk=1:p+1
    init_var = GAMMAs * init_var * GAMMAs' + GAMMAu * sig_qq * GAMMAu';
end

Zm_init   = zeros(T0-p-1,Nm*p);
i=1;
while i<=p
    Zm_init(:,(i-1)*Nm+1:i*Nm) = YM(p+1-(i-1):T0-i,:);
    i=i+1;
end

[init_At,init_Pt] = vm_initialize_4(GAMMAs,GAMMAz,GAMMAc,GAMMAu,...
LAMBDAs,LAMBDAz,LAMBDAc,LAMBDAu,LAMBDAs_t,LAMBDAz_t,LAMBDAc_t,LAMBDAu_t,...
sig_qq,sig_mm,sig_qm,sig_mq,Zm_init,YDATA,init_mean,init_var,spec_init);

%% Set Dataset
% Lagged Monthly Observations
Zm   = zeros(nobs,Nm*p);
i=1;
while i<=p
    Zm(:,(i-1)*Nm+1:i*Nm) = YM(T0-(i-1):T0+nobs-i,:);
    i=i+1;
end

% Observations in Monthly Freq
Yq   = YQ(T0+1:nobs+T0,:);
Ym   = YM(T0+1:nobs+T0,:);

%% Estimation
MF_BVAR_MAIN_SUB_4
% Save the Posterior Distributions
%======================================================================
%                     BLOCK 3: FORECASTING
%======================================================================
disp('                                                                ');
disp('                                                                ');
disp('                                                                ');
disp('                    MIXED FREQUENCY VAR: FORECASTING            ');
disp('                                                                ');
disp('                          - BLOCK ALGORITHM (2)-                ');
disp('                                                                ');
disp('                                                                ');
disp('                                                                ');

% do not fix federal funds rate
% store forecasts in monthly frequency
YYvector_ml  = zeros(nsim,H,Nm+Nq);     % collects now/forecast      
YYvector_mg  = zeros(nsim,H,Nm+Nq);
% store forecasts in quarterly frequency
YYvector_ql  = zeros(nsim,H/3,Nm+Nq);   
YYvector_qg  = zeros(nsim,H/3,Nm+Nq);

% % fix federal funds rate
% % store forecasts in monthly frequency
% FYYvector_ml  = zeros(nsim,H,Nm+Nq);     % collects now/forecast      
% FYYvector_mg  = zeros(nsim,H,Nm+Nq);
% % store forecasts in quarterly frequency
% FYYvector_ql  = zeros(nsim,H/3,Nm+Nq);   
% FYYvector_qg  = zeros(nsim,H/3,Nm+Nq);

counter   = 0;

for jj=1:nsim
    
    
    YYact    = squeeze(YYactsim(jj,end,:));
    XXact    = squeeze(XXactsim(jj,end,:));    
    post_phi = squeeze(Phip(jj,:,:));
    post_sig = squeeze(Sigmap(jj,:,:));
    
    vm_forecast                       % Output: YYpred 
    
    counter         = counter +1; 
     
    if counter==1000
    disp('                                                              '); 
    disp(['                FORECAST HORIZON:   ', num2str(H)]            );
    disp('                                                              ');
    disp(['                DRAW NUMBER:   ', num2str(jj)]                );
    disp('                                                              ');
    disp(['                REMAINING DRAWS:   ', num2str(nsim-jj)]       );
    disp('                                                              ');

    counter = 0;
    end    
    
    %% 1) Now-/Forecasts without fixing Federal Funds Rates 
    % store in monthly frequency
    YYvector_ml(jj,:,:)  = YYpred;    
    YYvector_mg(jj,:,:)  = 100*(YYpred1(2:end,:)-YYpred1(1:end-1,:));
    % store forecasts in quarterly frequency
    for ll=1:(H/3)-1
    YYvector_ql(jj,ll+1,:) = ...
    mean(YYvector_ml(jj,3*ll+1-Tnew:3*(ll+1)-Tnew,:));
    end
    
    % store nowcasts in quarterly frequency
    YYnow=squeeze(YYactsim(jj,end-Tnew+1:end,:));
    
    if size(YYnow,1) > size(YYnow,2)
        YYnow = YYnow';
    end
    
    if size(squeeze(YYvector_ml(jj,1:3-Tnew,:)),1)>...
       size(squeeze(YYvector_ml(jj,1:3-Tnew,:)),2)
       YYfuture=squeeze(YYvector_ml(jj,1:3-Tnew,:))';
    else
       YYfuture=squeeze(YYvector_ml(jj,1:3-Tnew,:)); 
    end
    
    if Tnew==3
    YYvector_ql(jj,1,:) = mean(YYnow);
    else
    YYvector_ql(jj,1,:) = mean([YYnow;YYfuture]);
    end
    
    YYvector_qg(jj,1,:) = ...
    100*(squeeze(YYvector_ql(jj,1,:))- mean([Ym(end-2:end,:) Yq(end-2:end,:)])');
    for bb=2:H/3
    YYvector_qg(jj,bb,:) = ...
    100*(squeeze(YYvector_ql(jj,bb,:))-squeeze(YYvector_ql(jj,bb-1,:)));
    end
    
%     %% 2) Now-/Forecasts fixing Federal Funds Rates 
%     vm_forecast_fix
%     % store in monthly frequency
%     FYYvector_ml(jj,:,:)  = FYYpred;    
%     FYYvector_mg(jj,:,:)  = 100*(FYYpred1(2:end,:)-FYYpred1(1:end-1,:));
%     % store forecasts in quarterly frequency
%     for ll=1:(H/3)-1
%     FYYvector_ql(jj,ll+1,:) = ...
%     mean(FYYvector_ml(jj,3*ll+1-Tnew:3*(ll+1)-Tnew,:));
%     end
%     
%     % store nowcasts in quarterly frequency
%     FYYnow=squeeze(YYactsim(jj,end-Tnew+1:end,:));
%     
%     if size(FYYnow,1) > size(FYYnow,2)
%         FYYnow = FYYnow';
%     end
%     
%     if size(squeeze(FYYvector_ml(jj,1:3-Tnew,:)),1)>...
%        size(squeeze(FYYvector_ml(jj,1:3-Tnew,:)),2)
%        FYYfuture=squeeze(FYYvector_ml(jj,1:3-Tnew,:))';
%     else
%        FYYfuture=squeeze(FYYvector_ml(jj,1:3-Tnew,:)); 
%     end
%     
%     if Tnew==3
%     FYYvector_ql(jj,1,:) = mean(FYYnow);
%     else
%     FYYvector_ql(jj,1,:) = mean([FYYnow;FYYfuture]);
%     end
%     
%     FYYvector_qg(jj,1,:) = ...
%     100*(squeeze(FYYvector_ql(jj,1,:))- mean([Ym(end-2:end,:) Yq(end-2:end,:)])');
%     for bb=2:H/3
%     FYYvector_qg(jj,bb,:) = ...
%     100*(squeeze(FYYvector_ql(jj,bb,:))-squeeze(FYYvector_ql(jj,bb-1,:)));
%     end
end

%======================================================================
%                             FIGURES
%======================================================================
% throw out nburn iterations
YYvector_ql  = YYvector_ql(nburn+1:end,:,:);
YYvector_qg  = YYvector_qg(nburn+1:end,:,:);
[yl95,yl80,yl50,yl20,yl05] = moment(YYvector_ql);
[yg95,yg80,yg50,yg20,yg05] = moment(YYvector_qg);

% cumulative predictive distributions
YYvector_qlc = YYvector_ql;
YYvector_qgc = YYvector_qg;
for jj=1:nsim-nburn
    for hh=2:H/3
        YYvector_qlc(jj,hh,:) = mean(YYvector_ql(jj,1:hh,:));
        YYvector_qgc(jj,hh,:) = mean(YYvector_qg(jj,1:hh,:));
    end
end

% cumulative actual values
rs_flvlc  = rs_flvl;
rs_fgrthc = rs_fgrth;

for hh=2:H/3
    rs_flvlc(hh,:)  = mean(rs_flvl(1:hh,:));
    rs_fgrthc(hh,:) = mean(rs_fgrth(1:hh,:));
end

% compute unconditional probability integral transformation
pit_lc = zeros(H/3,nv);
pit_gc = zeros(H/3,nv);
pit_l  = zeros(H/3,nv);
pit_g  = zeros(H/3,nv);

for hh=1:H/3
    for ii=1:nv
        pit_gc(hh,ii) = mean(squeeze(YYvector_qgc(:,hh,ii))< ones(nsim-nburn,1)*rs_fgrthc(hh,ii));
        pit_lc(hh,ii) = mean(squeeze(YYvector_qlc(:,hh,ii))< ones(nsim-nburn,1)*rs_flvlc(hh,ii));
        pit_g(hh,ii)  = mean(squeeze(YYvector_qg(:,hh,ii))< ones(nsim-nburn,1)*rs_fgrth(hh,ii));
        pit_l(hh,ii)  = mean(squeeze(YYvector_ql(:,hh,ii))< ones(nsim-nburn,1)*rs_flvl(hh,ii));
    end
end

% FYYvector_ql = FYYvector_ql(nburn+1:end,:,:);
% FYYvector_qg = FYYvector_qg(nburn+1:end,:,:);

% scrsz = get(0,'ScreenSize');
% fig1=figure('Position',[20,20,900,600],'Name',...
%         'Now-/Forecasts','Color','w',...
%         'Position',[1 scrsz(4)/6 scrsz(3) scrsz(4)/1.5]);
% subplot(2,2,1)
% hold on;
% plot(rs_fgrth(:,4),'Color',[0.9 0.2 0.1],'LineWidth',3)
% plot(yg50(:,4),'Color',[0.4 0.4 0.4],'LineWidth',3,'LineStyle','--')
% title('Quarterly GDP Growth')
% subplot(2,2,2)
% hold on;
% plot(rs_fgrth(:,1),'Color',[0.9 0.2 0.1],'LineWidth',3)
% plot(yg50(:,1),'Color',[0.4 0.4 0.4],'LineWidth',3,'LineStyle','--')
% title('Quarterly CPI Growth')
% subplot(2,2,3)
% hold on;
% plot(rs_flvl(:,2),'Color',[0.9 0.2 0.1],'LineWidth',3)
% plot(yl50(:,2),'Color',[0.4 0.4 0.4],'LineWidth',3,'LineStyle','--')
% title('Quarterly UNRATE level')
% subplot(2,2,4)
% hold on;
% plot(rs_flvl(:,3),'Color',[0.9 0.2 0.1],'LineWidth',3)
% plot(yl50(:,3),'Color',[0.4 0.4 0.4],'LineWidth',3,'LineStyle','--')
% title('Quarterly FEDFUND level')

%vm_figures
%vm_summary 
%diary off

% save predictive distribution
FL_vector95(rrr,:,:) = yl95;
FL_vector80(rrr,:,:) = yl80;
FL_vector50(rrr,:,:) = yl50;
FL_vector20(rrr,:,:) = yl20;
FL_vector05(rrr,:,:) = yl05;
FL_vector(rrr,:,:)   = rs_flvl;

FG_vector95(rrr,:,:) = yg95;
FG_vector80(rrr,:,:) = yg80;
FG_vector50(rrr,:,:) = yg50;
FG_vector20(rrr,:,:) = yg20;
FG_vector05(rrr,:,:) = yg05;
FG_vector(rrr,:,:)   = rs_fgrth;

PIT_LC(rrr,:,:)      = pit_lc;
PIT_GC(rrr,:,:)      = pit_gc;
PIT_L(rrr,:,:)       = pit_l;
PIT_G(rrr,:,:)       = pit_g;

%dlmwrite('Output/YYvector_ql.csv',YYvector_ql, 'precision', '%.6f','newline','pc'); 
%dlmwrite('Output/YYvector_qg.csv',YYvector_qg, 'precision', '%.6f','newline','pc'); 
%dlmwrite('Output/FYYvector_ql.csv',FYYvector_ql, 'precision', '%.6f','newline','pc'); 
%dlmwrite('Output/FYYvector_qg.csv',FYYvector_qg, 'precision', '%.6f','newline','pc'); 
%save results_4_part_106_end.mat
end

%save results_RS_MFBVAR_var4.mat

path=ss;

disp('                                                                   ');
disp(['                        ELAPSED TIME:   ', num2str(toc)]          );
disp('                                                                   ');

elapsedtime=toc;
