%======================================================================
%                           BLOCK ALGORITHM
%======================================================================
% dummy observations and actual observations
[mdd,YYact,YYdum,XXact,XXdum]=vm_mdd(hyp,YY,spec);

% draws from posterior distribution
vm_minnesota        
                    
%======================================================================
%                             FORECASTING
%======================================================================
disp('                                                                ');
disp('        QUARTERLY FREQUENCY BAYESIAN VAR                        ');
disp('                                                                ');
disp('                                                                ');
disp('             - FORECASTING -                                     ');
disp('                                                                ');

YYvector   = zeros(nsim,H,nv);         % collects forecast      
YYvector_g = zeros(nsim,H,nv);         % collects forecast in growth terms

clear post_phi post_sig                % clear previously defined values
counter   = 0;
YYact = YYact(end,:)';
XXact = XXact(end,:)';
for jj=1:nsim
    
    post_phi=squeeze(Phip(jj,:,:));
    post_sig=squeeze(Sigmap(jj,:,:));
    
    vm_forecast                       % Output: YYpred 
    
    counter         = counter +1; 
     
    if counter==5000
    disp('                                                              '); 
    disp(['       FORECAST HORIZON:   ', num2str(H)]                     );
    disp('                                                              ');
    disp(['       DRAW NUMBER:   ', num2str(jj)]                         );
    disp('                                                              ');
    disp(['       REMAINING DRAWS:   ', num2str(nsim-jj)]                );
    disp('                                                              ');

    counter = 0;
    end    
    
    YYvector(jj,:,:)    = YYpred;    
    YYvector_g(jj,:,:)  = 100*(YYpred1(2:end,:)-YYpred1(1:end-1,:));
end