%======================================================================
%
%            QF BVAR : BAYESIAN INFERENCE AND FORECASTING                     
%
%            Date : AUGUST, 2012
%
%            Note : Given selected hyperparameters, this code performs  
%                   Bayesian Inference and obtains forecast estimates  
%            Note2: Adds next period's first release dataset and generates
%                   forecasts (mimics augmenting bluechip forecasts at H=1)
%
%            Code Written By:  Frank Schorfheide  schorf@ssc.upenn.edu
%                              Dongho Song        donghos@sas.upenn.edu
%======================================================================


%======================================================================
%                          HOUSEKEEPING
%======================================================================

tic
close all
clear all
clc

ss = path;
path('Data',path);
path('Figures',path);
path('Main Files',path);
path('Moment',path);
path('Gauss Files',path);
path('Output',path);
path('Vintage',path);
path('GB',path);

% STORE
nsim     = 10000;         % number of draws from Posterior Density
nburn    = 0.2*nsim;     % number of draws to discard
nrs      = 151;          % number of recursive samples <= rs_end-rs_start+1
nrs_vec  =[[1:1:27] [30 31 32] [34:1:144] [146:1:151]]; % missing PCE@28,29,145 FPIC@28,33
add_vec  = [];
for kk=1:50;
    add_vec = [add_vec [3*kk+1*ones(1,3)]];
end
add_vec  = [add_vec 151];

H        = 8;
nv       = 11;

FLQ_vector95 = zeros(nrs,H,nv);
FLQ_vector80 = zeros(nrs,H,nv);
FLQ_vector50 = zeros(nrs,H,nv);
FLQ_vector20 = zeros(nrs,H,nv);
FLQ_vector05 = zeros(nrs,H,nv);
FLQ_vector   = zeros(nrs,H,nv);

FGQ_vector95 = zeros(nrs,H,nv);
FGQ_vector80 = zeros(nrs,H,nv);
FGQ_vector50 = zeros(nrs,H,nv);
FGQ_vector20 = zeros(nrs,H,nv);
FGQ_vector05 = zeros(nrs,H,nv);
FGQ_vector   = zeros(nrs,H,nv);

QPIT_LC      = zeros(nrs,H,nv);
QPIT_GC      = zeros(nrs,H,nv);
QPIT_L       = zeros(nrs,H,nv);
QPIT_G       = zeros(nrs,H,nv);


% load data
create_vintage_NEW
H = 8;

%======================================================================
%                          HYPERPARAMETERS
%======================================================================
load hypq.txt;           % selected hyperparameters from BVAR_PRIOR
hyp = hypq;
lambda1=hyp(1);
lambda2=hyp(2);
lambda3=hyp(3);
lambda4=hyp(4);
lambda5=hyp(5);
load hypq_vec.txt 
%======================================================================
%            BAYESIAN ESTIMATION OF VAR, FORECASTING, RMSE
%======================================================================
disp('                                                                ');
disp('     QUARTERLY FREQUENCY QUARTERLY FREQUENCY VAR                ');
disp('                                                                ');
disp('                                                                ');
disp('             - ESTIMATION -                                     ');
disp('                                                                ');

% recursive sample 
for rrrr=1:length(nrs_vec)
    rrr = nrs_vec(rrrr);    
    hyp = hypq_vec(rrr,:);
    vm_loaddataq_v2  
    
    % RUN BLOCK ALGORITHM
    disp('                                                              ');
    disp(['       RECURSIVE SAMPLE:   ', num2str(rrr)]                   );
    disp('                                                              ');

    %======================================================================
    %                           BLOCK ALGORITHM
    %====================================================================== 
    % dummy observations and actual observations
    [mdd,YYact,YYdum,XXact,XXdum] = vm_mdd(hyp,YY,spec);

    % draws from posterior distribution
    vm_minnesota        
                    
    %======================================================================
    %                             FORECASTING
    %======================================================================
    disp('                                                                ');
    disp('        QUARTERLY FREQUENCY BAYESIAN VAR                        ');
    disp('                                                                ');
    disp('                                                                ');
    disp('             - FORECASTING -                                     ');
    disp('                                                                ');

    YYvector   = zeros(nsim,H,nv);         % collects forecast      
    YYvector_g = zeros(nsim,H,nv);         % collects forecast in growth terms

    clear post_phi post_sig                % clear previously defined values
    counter   = 0;
    YYact = YYact(end,:)';
    XXact = XXact(end,:)';
    
    for jj=1:nsim
    
    post_phi=squeeze(Phip(jj,:,:));
    post_sig=squeeze(Sigmap(jj,:,:));
    
    %======================================================================
    %              BAYESIAN ESTIMATION: FORECASTING                  
    %======================================================================   

    YYpred              = zeros(H+1,nv);     % forecasts from VAR
    YYpred(1,:)         = YYact;
    XXpred              = zeros(H+1,(nv)*nlags+1);
    XXpred(:,end)       = ones(H+1,1);
    XXpred(1,:)         = XXact;

    %====================================================================== 
    %          given posterior draw, draw #{H+1} random sequence
    %======================================================================

    error_pred = zeros(H+1,nv);     
    
    for h=1:H+1
        
    error_pred(h,:) = mvnrnd(zeros(nv,1), post_sig);         
        
    end

    %====================================================================== 
    %       given posterior draw, iterate forward to construct forecasts
    %======================================================================
        
    % treat first release for the next quarter as data
    frrr = add_vec(rrr);
    vm_loaddataq_v3
    
    YYpred(1,:) = YYY(end-1,:)';
    
    for h=2:H+1
        
    XXpred(h,nv+1:end-1) = XXpred(h-1,1:end-nv-1);
    XXpred(h,1:nv)       = YYpred(h-1,:);  
        if h==2
        YYpred(h,:)      = YYY(end,:)'; % plug in time T+1 data
        else
        YYpred(h,:)      = XXpred(h,:)*post_phi+error_pred(h,:);
        end
    end

    YYpred1     = YYpred;
    YYpred      = YYpred(2:end,:);
    
    counter         = counter +1; 
     
    if counter==5000
    disp('                                                              '); 
    disp(['       FORECAST HORIZON:   ', num2str(H)]                     );
    disp('                                                              ');
    disp(['       DRAW NUMBER:   ', num2str(jj)]                         );
    disp('                                                              ');
    disp(['       REMAINING DRAWS:   ', num2str(nsim-jj)]                );
    disp('                                                              ');

    counter = 0;
    end    
    
    YYvector(jj,:,:)    = YYpred;    
    YYvector_g(jj,:,:)  = 100*(YYpred1(2:end,:)-YYpred1(1:end-1,:));
    end
        
    % SAVE THE MEDIAN VALUE ONLY
    [y95,y80,y50,y20,y05] = moment(YYvector);
    [g95,g80,g50,g20,g05] = moment(YYvector_g);
    
    % cumulative predictive distributions
    YYvector_c  = YYvector;
    YYvector_gc = YYvector_g;
    for jj=1:nsim-nburn
        for hh=2:8
            YYvector_c(jj,hh,:)  = mean(YYvector(jj,1:hh,:));
            YYvector_gc(jj,hh,:) = mean(YYvector_g(jj,1:hh,:));
        end
    end

    % cumulative actual values
    rs_flvlc  = rs_flvl;
    rs_fgrthc = rs_fgrth;

    for hh=2:8
        rs_flvlc(hh,:)  = mean(rs_flvl(1:hh,:));
        rs_fgrthc(hh,:) = mean(rs_fgrth(1:hh,:));
    end

    % compute unconditional probability integral transformation
    pit_lc = zeros(8,nv);
    pit_gc = zeros(8,nv);
    pit_l  = zeros(8,nv);
    pit_g  = zeros(8,nv);

    for hh=1:8
        for ii=1:nv
            pit_gc(hh,ii) = mean(squeeze(YYvector_gc(:,hh,ii))< ones(nsim,1)*rs_fgrthc(hh,ii));
            pit_lc(hh,ii) = mean(squeeze(YYvector_c(:,hh,ii))< ones(nsim,1)*rs_flvlc(hh,ii));
            pit_g(hh,ii)  = mean(squeeze(YYvector_g(:,hh,ii))< ones(nsim,1)*rs_fgrth(hh,ii));
            pit_l(hh,ii)  = mean(squeeze(YYvector(:,hh,ii))< ones(nsim,1)*rs_flvl(hh,ii));
        end
    end
    
    FLQ_vector95(rrr,:,:) = y95;
    FLQ_vector80(rrr,:,:) = y80;
    FLQ_vector50(rrr,:,:) = y50;
    FLQ_vector20(rrr,:,:) = y20;
    FLQ_vector05(rrr,:,:) = y05;
    FGQ_vector95(rrr,:,:) = g95;
    FGQ_vector80(rrr,:,:) = g80;
    FGQ_vector50(rrr,:,:) = g50;
    FGQ_vector20(rrr,:,:) = g20;
    FGQ_vector05(rrr,:,:) = g05;    
    FLQ_vector(rrr,:,:)   = rs_flvl;
    FGQ_vector(rrr,:,:)   = rs_fgrth;
    QPIT_LC(rrr,:,:)      = pit_lc;
    QPIT_GC(rrr,:,:)      = pit_gc;
    QPIT_L(rrr,:,:)       = pit_l;
    QPIT_G(rrr,:,:)       = pit_g;
end

save results_RS_QFBVAR_v2.mat

path=ss;

disp('                                                                 ');
disp(['            ELAPSED TIME:   ', num2str(toc)]                     );
disp('                                                                 ');

elapsedtime=toc;
