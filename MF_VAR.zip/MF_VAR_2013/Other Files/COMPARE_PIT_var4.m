load results_RS_MFBVAR_var4.mat
load results_RS_AR2.mat
load results_RS_QFBVAR_var4.mat

 PIT_G  = PIT_G(nrs_vec,:,:);
QPIT_G  = QPIT_G(nrs_vec,:,:);
APIT_G  = APIT_G(nrs_vec,:,:);

 PIT_GC = PIT_GC(nrs_vec,:,:);
QPIT_GC = QPIT_GC(nrs_vec,:,:);
APIT_GC = APIT_GC(nrs_vec,:,:);

 PIT_L  = PIT_L(nrs_vec,:,:);
QPIT_L  = QPIT_L(nrs_vec,:,:);
APIT_L  = APIT_L(nrs_vec,:,:);

PIT_LC  = PIT_LC(nrs_vec,:,:);
QPIT_LC = QPIT_LC(nrs_vec,:,:);
APIT_LC = APIT_LC(nrs_vec,:,:);

ALL_S = [1 0 1 0];

PIT    =  PIT_G; 
PIT(:,ALL_S==1)=PIT_L(:,ALL_S==1);
QPIT   =  QPIT_G; 
QPIT(:,ALL_S==1)=QPIT_L(:,ALL_S==1);
APIT   =  APIT_G; 
APIT(:,ALL_S==1)=APIT_L(:,ALL_S==1);

h_vec  = [ 1 2 4 8];
v_vec  = [ 2 1 3 4];
yl_vec = {'1-step','2-step','4-step','8-step'};
xl_vec = {'INF','UNR','FF','GDP'};

scrsz = get(0,'ScreenSize');

fig1=figure('Position',[20,20,900,600],'Name',...
        'Marginal PIT','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.3]);
for jjj=1:4
for hhh=1:4
    
hh=h_vec(hhh);    
subplot(4,4,4*(hhh-1)+jjj)
hold on
[ybin xbin]=hist(PIT(:,hh,v_vec(jjj)),[0.1 0.3 0.5 0.7 0.9]);
bar(xbin,100*ybin./sum(ybin),1)
ylim([0 nrs])
ylabel(yl_vec(hhh),'FontSize',12)
xlabel(xl_vec(jjj),'FontSize',12)
HT = findobj(gca,'Type','patch');
set(HT,'FaceColor',[0.6 0.6 0.6],'EdgeColor','w')
hold on
line([0,1],[20 20],'Color',[0.9 0.2 0.1],'LineWidth',2)
axis([0 1 0 100])
end
end

fig2=figure('Position',[20,20,900,600],'Name',...
        'Marginal PIT','Color','w',...
        'Position',[1 scrsz(4)/13 scrsz(3) scrsz(4)/1.3]);
for jjj=1:4
for hhh=1:4
    
hh=h_vec(hhh);    
subplot(4,4,4*(hhh-1)+jjj)
hold on
[ybin xbin]=hist(QPIT(:,hh,v_vec(jjj)),[0.1 0.3 0.5 0.7 0.9]);
bar(xbin,100*ybin./sum(ybin),1)
ylim([0 nrs])
ylabel(yl_vec(hhh),'FontSize',12)
xlabel(xl_vec(jjj),'FontSize',12)
HT = findobj(gca,'Type','patch');
set(HT,'FaceColor',[0.6 0.6 0.6],'EdgeColor','w')
hold on
line([0,1],[20 20],'Color',[0.9 0.2 0.1],'LineWidth',2)
axis([0 1 0 100])
end
end




saveas(fig1,'Figures/PIT_MFVAR_var4.bmp')
saveas(fig2,'Figures/PIT_QFVAR_var4.bmp')